<?php

use App\Enums\PresenceStatus;
use App\Models\Permission;
use App\Services\GreetingService;
use App\Services\Template\Words\Quotes;
use App\Services\Reservation\ValidationService;
use App\Services\TenantService;
use Carbon\CarbonInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Morilog\Jalali\CalendarUtils;
use Morilog\Jalali\Jalalian;

if (!function_exists('convertToPersian')) {
    function convertToPersian(mixed $value): ?string
    {
        if (blank($value)) {
            return null;
        }

        return strtr((string)$value, [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹'
        ]);
    }
}

if (!function_exists('appUpdateIsRecent')) {
    function appUpdateIsRecent(int $days = 7): bool
    {
        try {
            return Carbon::parse(config('app.last_update'))->diffInDays(now()) <= $days;
        } catch (\Exception) {
            return false;
        }
    }
}

if (!function_exists('stripHtml')) {
    function stripHtml(?string $text): string
    {
        if (blank($text)) {
            return '';
        }

        $text = strip_tags($text);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = str_replace(["\u{a0}", "\u{200b}", "\u{feff}"], ' ', $text);
        $text = preg_replace('/\s+/u', ' ', $text);

        return trim((string)$text);
    }
}

if (!function_exists('superClean')) {
    function superClean(?string $text, int $limit = 100, bool $nl2br = false): string
    {
        if (blank($text)) {
            return '';
        }

        $text = strip_tags($text);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace($nl2br ? '/[ \t]+/u' : '/\s+/u', ' ', $text);
        $text = Str::limit(trim((string)$text), $limit);

        return $nl2br ? nl2br(e($text), false) : $text;
    }
}

if (!function_exists('renderComment')) {
    function renderComment(?string $text, int $limit = 2000): string
    {
        if (blank($text)) {
            return '';
        }

        static $cache = [];
        if (count($cache) >= 256) {
            $cache = [];
        }
        $key = md5($text . '|' . $limit);
        if (isset($cache[$key])) {
            return $cache[$key];
        }

        $text = html_entity_decode((string)$text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/[ \t]+/u', ' ', $text);
        $text = Str::limit(trim($text), $limit);
        $text = preg_replace('/\*\*(.+?)\*\*/su', '<strong>$1</strong>', $text);
        $text = Str::sanitizeHtml((string)$text);

        return $cache[$key] = nl2br($text, false);
    }
}

if (!function_exists('renderInline')) {
    function renderInline(?string $html, int $limit = 0): string
    {
        if (blank($html)) {
            return '';
        }

        static $cache = [];
        if (count($cache) >= 256) {
            $cache = [];
        }
        $key = md5($html . '|' . $limit);
        if (isset($cache[$key])) {
            return $cache[$key];
        }

        $src = strip_tags((string) $html, '<span><a><strong><em><u><b><i><br>');

        if ($limit > 0) {
            $parts = preg_split('/(<(?:[^>"\']|"[^"]*"|\'[^\']*\')*>)/u', $src, -1, PREG_SPLIT_DELIM_CAPTURE);
            if ($parts !== false) {
                $out = '';
                $visible = 0;
                foreach ($parts as $i => $part) {
                    if ($i % 2 === 1) {
                        $out .= $part;
                        continue;
                    }
                    if ($visible >= $limit) {
                        break;
                    }
                    $remaining = $limit - $visible;
                    $partLen = mb_strlen($part, 'UTF-8');
                    if ($partLen <= $remaining) {
                        $out .= $part;
                        $visible += $partLen;
                    } else {
                        $out .= mb_substr($part, 0, $remaining, 'UTF-8');
                        $visible = $limit;
                    }
                }
                $src = $out;
            }
        }

        return $cache[$key] = Str::sanitizeHtml($src);
    }
}

if (!function_exists('jdateOnly')) {
    function jdateOnly(mixed $date = null): string
    {
        return convertToPersian(jdate($date)->format('%d/%m/%Y')) ?? '';
    }
}

if (!function_exists('isPast')) {
    function isPast(?string $time = null): bool
    {
        if (blank($time)) {
            return false;
        }

        try {
            return Carbon::parse($time)->isPast();
        } catch (\Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('presence')) {
    function presence(mixed $p): PresenceStatus
    {
        if ($p instanceof PresenceStatus) {
            return $p;
        }

        return PresenceStatus::tryFrom((string)$p) ?? PresenceStatus::default();
    }
}

if (!function_exists('presenceCases')) {
    function presenceCases(): array
    {
        return PresenceStatus::cases();
    }
}

if (!function_exists('greeting')) {
    function greeting(?string $name = null): string
    {
        $name ??= auth()->user()?->name ?? '';
        return app(GreetingService::class)->getGreeting($name);
    }
}

if (!function_exists('shortGreeting')) {
    function shortGreeting(?string $name = null): string
    {
        $name ??= auth()->user()?->name ?? '';
        return app(GreetingService::class)->getShortGreeting($name);
    }
}

if (!function_exists('quotes')) {
    function quotes(): array
    {
        static $quotes;
        return $quotes ??= Quotes::for('general');
    }
}


if (!function_exists('isSpecialDay')) {
    function isSpecialDay(string $type): bool
    {
        $user = auth()->user();

        if (!$user) {
            return false;
        }

        $user->loadMissing('profile');

        $date = match ($type) {
            'birthdate' => $user->profile?->birthdate,
            'start_date' => $user->profile?->start_date,
            default => null,
        };

        if (!$date instanceof CarbonInterface || $date->format('m-d') !== Carbon::now()->format('m-d')) {
            return false;
        }

        return !cache()->has($type . '_' . $user->id);
    }
}

if (!function_exists('getEventStyles')) {
    function getEventStyles(string $type): string
    {
        return match ($type) {
            'birthday' => 'bg-[color-mix(in_srgb,var(--tool-amethyst-bg,var(--md-sys-color-tertiary-container))_70%,transparent)] text-[var(--tool-amethyst-color,var(--md-sys-color-on-tertiary-container))]',
            'anniversary' => 'bg-[color-mix(in_srgb,var(--tool-gold-bg,var(--md-sys-color-secondary-container))_70%,transparent)] text-[var(--tool-gold-color,var(--md-sys-color-on-secondary-container))]',
            'holiday' => 'bg-[color-mix(in_srgb,var(--md-sys-color-error-container)_50%,transparent)] text-[var(--md-sys-color-error)]',
            'reminder' => 'bg-[color-mix(in_srgb,var(--tool-sapphire-bg,var(--md-sys-color-primary-container))_70%,transparent)] text-[var(--tool-sapphire-color,var(--md-sys-color-on-primary-container))]',
            default => 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)]'
        };
    }
}

if (!function_exists('formatJalaliDate')) {
    function formatJalaliDate(mixed $date, string $format = 'l, d F', string $fromFormat = 'Y-m-d'): string
    {
        if (blank($date)) {
            return '';
        }

        try {
            $formatted = Jalalian::fromFormat($fromFormat, (string)$date)->format($format);
            return convertToPersian($formatted) ?? (string)$date;
        } catch (\Throwable $e) {
            return convertToPersian((string)$date) ?? (string)$date;
        }
    }
}

if (!function_exists('isVideo')) {
    function isVideo(?string $path): bool
    {
        if (blank($path)) {
            return false;
        }

        $extension = strtolower(pathinfo(parse_url($path, PHP_URL_PATH) ?? '', PATHINFO_EXTENSION));
        return in_array($extension, ['mp4', 'webm', 'ogg', 'mov'], true);
    }
}

if (!function_exists('getFileExtension')) {
    function getFileExtension(?string $path): string
    {
        if (blank($path)) {
            return '';
        }

        return strtolower(pathinfo($path, PATHINFO_EXTENSION));
    }
}

if (!function_exists('toJalali')) {
    function toJalali(mixed $date, string $format = 'Y/m/d H:i'): string
    {
        if (blank($date)) {
            return '';
        }

        try {
            if ($date instanceof CarbonInterface) {
                return convertToPersian(Jalalian::fromCarbon($date->copy()->setTimezone(config('app.timezone')))->format($format)) ?? '';
            }

            $dateString = str_replace('/', '-', (string)$date);
            $year = (int)explode('-', $dateString)[0];

            if ($year >= 1300 && $year <= 1500) {
                return convertToPersian($dateString) ?? $dateString;
            }

            return convertToPersian(Jalalian::fromCarbon(Carbon::parse($dateString)->setTimezone(config('app.timezone')))->format($format)) ?? '';
        } catch (\Throwable $e) {
            return '';
        }
    }
}

if (!function_exists('toJalaliSmart')) {
    function toJalaliSmart(mixed $date): string
    {
        if (blank($date)) {
            return '—';
        }

        try {
            $carbon = $date instanceof CarbonInterface
                ? $date
                : Carbon::parse($date);

            $format = $carbon->format('H:i') === '00:00' ? 'Y/m/d' : 'Y/m/d H:i';

            return toJalali($carbon, $format);
        } catch (\Throwable $e) {
            return '—';
        }
    }
}

if (!function_exists('toJalaliRelative')) {
    function toJalaliRelative(mixed $date, bool $short = false, int $dateAfterDays = 30): string
    {
        if (blank($date)) {
            return '';
        }

        try {
            $carbon = $date instanceof CarbonInterface
                ? $date
                : Carbon::parse($date);
        } catch (\Throwable $e) {
            return '';
        }

        $seconds = $carbon->diffInSeconds(Carbon::now());

        if ($seconds < 60) {
            return $short ? 'الان' : 'همین الان';
        }

        $minutes = intdiv($seconds, 60);
        if ($minutes < 60) {
            $pMinutes = convertToPersian($minutes);
            return $short ? $pMinutes . 'د' : $pMinutes . ' دقیقه پیش';
        }

        $hours = intdiv($minutes, 60);
        if ($hours < 24) {
            $pHours = convertToPersian($hours);
            return $short ? $pHours . 'س' : $pHours . ' ساعت پیش';
        }

        $days = intdiv($hours, 24);
        if ($days < 7) {
            $pDays = convertToPersian($days);
            return $short ? $pDays . 'ر' : $pDays . ' روز پیش';
        }

        if ($days < 30) {
            $weeks = intdiv($days, 7);
            $pWeeks = convertToPersian($weeks);
            return $short ? $pWeeks . 'ه' : $pWeeks . ' هفته پیش';
        }

        if ($dateAfterDays === 0 || $days < $dateAfterDays) {
            $months = intdiv($days, 30);
            if ($months < 12) {
                $pMonths = convertToPersian($months);
                return $short ? $pMonths . 'م' : $pMonths . ' ماه پیش';
            }

            $pYears = convertToPersian(intdiv($days, 365));
            return $short ? $pYears . 'س' : $pYears . ' سال پیش';
        }

        return toJalali($carbon, 'Y/m/d');
    }
}

if (!function_exists('jNow')) {
    function jNow(string $part = 'year'): int
    {
        $jalalian = jdate();

        return match ($part) {
            'month' => $jalalian->getMonth(),
            'day' => $jalalian->getDay(),
            default => $jalalian->getYear(),
        };
    }
}

if (!function_exists('jalaliMonthBounds')) {
    function jalaliMonthBounds(\Carbon\Carbon $date): array
    {
        $j = Jalalian::fromCarbon($date);

        return [
            (new Jalalian($j->getYear(), $j->getMonth(), 1))->toCarbon()->startOfDay(),
            (new Jalalian($j->getYear(), $j->getMonth(), $j->getMonthDays()))->toCarbon()->endOfDay(),
        ];
    }
}

if (!function_exists('jalaliAddMonth')) {
    function jalaliAddMonth(\Carbon\Carbon $date): Carbon
    {
        $j = Jalalian::fromCarbon($date);
        $index = $j->getYear() * 12 + $j->getMonth();
        $year = intdiv($index, 12);
        $month = $index % 12 + 1;
        $day = min($j->getDay(), (new Jalalian($year, $month, 1))->getMonthDays());

        return Carbon::instance((new Jalalian($year, $month, $day, 0, 0, 0, $date->getTimezone()))->toCarbon())
            ->setTimeFrom($date);
    }
}

if (!function_exists('jalaliSpanFromParts')) {
    function jalaliSpanFromParts(mixed $fromYear, mixed $fromMonth, mixed $fromDay, mixed $toYear, mixed $toMonth, mixed $toDay): ?array
    {
        if (!$fromYear || !$fromMonth || !$fromDay || !$toYear || !$toMonth || !$toDay) {
            return null;
        }

        try {
            if (!CalendarUtils::checkDate((int)$fromYear, (int)$fromMonth, (int)$fromDay, true)
                || !CalendarUtils::checkDate((int)$toYear, (int)$toMonth, (int)$toDay, true)) {
                return null;
            }

            $start = CalendarUtils::createCarbonFromFormat('Y/m/d H:i:s', sprintf('%04d/%02d/%02d 00:00:00', $fromYear, $fromMonth, $fromDay))->startOfDay();
            $end = CalendarUtils::createCarbonFromFormat('Y/m/d H:i:s', sprintf('%04d/%02d/%02d 00:00:00', $toYear, $toMonth, $toDay))->endOfDay();
        } catch (\Throwable) {
            return null;
        }

        return $end->lt($start) ? null : [$start, $end];
    }
}

if (!function_exists('confirmDialog')) {
    function confirmDialog(string $method, string $title, string $message, mixed $params = null, ?string $type = 'dispatch', ?string $tone = null): string
    {
        $payload = ['title' => $title, 'message' => $message, 'method' => $method];

        if ($params !== null) {
            $payload['params'] = $params;
        }

        if ($type !== null) {
            $payload['type'] = $type;
        }

        if ($tone !== null) {
            $payload['tone'] = $tone;
        }

        return "\$dispatch('open-confirmation', " . json_encode($payload, JSON_UNESCAPED_UNICODE) . ')';
    }
}

if (!function_exists('confirmDialogListener')) {
    function confirmDialogListener(array $methods): string
    {
        return implode('; ', array_map(
            fn (string $method, bool|string $params) => "if (\$event.detail.method === '{$method}') \$wire.call('{$method}'" . match (true) {
                $params === 'spread' => ", ...\$event.detail.params",
                (bool) $params => ", \$event.detail.params",
                default => '',
            } . ')',
            array_keys($methods),
            $methods,
        ));
    }
}

if (!function_exists('canAdmin')) {
    function canAdmin(): bool
    {
        static $status = [];
        $user = auth()->user();

        if (!$user) {
            return false;
        }

        if (isset($status[$user->id])) {
            return $status[$user->id];
        }

        // Developers are super-admin by role — no permission row needed.
        if ($user->isDeveloper()) {
            return $status[$user->id] = true;
        }

        $adminPerm = Permission::forUser($user->id);

        return $status[$user->id] = $adminPerm && ($adminPerm->is_super_admin || !empty($adminPerm->abilities));
    }
}

if (!function_exists('disabledReservationTypes')) {
    function disabledReservationTypes(): array
    {
        return app(ValidationService::class)->disabledTypes();
    }
}

if (!function_exists('tenantAsset')) {
    function tenantAsset(string $tenant, string $type, string $role, ?string $fallback = null): ?string
    {
        static $cache = [];
        $pattern = "{$type}/{$tenant}/{$role}";
        if (array_key_exists($pattern, $cache)) {
            return $cache[$pattern] ?? $fallback;
        }

        $matches = glob(resource_path("assets/{$type}/{$tenant}/{$role}.*")) ?: [];
        $cache[$pattern] = $matches ? "build/assets/{$type}/{$tenant}/" . basename($matches[0]) : null;

        return $cache[$pattern] ?? $fallback;
    }
}

if (!function_exists('tenantSiblings')) {
    function tenantSiblings(string $tenant, array $items): array
    {
        return array_map(function (array $item) use ($tenant) {
            $found = glob(resource_path("assets/img/{$tenant}/sibling/optimized/" . strtolower($item['name']) . '.*')) ?: [];

            $item['logo'] = ($item['logo'] ?? null) ?: ($found ? "build/assets/img/{$tenant}/sibling/" . basename($found[0]) : null);

            return $item;
        }, $items);
    }
}

if (!function_exists('tenantVideos')) {
    function tenantVideos(string $tenant): array
    {
        static $cache = [];
        if (array_key_exists($tenant, $cache)) {
            return $cache[$tenant];
        }

        $files = glob(resource_path("assets/video/{$tenant}/*.*")) ?: [];
        natsort($files);

        return $cache[$tenant] = array_map(
            fn(string $file): string => "build/assets/video/{$tenant}/" . basename($file),
            array_values($files)
        );
    }
}

if (!function_exists('tenantBackdrops')) {
    function tenantBackdrops(string $tenant): array
    {
        static $cache = [];
        if (array_key_exists($tenant, $cache)) {
            return $cache[$tenant];
        }

        $files = glob(resource_path("assets/img/{$tenant}/bg/*.*")) ?: [];
        natsort($files);

        return $cache[$tenant] = array_map(
            fn(string $file): string => "build/assets/img/{$tenant}/bg/" . basename($file),
            array_values($files)
        );
    }
}

if (!function_exists('tenantOff')) {
    function tenantOff(string $key): bool
    {
        return app(TenantService::class)->off($key);
    }
}

if (!function_exists('tenantOffKeys')) {
    function tenantOffKeys(): array
    {
        return app(TenantService::class)->offKeys();
    }
}

if (!function_exists('aiAssistantOn')) {
    function aiAssistantOn(): bool
    {
        return auth()->check()
            && config('app.ai_assistant_access') === true
            && filled(config('services.ai_assistant.url'))
            && !tenantOff('ai-assistant');
    }
}

if (!function_exists('thsAiOn')) {
    function thsAiOn(): bool
    {
        return !tenantOff('ths:ai') && \App\Services\Ai\AiClient::isConfigured();
    }
}

if (!function_exists('correspondenceAiOn')) {
    function correspondenceAiOn(): bool
    {
        return !tenantOff('correspondence:ai') && \App\Services\Ai\AiClient::isConfigured();
    }
}

if (!function_exists('channelAiOn')) {
    function channelAiOn(): bool
    {
        return !tenantOff('channel:ai') && \App\Services\Ai\AiClient::isConfigured() && filled(config('ai.channel.modes'));
    }
}

if (!function_exists('feedAiOn')) {
    function feedAiOn(): bool
    {
        return !tenantOff('feed:ai') && \App\Services\Ai\AiClient::isConfigured();
    }
}

if (!function_exists('contactAiOn')) {
    function contactAiOn(): bool
    {
        return !tenantOff('contact:ai') && \App\Services\Ai\AiClient::isConfigured() && filled(config('ai.messaging.rules'));
    }
}

if (!function_exists('correspondenceMailOn')) {
    function correspondenceMailOn(): bool
    {
        return !tenantOff('notify') && !tenantOff('notify:mail');
    }
}

if (!function_exists('tenantOffName')) {
    function tenantOffName(string $name): bool
    {
        return app(TenantService::class)->offName($name);
    }
}

if (!function_exists('tenantThemeCss')) {
    function tenantThemeCss(): string
    {
        return app(TenantService::class)->themeCss();
    }
}

if (!function_exists('tenantOffCss')) {
    function tenantOffCss(): string
    {
        return app(TenantService::class)->offCss();
    }
}

if (!function_exists('tenantLogo')) {
    function tenantLogo(bool $dark, string $scope = 'user', bool $auth = false): string
    {
        if ($scope === 'admin' && config('app.admin_use_company_logo')) {
            return config('app.company_logo');
        }

        $reversed = config('app.' . $scope . ($auth ? '_auth_reverse_logo' : '_reverse_logo'));
        $showDark = $reversed ? !$dark : $dark;

        return config($showDark ? 'app.app_logo_dark' : 'app.app_logo_light');
    }
}
