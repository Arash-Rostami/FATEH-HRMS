<?php

namespace App\Filament\Resources\ReservationPolicyResource\Pages;

use App\Filament\Resources\ReservationPolicyResource;
use App\Filament\Resources\ReservationResource;
use App\Traits\Filament\FilamentHeaderActions;
use App\Filament\Pages\ListRecords;

class ListPolicies extends ListRecords
{
    use FilamentHeaderActions;

    protected static string $resource = ReservationPolicyResource::class;

    protected function listHeaderActions(): array
    {
        return [...ReservationResource::switchActions(static::$resource), ReservationPolicyResource::setupGuideAction()];
    }
}