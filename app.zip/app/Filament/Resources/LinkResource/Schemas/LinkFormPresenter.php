<?php

namespace App\Filament\Resources\LinkResource\Schemas;

use Closure;
use App\Enums\LinkIcon;
use App\Enums\LinkType;
use App\Models\Link;
use App\Rules\ExtraRequiresInternalUrl;
use App\Support\FileNamer;
use App\Traits\Filament\FilamentFormDivider;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TagsInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Components\Utilities\Get;
use Livewire\Features\SupportFileUploads\TemporaryUploadedFile;

class LinkFormPresenter
{
    use FilamentFormDivider;

    private const URL_HOST_REGEX = '/^((?:mailto|tel):[A-Za-z0-9._~:\/?#\[\]@!$&()*+,;=%-]+|[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[A-Za-z0-9._~:\/?#\[\]@!$&()*+,;=%-]+|[A-Za-z0-9][A-Za-z0-9._-]+(:[0-9]{1,5})?([\/?#][A-Za-z0-9._~:\/?#@!$&()*+,;=%-]*)?)$/';

    public static function companyIps(): TagsInput
    {
        return TagsInput::make('extra')
            ->label(__('resources/link/strings.fields.extra'))
            ->placeholder(__('resources/link/strings.fields.extra_placeholder'))
            ->helperText(__('resources/link/strings.fields.extra_hint'))
            ->splitKeys(['Enter', ',', ' '])
            ->visible(fn (Get $get): bool => filled($get('internal_url')))
            ->requiredWith('internal_url')
            ->dehydrateStateUsing(fn (mixed $state): mixed => is_array($state)
                ? array_values(array_filter(array_map('trim', $state), fn (string $v): bool => $v !== ''))
                : $state
            )
            ->rule(self::extraRequiresInternalUrl());
    }

    private static function extraRequiresInternalUrl(): Closure
    {
        return fn (Get $get): ExtraRequiresInternalUrl => new ExtraRequiresInternalUrl($get('extra'), $get('internal_url'));
    }

    public static function icon(): FileUpload
    {
        return FileUpload::make('icon')
            ->label(__('resources/link/strings.fields.icon'))
            ->disk('public')
            ->directory('link/icon')
            ->downloadable()
            ->openable()
            ->previewable()
            ->imageEditor()
            ->maxSize(config('file_upload_limits.icon'))
            ->acceptedFileTypes(['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'])
            ->getUploadedFileNameForStorageUsing(
                fn (TemporaryUploadedFile $file): string => FileNamer::stored('link', $file)
            )
            ->image()
            ->imagePreviewHeight('80')
            ->required()
            ->helperText(__('resources/link/strings.hints.icon'));
    }

    public static function iconDescription(): Select
    {
        return Select::make('icon_description')
            ->label(__('resources/link/strings.fields.icon_description'))
            ->helperText(__('resources/link/strings.hints.icon_description'))
            ->searchable()
            ->native(false)
            ->allowHtml()
            ->options(fn(?Link $record): array => static::curatedIconOptions($record))
            ->getOptionLabelUsing(fn(?string $state): ?string => $state !== null
                ? (LinkIcon::tryFrom($state)?->getLabel() ?? $state)
                : null)
            ->nullable();
    }

    private static function curatedIconOptions(?Link $record): array
    {
        $options = collect(LinkIcon::cases())
            ->mapWithKeys(fn(LinkIcon $icon) => [$icon->value => static::renderCuratedIconOption($icon->value, $icon->getLabel())]);

        if (filled($record?->icon_description) && !LinkIcon::tryFrom($record->icon_description)) {
            $options->put($record->icon_description, static::renderCuratedIconOption($record->icon_description, $record->icon_description));
        }

        return $options->all();
    }

    private static function renderCuratedIconOption(string $value, string $label): string
    {
        return '<div class="flex items-center gap-2"><span class="material-symbols-rounded text-[18px] leading-none">' . e($value) . '</span><span>' . e($label) . '</span></div>';
    }

    public static function image(): FileUpload
    {
        return FileUpload::make('image')
            ->label(__('resources/link/strings.fields.image'))
            ->disk('public')
            ->directory('link/image')
            ->imageEditor()
            ->maxSize(config('file_upload_limits.image'))
            ->downloadable()
            ->openable()
            ->previewable()
            ->acceptedFileTypes(['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'])
            ->getUploadedFileNameForStorageUsing(
                fn (TemporaryUploadedFile $file): string => FileNamer::stored('link', $file)
            )
            ->image()
            ->imagePreviewHeight('120')
            ->required()
            ->helperText(__('resources/link/strings.hints.image'));
    }

    public static function imageDescription(): Textarea
    {
        return Textarea::make('image_description')
            ->label(__('resources/link/strings.fields.image_description'))
            ->rows(2)
            ->maxLength(500)
            ->helperText(__('resources/link/strings.hints.image_description'));
    }

    public static function internalUrl(): TextInput
    {
        return TextInput::make('internal_url')
            ->label(__('resources/link/strings.fields.internal_url'))
            ->rules(['string', 'regex:' . self::URL_HOST_REGEX])
            ->maxLength(2048)
            ->live(onBlur: true)
            ->helperText(__('resources/link/strings.fields.internal_url_hint'))
            ->rule(self::extraRequiresInternalUrl());
    }

    public static function linkType(): Radio
    {
        return Radio::make('link')
            ->label(__('resources/link/strings.fields.link_type'))
            ->options(LinkType::class)
            ->required()
            ->inline()
            ->helperText(__('resources/link/strings.hints.link_type'));
    }

    public static function sequence(): Select
    {
        return Select::make('sequence')
            ->label(__('resources/link/strings.fields.sequence'))
            ->options(fn (): array => array_combine(range(0, 100), range(0, 100)))
            ->default(0)
            ->searchable()
            ->native(false)
            ->helperText(__('resources/link/strings.fields.sequence_hint'));
    }

    public static function url(): TextInput
    {
        return TextInput::make('url')
            ->label(__('resources/link/strings.fields.url'))
            ->required()
            ->rules(['string', 'regex:' . self::URL_HOST_REGEX])
            ->maxLength(2048)
            ->placeholder('//:https')
            ->helperText(__('resources/link/strings.fields.url_hint'));
    }

    public static function urlDescription(): Textarea
    {
        return Textarea::make('url_description')
            ->label(__('resources/link/strings.fields.url_description'))
            ->rows(2)
            ->maxLength(1000)
            ->helperText(__('resources/link/strings.hints.url_description'));
    }

    public static function urlTitle(): TextInput
    {
        return TextInput::make('url_title')
            ->label(__('resources/link/strings.fields.url_title'))
            ->required()
            ->maxLength(255)
            ->helperText(__('resources/link/strings.hints.url_title'));
    }
}
