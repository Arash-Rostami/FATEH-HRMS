<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProfileResource\Exports\ProfileExporter;
use App\Filament\Resources\ProfileResource\Pages\CreateProfile;
use App\Filament\Resources\ProfileResource\Pages\EditProfile;
use App\Filament\Resources\ProfileResource\Pages\ListProfiles;
use App\Filament\Resources\ProfileResource\RelationManagers\UserRelationManager;
use App\Filament\Resources\ProfileResource\Schemas\ProfileFormPresenter;
use App\Filament\Resources\ProfileResource\Schemas\ProfileInfolistPresenter;
use App\Filament\Resources\ProfileResource\Schemas\ProfileTablePresenter;
use App\Models\Profile;
use App\Traits\Filament\AuthorizesByPermission;
use App\Traits\Filament\FilamentActions;
use App\Traits\Filament\FilamentAdminGuide;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class ProfileResource extends Resource
{
    use FilamentActions, AuthorizesByPermission, FilamentAdminGuide;

    protected static ?string $model = Profile::class;
    protected static string|null|BackedEnum $navigationIcon = 'heroicon-o-identification';
    protected static ?int $navigationSort = 2;

    protected static array $guide = [
        ['label' => 'بررسی', 'icon' => 'menu_book', 'view' => 'filament.resources.profile.guide.overview'],
        ['label' => 'زبانه‌های فهرست', 'icon' => 'tab', 'view' => 'filament.resources.profile.guide.list-tabs'],
        ['label' => 'کارهای مدیریتی', 'icon' => 'admin_panel_settings', 'view' => 'filament.resources.profile.guide.admin-ops'],
        ['label' => 'تجربهٔ کاربر', 'icon' => 'visibility', 'view' => 'filament.resources.profile.guide.user'],
    ];

    public static function getRecordTitle(?Model $record): ?string
    {
        if (! $record) {
            return null;
        }

        return $record->user?->name ?? ('#' . $record->personnel_id);
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Tabs::make()
                ->tabs([
                    Tab::make(__('resources/profile/strings.form.section_identity_header'))
                        ->icon('heroicon-o-user-circle')
                        ->schema([
                            Section::make(__('resources/profile/strings.form.section_identity'))
                                ->schema([
                                    ProfileFormPresenter::userId(),
                                    ProfileFormPresenter::birthdate(),
                                    ProfileFormPresenter::gender(),
                                    ProfileFormPresenter::maritalStatus(),
                                    ProfileFormPresenter::numberOfChildren(),
                                    ProfileFormPresenter::divider(),
                                    ProfileFormPresenter::personnelId(),
                                    ProfileFormPresenter::idCardNumber(),
                                    ProfileFormPresenter::idBookletNumber(),

                                ])
                                ->columns(2)
                                ->columnSpan(1),

                            Section::make(__('resources/profile/strings.form.section_contact'))
                                ->icon('heroicon-o-phone')
                                ->schema([
                                    ProfileFormPresenter::cellphone(),
                                    ProfileFormPresenter::landline(),
                                    ProfileFormPresenter::emergencyPhone(),
                                    ProfileFormPresenter::emergencyRelationship(),
                                    ProfileFormPresenter::licensePlate(),
                                    ProfileFormPresenter::zipCode(),
                                    ProfileFormPresenter::address(),
                                    ProfileFormPresenter::accessibility(),
                                ])
                                ->columns(2)
                                ->columnSpan(1),

                            Section::make(__('resources/profile/strings.form.section_employment'))
                                ->icon('heroicon-o-briefcase')
                                ->schema([
                                    ProfileFormPresenter::employmentType(),
                                    ProfileFormPresenter::employmentStatus(),
                                    ProfileFormPresenter::degree(),
                                    ProfileFormPresenter::divider(),
                                    ProfileFormPresenter::departmentId(),
                                    ProfileFormPresenter::position(),
                                    ProfileFormPresenter::workExperience(),
                                    ProfileFormPresenter::insurance(),
                                    ProfileFormPresenter::divider(),
                                    ProfileFormPresenter::startDate(),
                                    ProfileFormPresenter::endDate(),
                                    ProfileFormPresenter::field(),
                                ])
                                ->columns(3)
                                ->columnSpanFull(),
                        ])
                        ->columns(2),


                    Tab::make(__('resources/profile/strings.form.section_media'))
                        ->icon('heroicon-o-paper-clip')
                        ->schema([
                            ProfileFormPresenter::image(),
                            ProfileFormPresenter::attachments(),
                        ])
                        ->columns(2),

                    Tab::make(__('resources/profile/strings.form.section_skills'))
                        ->icon('heroicon-o-academic-cap')
                        ->schema([
                            ProfileFormPresenter::skills(),
                        ]),

                    Tab::make(__('resources/profile/strings.form.section_about'))
                        ->icon('heroicon-o-information-circle')
                        ->schema([
                            ProfileFormPresenter::interests(),
                            ProfileFormPresenter::aboutMe(),
                            ProfileFormPresenter::favoriteColors(),
                        ])
                        ->columns(2),

                    Tab::make(__('resources/profile/strings.form.section_details'))
                        ->icon('heroicon-o-list-bullet')
                        ->schema([
                            ProfileFormPresenter::details(),
                        ]),
                ])
                ->columnSpanFull()
                ->persistTabInQueryString(),
        ]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->with(['user', 'department', 'details'])
            ->withCount('details');
    }

    public static function getGlobalSearchResultActions(Model $record): array
    {
        return [
            Action::make('edit')
                ->icon('heroicon-m-pencil')
                ->url(static::getUrl('edit', ['record' => $record])),
        ];
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            ' شماره پرسنلی' => $record->personnel_id ?? '—',
            'کارت ملی' => $record->id_card_number ?? '—',
            'شماره شناسنامه' => $record->id_booklet_number ?? '—',
            'موبایل' => $record->cellphone ?? '—',
        ];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return $record->user->name;
    }

    public static function getGlobalSearchResultUrl(Model $record): string
    {
        return static::getUrl('edit', ['record' => $record]);
    }

    public static function getGloballySearchableAttributes(): array
    {
        return [
            'user.name',
            'personnel_id',
            'id_card_number',
            'id_booklet_number',
            'cellphone',
        ];
    }

    public static function getModelLabel(): string
    {
        return __('resources/profile/strings.navigation.singular');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('resources/profile/strings.navigation.group');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListProfiles::route('/'),
            'create' => CreateProfile::route('/create'),
            'edit' => EditProfile::route('/{record}/edit'),
        ];
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/profile/strings.navigation.plural');
    }

    public static function getRelations(): array
    {
        return [
            UserRelationManager::class,
        ];
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Tabs::make()
                ->tabs([
                    Tab::make(__('resources/profile/strings.infolist.section_identity'))
                        ->icon('heroicon-o-user-circle')
                        ->schema([
                            Section::make()
                                ->extraAttributes(['class' => 'fi-infolist-panel'])
                                ->schema([
                                    ProfileInfolistPresenter::id(),
                                    ProfileInfolistPresenter::personnelId(),
                                    ProfileInfolistPresenter::userName(),
                                    ProfileInfolistPresenter::gender(),
                                    ProfileInfolistPresenter::idCardNumber(),
                                    ProfileInfolistPresenter::idBookletNumber(),
                                    ProfileInfolistPresenter::birthdate(),
                                    ProfileInfolistPresenter::age(),
                                    ProfileInfolistPresenter::maritalStatus(),
                                    ProfileInfolistPresenter::numberOfChildren(),
                                    ProfileInfolistPresenter::divider(),
                                    ProfileInfolistPresenter::cellphone(),
                                    ProfileInfolistPresenter::landline(),
                                    ProfileInfolistPresenter::emergencyPhone(),
                                    ProfileInfolistPresenter::emergencyRelationship(),
                                    ProfileInfolistPresenter::licensePlate(),
                                    ProfileInfolistPresenter::zipCode(),
                                    ProfileInfolistPresenter::address(),
                                    ProfileInfolistPresenter::accessibility(),
                                ])
                                ->columns(3),
                        ]),

                    Tab::make(__('resources/profile/strings.infolist.section_employment'))
                        ->icon('heroicon-o-briefcase')
                        ->schema([
                            Section::make()
                                ->extraAttributes(['class' => 'fi-infolist-panel'])
                                ->schema([
                                    ProfileInfolistPresenter::department(),
                                    ProfileInfolistPresenter::unit(),
                                    ProfileInfolistPresenter::section(),
                                    ProfileInfolistPresenter::position(),
                                    ProfileInfolistPresenter::employmentType(),
                                    ProfileInfolistPresenter::employmentStatus(),
                                    ProfileInfolistPresenter::degree(),
                                    ProfileInfolistPresenter::field(),
                                    ProfileInfolistPresenter::insurance(),
                                    ProfileInfolistPresenter::divider(),
                                    ProfileInfolistPresenter::startDate(),
                                    ProfileInfolistPresenter::endDate(),
                                    ProfileInfolistPresenter::workExperience(),
                                ])
                                ->columns(3),
                        ]),

                    Tab::make(__('resources/profile/strings.infolist.section_media'))
                        ->icon('heroicon-o-paper-clip')
                        ->schema([
                            Section::make()
                                ->extraAttributes(['class' => 'fi-infolist-panel'])
                                ->schema([
                                    ProfileInfolistPresenter::image(),
                                    ...ProfileInfolistPresenter::attachments(),
                                ])
                                ->columns(2),
                        ]),

                    Tab::make(__('resources/profile/strings.infolist.section_skills'))
                        ->icon('heroicon-o-academic-cap')
                        ->schema([
                            Section::make()
                                ->extraAttributes(['class' => 'fi-infolist-panel'])
                                ->schema([
                                    ProfileInfolistPresenter::skills(),
                                ]),
                        ]),

                    Tab::make(__('resources/profile/strings.infolist.section_about'))
                        ->icon('heroicon-o-information-circle')
                        ->schema([
                            Section::make()
                                ->extraAttributes(['class' => 'fi-infolist-panel'])
                                ->schema([
                                    ProfileInfolistPresenter::interests(),
                                    ProfileInfolistPresenter::favoriteColors(),
                                    ProfileInfolistPresenter::aboutMe(),
                                    ProfileInfolistPresenter::divider(),
                                    ProfileInfolistPresenter::createdAt(),
                                    ProfileInfolistPresenter::updatedAt(),
                                ])
                                ->columns(2),
                        ]),

                    Tab::make(__('resources/profile/strings.infolist.section_details'))
                        ->icon('heroicon-o-list-bullet')
                        ->schema([
                            Section::make()
                                ->extraAttributes(['class' => 'fi-infolist-panel'])
                                ->schema([
                                    ProfileInfolistPresenter::details(),
                                ]),
                        ]),
                ])
                ->columnSpanFull()
                ->persistTabInQueryString()
                ->extraAttributes(['class' => 'fi-infolist-panel']),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                ProfileTablePresenter::id(),
                ProfileTablePresenter::avatar(),
                ProfileTablePresenter::userName(),
                ProfileTablePresenter::position(),
                ProfileTablePresenter::employmentStatus(),
                ProfileTablePresenter::personnelId(),
                ProfileTablePresenter::department(),
                ProfileTablePresenter::employmentType(),
                ProfileTablePresenter::gender(),
                ProfileTablePresenter::cellphone(),
                ProfileTablePresenter::startDate(),
                ProfileTablePresenter::createdAt(),
                ProfileTablePresenter::detailsCount(),
            ])
            ->groups([
                ProfileTablePresenter::departmentGroup(),
                ProfileTablePresenter::positionGroup(),
                ProfileTablePresenter::employmentStatusGroup(),
                ProfileTablePresenter::employmentTypeGroup(),
                ProfileTablePresenter::genderGroup(),
            ])
            ->filters([
                ProfileTablePresenter::employmentStatusFilter(),
                ProfileTablePresenter::employmentTypeFilter(),
                ProfileTablePresenter::genderFilter(),
                ProfileTablePresenter::degreeFilter(),
                ProfileTablePresenter::departmentFilter(),
                ProfileTablePresenter::hasDetailsFilter(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                self::viewAction(),
                self::editAction(),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells)
            ->striped()
            ->groupedBulkActions(self::bulkActions(ProfileExporter::class))
            ->emptyStateIcon('heroicon-o-bookmark')
            ->defaultSort('id', 'desc');
    }
}
