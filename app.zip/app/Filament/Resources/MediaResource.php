<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MediaResource\Pages\CreateMedia;
use App\Filament\Resources\MediaResource\Pages\EditMedia;
use App\Filament\Resources\MediaResource\Pages\ListMedia;
use App\Filament\Resources\MediaResource\RelationManagers\EpisodesRelationManager;
use App\Filament\Resources\MediaResource\RelationManagers\ProgressRelationManager;
use App\Filament\Resources\MediaResource\Schemas\MediaFormPresenter;
use App\Filament\Resources\MediaResource\Schemas\MediaInfolistPresenter;
use App\Filament\Resources\MediaResource\Schemas\MediaTablePresenter;
use App\Models\Media;
use App\Traits\Filament\AuthorizesByPermission;
use App\Traits\Filament\FilamentActions;
use App\Traits\Filament\FilamentAdminGuide;
use App\Traits\Filament\FilamentFilters;
use App\Traits\Filament\FilamentVisibility;
use Closure;
use Filament\Actions\Action;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class MediaResource extends Resource
{
    use FilamentAdminGuide, FilamentActions, FilamentFilters, FilamentVisibility, AuthorizesByPermission;

    public static function shouldRegisterNavigation(): bool
    {
        return ReportResource::knowledgeEntry() === static::class;
    }

    public static function getNavigationLabel(): string
    {
        return __('resources/report/strings.nav_label');
    }

    protected static ?string $model = Media::class;
    protected static ?string $recordTitleAttribute = 'title';
    protected static ?string $slug = 'media';
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-play-circle';

    protected static array $guide = [
        ['label' => 'معرفی رسانه', 'icon' => 'video_library', 'view' => 'filament.resources.media.guide.overview'],
        ['label' => 'ثبت و ویرایش', 'icon' => 'admin_panel_settings', 'view' => 'filament.resources.media.guide.admin-ops'],
        ['label' => 'دسترسی واحدها', 'icon' => 'lock', 'view' => 'filament.resources.media.guide.visibility'],
        ['label' => 'فهرست و فیلترها', 'icon' => 'filter_list', 'view' => 'filament.resources.media.guide.list-tabs'],
        ['label' => 'نمای کاربر', 'icon' => 'visibility', 'view' => 'filament.resources.media.guide.user'],
    ];

    public static function form(Schema $schema): Schema
    {
        $isSeries = '$get(\'kind\') === \'' . Media::KIND_SERIES . '\'';

        return $schema->components([
            Tabs::make()
                ->tabs([
                    Tab::make(__('resources/media/strings.form.tab_main'))
                        ->icon('heroicon-o-information-circle')
                        ->schema([
                            Section::make(__('resources/media/strings.form.section_main'))
                                ->description(__('resources/media/strings.form.section_description'))
                                ->icon('heroicon-o-film')
                                ->schema([
                                    MediaFormPresenter::kind(),
                                    MediaFormPresenter::title(),
                                    MediaFormPresenter::topic(),
                                    MediaFormPresenter::module(),
                                    MediaFormPresenter::icon(),
                                    MediaFormPresenter::divider(),
                                    MediaFormPresenter::departmentId(),
                                    MediaFormPresenter::departments(),
                                    MediaFormPresenter::userId(),
                                    MediaFormPresenter::active(),
                                    MediaFormPresenter::pinned(),
                                    MediaFormPresenter::divider(),
                                    MediaFormPresenter::reportDate(),
                                    MediaFormPresenter::expiresAt(),
                                    MediaFormPresenter::parentId(),
                                    MediaFormPresenter::reportIds(),
                                    MediaFormPresenter::divider(),
                                    MediaFormPresenter::description(),
                                ])
                                ->columns(2)
                                ->columnSpanFull(),
                        ]),

                    Tab::make(__('resources/media/strings.form.tab_files'))
                        ->icon('heroicon-o-paper-clip')
                        ->schema([
                            Section::make(__('resources/media/strings.form.section_files'))
                                ->icon('heroicon-o-folder-open')
                                ->schema([
                                    MediaFormPresenter::coverImage(),
                                    MediaFormPresenter::divider(),
                                    MediaFormPresenter::filePath()->hiddenJs($isSeries),
                                    MediaFormPresenter::durationSeconds()->hiddenJs($isSeries),
                                ])
                                ->columns(2)
                                ->columnSpanFull(),

                            Section::make(__('resources/media/strings.form.section_tracks'))
                                ->icon('heroicon-o-document-text')
                                ->schema([
                                    MediaFormPresenter::transcriptPath(),
                                    MediaFormPresenter::chaptersPath(),
                                ])
                                ->hiddenJs($isSeries)
                                ->columns(2)
                                ->columnSpanFull(),
                        ]),
                ])
                ->columnSpanFull()
                ->persistTabInQueryString(),
        ]);
    }

    public static function mediaActiveColumn(): ToggleColumn
    {
        return self::activeColumn()->rules(fn (Model $record): array => [
            fn (string $attribute, mixed $value, Closure $fail) => $value && $record->kind !== Media::KIND_SERIES && blank($record->file_path)
                ? $fail(__('resources/media/strings.validation.activate_needs_file'))
                : null,
        ]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->with(['department', 'user:id,name', 'parent:id,title']);
    }

    public static function getRelations(): array
    {
        return [
            EpisodesRelationManager::class,
            ProgressRelationManager::class,
        ];
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()
                ->extraAttributes(['class' => 'fi-infolist-panel'])
                ->hiddenLabel()
                ->schema([
                    MediaInfolistPresenter::cover(),
                    MediaInfolistPresenter::title(),
                    MediaInfolistPresenter::kind(),
                    MediaInfolistPresenter::description(),

                    MediaInfolistPresenter::divider(),
                    MediaInfolistPresenter::department(),
                    MediaInfolistPresenter::audience(),
                    MediaInfolistPresenter::user(),
                    MediaInfolistPresenter::duration(),

                    MediaInfolistPresenter::divider(),
                    MediaInfolistPresenter::active(),
                    MediaInfolistPresenter::pinned(),

                    MediaInfolistPresenter::divider(),
                    MediaInfolistPresenter::reportDate(),
                    MediaInfolistPresenter::expiresAt(),
                    MediaInfolistPresenter::createdAt(),
                    MediaInfolistPresenter::updatedAt(),
                ])
                ->columnSpanFull()
                ->columns(2),
        ]);
    }

    public static function getGlobalSearchResultActions(Model $record): array
    {
        return [
            Action::make('edit')
                ->icon('heroicon-m-pencil')
                ->url(static::getUrl('edit', ['record' => $record])),
        ];
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            __('resources/media/strings.table.parent') => $record->parent?->title ?? '-',
        ];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return $record->title;
    }

    public static function getGlobalSearchResultUrl(Model $record): string
    {
        return static::getUrl('edit', ['record' => $record]);
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['title', 'topic', 'description'];
    }

    public static function getModelLabel(): string
    {
        return __('resources/media/strings.label');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('resources/report/strings.nav_group');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListMedia::route('/'),
            'create' => CreateMedia::route('/create'),
            'edit' => EditMedia::route('/{record}/edit'),
        ];
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/media/strings.plural_label');
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->withCount('episodes'))
            ->columns([
                MediaTablePresenter::id(),
                MediaTablePresenter::title(),
                MediaTablePresenter::kind(),
                MediaTablePresenter::parent(),
                MediaTablePresenter::duration(),
                MediaTablePresenter::icon(),
                MediaTablePresenter::department(),
                MediaTablePresenter::audience(),
                MediaTablePresenter::user(),
                self::mediaActiveColumn(),
                MediaTablePresenter::pinned(),
                MediaTablePresenter::reportDate(),
                MediaTablePresenter::createdAt(),
            ])
            ->groups([
                MediaTablePresenter::activeGroup(),
                MediaTablePresenter::departmentGroup(),
                MediaTablePresenter::pinnedGroup(),
                MediaTablePresenter::kindGroup(),
            ])
            ->filters([
                MediaTablePresenter::activeFilter(),
                MediaTablePresenter::departmentFilter(),
                MediaTablePresenter::visibilityFilter(),
                MediaTablePresenter::pinnedFilter(),
                MediaTablePresenter::reportDateRangeFilter(),
                self::createdAtFilter(),
                MediaTablePresenter::kindFilter(),
                MediaTablePresenter::rootFilter(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                self::viewAction(),
                self::editAction(),
                self::deleteAction()->modalDescription(__('resources/media/strings.table.delete_series')),
            ], RecordActionsPosition::AfterCells)
            ->groupedBulkActions([
                static::bulkDeleteAction()->modalDescription(__('resources/media/strings.table.delete_series')),
                MediaTablePresenter::shareWithDepartmentsBulkAction('resources/media/strings.bulk'),
                ...self::bulkVisibilityActions(),
            ])
            ->emptyStateIcon('heroicon-o-play-circle')
            ->defaultSort('created_at', 'desc')
            ->striped();
    }
}
