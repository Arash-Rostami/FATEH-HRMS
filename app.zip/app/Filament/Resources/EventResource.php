<?php

namespace App\Filament\Resources;

use App\Filament\Resources\EventResource\Exports\EventExporter;
use App\Filament\Resources\EventResource\RelationManagers\EventSharesRelationManager;
use App\Traits\Filament\AuthorizesByPermission;
use App\Filament\Resources\EventResource\Pages\{CreateEvent, EditEvent, ListEvents};
use App\Filament\Resources\EventResource\Schemas\{EventFormPresenter, EventInfolistPresenter, EventTablePresenter};
use App\Models\Event;
use App\Traits\Filament\{FilamentActions, FilamentAdminGuide};
use BackedEnum;
use Filament\Actions\Action;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Group;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class EventResource extends Resource
{
    use FilamentActions, FilamentAdminGuide, AuthorizesByPermission;

    protected static ?string $model = Event::class;
    protected static ?string $slug = 'calendar-events';
    protected static ?string $recordTitleAttribute = 'title';
    protected static string|null|BackedEnum $navigationIcon = 'heroicon-o-calendar-days';
    protected static ?int $navigationSort = 3;

    protected static array $guide = [
        ['label' => 'بررسی', 'icon' => 'calendar_month', 'view' => 'filament.resources.event.guide.overview'],
        ['label' => 'شمارش معکوس', 'icon' => 'hourglass_top', 'view' => 'filament.resources.event.guide.countdown'],
        ['label' => 'فهرست و فیلترها', 'icon' => 'filter_list', 'view' => 'filament.resources.event.guide.list-tabs'],
        ['label' => 'کارهای مدیریتی', 'icon' => 'admin_panel_settings', 'view' => 'filament.resources.event.guide.admin-ops'],
        ['label' => 'تجربهٔ کاربر', 'icon' => 'visibility', 'view' => 'filament.resources.event.guide.user'],
    ];

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Group::make()
                ->columnSpanFull()
                ->columns(2)
                ->schema([

                    Group::make()
                        ->columnSpan(1)
                        ->schema([
                            Section::make(__('resources/event/strings.form.section_info'))
                                ->icon('heroicon-o-document-text')
                                ->schema([
                                    EventFormPresenter::title(),
                                    EventFormPresenter::divider(),
                                    EventFormPresenter::description(),
                                ]),

                            Section::make(__('resources/event/strings.form.section_schedule'))
                                ->icon('heroicon-o-calendar')
                                ->schema([
                                    EventFormPresenter::dateJalali(),
                                    EventFormPresenter::dateTimePart(),
                                ])
                                ->columns(3),
                        ]),

                    Group::make()
                        ->columnSpan(1)
                        ->schema([
                            Section::make(__('resources/event/strings.form.section_access'))
                                ->icon('heroicon-o-lock-closed')
                                ->schema([
                                    EventFormPresenter::private(),
                                    EventFormPresenter::userId(),
                                    EventFormPresenter::remindHours(),
                                ])
                                ->columns(1),

                            Section::make(__('resources/event/strings.form.section_countdown'))
                                ->icon('heroicon-o-clock')
                                ->description(__('resources/event/strings.form.section_countdown_description'))
                                ->visible(fn (Get $get) => ! (bool) $get('private'))
                                ->schema([
                                    Grid::make(2)->schema([
                                        EventFormPresenter::countdownEnabled(),
                                        EventFormPresenter::countdownConfetti(),
                                    ]),
                                    EventFormPresenter::countdownMood(),
                                    EventFormPresenter::countdownMessages(),
                                ]),
                        ]),
                ]),
        ]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->with('user');
    }

    public static function getGlobalSearchResultActions(Model $record): array
    {
        return [
            Action::make('edit')
                ->icon('heroicon-m-pencil')
                ->url(static::getUrl('edit', ['record' => $record])),
        ];
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            __('resources/event/strings.fields.user') => $record->user?->name ?? '—',
            __('resources/event/strings.fields.date') => toJalaliSmart($record->date),
        ];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return $record->title;
    }

    public static function getGlobalSearchResultUrl(Model $record): string
    {
        return static::getUrl('edit', ['record' => $record]);
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['title', 'description', 'user.name'];
    }

    public static function getModelLabel(): string
    {
        return __('resources/event/strings.label');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('resources/event/strings.nav_group');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListEvents::route('/'),
            'create' => CreateEvent::route('/create'),
            'edit' => EditEvent::route('/{record}/edit'),
        ];
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/event/strings.plural_label');
    }

    public static function getRelations(): array
    {
        return [
            EventSharesRelationManager::class,
        ];
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()
                ->extraAttributes(['class' => 'fi-infolist-panel'])
                ->hiddenLabel()
                ->schema([
                    EventInfolistPresenter::date(),
                    EventInfolistPresenter::user(),
                    EventInfolistPresenter::private(),
                    EventInfolistPresenter::remindHours(),
                    EventInfolistPresenter::countdown(),

                    EventInfolistPresenter::divider(),
                    EventInfolistPresenter::title(),
                    EventInfolistPresenter::description(),

                    EventInfolistPresenter::divider(),
                    EventInfolistPresenter::createdAt(),
                    EventInfolistPresenter::updatedAt(),
                ])
                ->columnSpanFull()
                ->columns(3),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                EventTablePresenter::id(),
                EventTablePresenter::title(),
                EventTablePresenter::user(),
                EventTablePresenter::date(),
                EventTablePresenter::private(),
                EventTablePresenter::countdown(),
                EventTablePresenter::createdAt(),
            ])
            ->groups([
                EventTablePresenter::visibilityGroup(),
            ])
            ->filters([
                EventTablePresenter::userFilter(),
                EventTablePresenter::visibilityFilter(),
                EventTablePresenter::upcomingFilter(),
                EventTablePresenter::dateRangeFilter(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                self::viewAction(),
                self::editAction(),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells)
            ->groupedBulkActions(self::bulkActions(EventExporter::class))
            ->emptyStateIcon('heroicon-o-bookmark')
            ->defaultSort('date', 'desc')
            ->striped();
    }
}
