<?php

namespace App\Filament\Resources\UserResource\Schemas;

use App\Enums\PresenceStatus;
use App\Filament\Resources\UserResource;
use App\Enums\UserRole;
use App\Enums\UserStatus;
use App\Enums\UserType;
use App\Models\User;
use App\Services\ProjectTask\TasksheetShareService;
use Filament\Actions\Action;
use Filament\Actions\BulkAction;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Select;
use Filament\Notifications\Notification;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Tables\Grouping\Group;
use Filament\Support\Enums\Width;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;
use Illuminate\Validation\ValidationException;

class UserTablePresenter
{
    public static function avatar(): ImageColumn
    {
        return ImageColumn::make('profile_image')
            ->label(__('resources/user/strings.table.avatar'))
            ->getStateUsing(fn(User $record): ?string => $record->getProfileImageUrl())
            ->circular()
            ->imageSize(40)
            ->defaultImageUrl(fn(User $record): string => $record->getInitialsAvatarUrl())
            ->toggleable(isToggledHiddenByDefault: false);
    }

    public static function bulkDeactivateAction(): BulkAction
    {
        return BulkAction::make('bulk_deactivate')
            ->label('غیرفعال‌سازی گروهی')
            ->icon('heroicon-m-user-minus')
            ->color('danger')
            ->visible(fn() => UserResource::canEditAny())
            ->requiresConfirmation()
            ->modalHeading('غیرفعال‌سازی گروهی کاربران')
            ->modalDescription('حساب کاربران انتخاب‌شده غیرفعال می‌شود و دیگر نمی‌توانند وارد سامانه شوند. پیام‌ها، گزارش‌ها و رزروهای قبلی آن‌ها باقی می‌مانند. حساب خودتان غیرفعال نمی‌شود.')
            ->deselectRecordsAfterCompletion()
            ->action(function (Collection $records) {
                $targets = $records->reject(fn($record) => $record->id === auth()->id());

                if ($targets->isEmpty()) {
                    return;
                }

                $skipped = [];

                foreach ($targets as $record) {
                    try {
                        $record->forceFill(['status' => UserStatus::Inactive->value])->save();
                    } catch (ValidationException $e) {
                        $skipped[] = $record->name . ': ' . collect($e->errors())->flatten()->first();
                    }
                }

                Notification::make()
                    ->title('تعداد غیرفعال‌شده: ' . ($targets->count() - count($skipped)))
                    ->success()
                    ->send();

                if ($skipped) {
                    Notification::make()
                        ->title('این کاربران غیرفعال نشدند')
                        ->body(implode("\n", $skipped))
                        ->warning()
                        ->send();
                }
            });
    }

    public static function createdAt(): TextColumn
    {
        return TextColumn::make('created_at')
            ->label(__('resources/user/strings.table.created_at'))
            ->formatStateUsing(fn($state) => $state ? toJalali($state, 'Y/m/d') : '-')
            ->sortable()
            ->toggleable(isToggledHiddenByDefault: true)
            ->color('zinc');
    }

    public static function email(): TextColumn
    {
        return TextColumn::make('email')
            ->label(__('resources/user/strings.table.email'))
            ->sortable()
            ->searchable()
            ->copyable()
            ->toggleable(isToggledHiddenByDefault: true)
            ->color('info');
    }

    public static function id(): TextColumn
    {
        return TextColumn::make('id')
            ->label(__('resources/user/strings.table.id'))
            ->sortable()
            ->toggleable(isToggledHiddenByDefault: false)
            ->color('zinc');
    }

    public static function lastSeen(): TextColumn
    {
        return TextColumn::make('last_seen')
            ->label(__('resources/user/strings.table.last_seen'))
            ->formatStateUsing(fn($state) => $state ? toJalaliRelative($state) : '—')
            ->sortable()
            ->placeholder('-')
            ->toggleable(isToggledHiddenByDefault: true)
            ->color(fn(User $record): string => $record->isOnline() ? 'success' : 'gray');
    }

    public static function name(): TextColumn
    {
        return TextColumn::make('name')
            ->label(__('resources/user/strings.table.name'))
            ->sortable()
            ->searchable()
            ->extraAttributes(['dir' => 'auto', 'style' => 'unicode-bidi: isolate;'])
            ->toggleable(isToggledHiddenByDefault: false)
            ->color('primary');
    }

    public static function presence(): TextColumn
    {
        return TextColumn::make('presence')
            ->label(__('resources/user/strings.table.presence'))
            ->badge()
            ->formatStateUsing(fn($state): string => $state instanceof PresenceStatus ? $state->label() : ($state ?? '-'))
            ->color(fn($state): string => $state instanceof PresenceStatus ? $state->color() : 'info')
            ->icon(fn(User $record): ?string => $record->isFocusing() ? 'heroicon-o-clock' : null)
            ->tooltip(fn(User $record): ?string => $record->focusLabel())
            ->toggleable(isToggledHiddenByDefault: true);
    }

    public static function presenceFilter(): SelectFilter
    {
        return SelectFilter::make('presence')
            ->label(__('resources/user/strings.table.filter_presence'))
            ->options(
                collect(PresenceStatus::cases())
                    ->mapWithKeys(fn(PresenceStatus $c) => [$c->value => $c->label()])
            );
    }

    public static function presenceGroup(): Group
    {
        return Group::make('presence')
            ->label(__('resources/user/strings.table.filter_presence'))
            ->getTitleFromRecordUsing(fn(User $record): string => $record->presence instanceof PresenceStatus ? $record->presence->label() : ($record->presence ?? '-'))
            ->collapsible();
    }

    public static function role(): TextColumn
    {
        return TextColumn::make('role')
            ->label(__('resources/user/strings.table.role'))
            ->badge()
            ->formatStateUsing(fn(string $state): string => UserRole::tryFrom($state)?->getLabel() ?? $state)
            ->color(fn(string $state): string => UserRole::tryFrom($state)?->getColor() ?? 'gray')
            ->icon(fn(string $state): string => UserRole::tryFrom($state)?->getIcon() ?? '')
            ->sortable()
            ->toggleable(isToggledHiddenByDefault: true);
    }

    public static function roleFilter(): SelectFilter
    {
        return SelectFilter::make('role')
            ->label(__('resources/user/strings.table.filter_role'))
            ->options(UserRole::class);
    }

    public static function roleGroup(): Group
    {
        return Group::make('role')
            ->label(__('resources/user/strings.table.filter_role'))
            ->getTitleFromRecordUsing(fn(User $record): string => UserRole::tryFrom($record->role)?->getLabel() ?? $record->role ?? '-')
            ->collapsible();
    }

    public static function status(): TextColumn
    {
        return TextColumn::make('status')
            ->label(__('resources/user/strings.table.status'))
            ->badge()
            ->formatStateUsing(fn(string $state): string => UserStatus::tryFrom($state)?->getLabel() ?? $state)
            ->color(fn(string $state): string => UserStatus::tryFrom($state)?->getColor() ?? 'gray')
            ->icon(fn(string $state): string => UserStatus::tryFrom($state)?->getIcon() ?? '')
            ->sortable()
            ->toggleable(isToggledHiddenByDefault: false);
    }

    public static function statusFilter(): SelectFilter
    {
        return SelectFilter::make('status')
            ->label(__('resources/user/strings.table.filter_status'))
            ->options(UserStatus::class);
    }

    public static function statusGroup(): Group
    {
        return Group::make('status')
            ->label(__('resources/user/strings.table.filter_status'))
            ->getTitleFromRecordUsing(fn(User $record): string => UserStatus::tryFrom($record->status)?->getLabel() ?? $record->status ?? '-')
            ->collapsible();
    }

    public static function type(): TextColumn
    {
        return TextColumn::make('type')
            ->label(__('resources/user/strings.table.type'))
            ->badge()
            ->formatStateUsing(fn(string $state): string => UserType::tryFrom($state)?->getLabel() ?? $state)
            ->color(fn(string $state): string => UserType::tryFrom($state)?->getColor() ?? 'gray')
            ->icon(fn(string $state): string => UserType::tryFrom($state)?->getIcon() ?? '')
            ->sortable()
            ->toggleable(isToggledHiddenByDefault: true);
    }

    public static function typeFilter(): SelectFilter
    {
        return SelectFilter::make('type')
            ->label(__('resources/user/strings.table.filter_type'))
            ->options(UserType::class);
    }

    public static function shareTasksheet(): Action
    {
        return Action::make('shareTasksheet')
            ->label('اشتراک‌گذاری تسک‌شیت')
            ->visible(fn () => !tenantOff('tasksheet'))
            ->icon('heroicon-o-share')
            ->iconButton()
            ->modalWidth(Width::Small)
            ->modalSubmitActionLabel('ارسال')
            ->form(function (?Model $record) {
                $boss = $record ? TasksheetShareService::managerFor($record) : null;

                return [
                    Radio::make('target')
                        ->label('گیرنده')
                        ->options([
                            'boss' => $boss && $boss->id === $record->id
                                ? 'مدیر سازمانی (همان فرد است؛ «کاربر دیگر» را انتخاب کنید)'
                                : 'مدیر سازمانی',
                            'other' => 'کاربر دیگر',
                        ])
                        ->helperText('گیرنده پیوند گزارش این ماه را در اعلان‌ها می‌بیند. پیوند ۷ روز اعتبار دارد. اگر «مدیر سازمانی» را انتخاب کنید، گیرنده بر اساس ساختار واحدها تعیین می‌شود.')
                        ->default('boss')
                        ->live()
                        ->columnSpanFull(),
                    Select::make('recipient')
                        ->label('گیرندهٔ گزارش')
                        ->options(fn () => User::getCachedActiveOptions()
                            ->except($record?->id ?? 0)
                            ->except($boss?->id ?? 0)
                            ->all())
                        ->visible(fn (Get $get) => $get('target') === 'other')
                        ->searchable()
                        ->preload()
                        ->required(),
                ];
            })
            ->action(function (User $record, array $data) {
                if (($data['target'] ?? 'boss') === 'boss') {
                    $recipient = TasksheetShareService::managerFor($record);

                    if (!$recipient) {
                        Notification::make()
                            ->title('مدیر سازمانی پیدا نشد. «کاربر دیگر» را انتخاب کنید.')
                            ->warning()
                            ->send();

                        return;
                    }

                    if ($recipient->is($record)) {
                        Notification::make()
                            ->title('گیرنده همان صاحب گزارش است. فرد دیگری را انتخاب کنید.')
                            ->warning()
                            ->send();

                        return;
                    }
                } else {
                    $recipient = User::visibleOnBoard()->find($data['recipient'] ?? 0);

                    if (!$recipient) {
                        Notification::make()
                            ->title('گیرندهٔ انتخاب‌شده معتبر نیست.')
                            ->warning()
                            ->send();

                        return;
                    }
                }

                $result = app(TasksheetShareService::class)
                    ->shareWithManager($record, $recipient, requestedBy: auth()->user());

                Notification::make()
                    ->title($result['message'])
                    ->{$result['success'] ? 'success' : 'warning'}()
                    ->send();
            });
    }

    public static function toggleStatusAction(): Action
    {
        return Action::make('toggleStatus')
            ->tooltip(fn(User $record) => $record->status === UserStatus::Active->value ? 'غیرفعال‌سازی' : 'فعال‌سازی')
            ->icon(fn(User $record) => $record->status === UserStatus::Active->value ? 'heroicon-o-user-minus' : 'heroicon-o-user-plus')
            ->color(fn(User $record) => $record->status === UserStatus::Active->value ? 'danger' : 'success')
            ->iconButton()
            ->visible(fn(User $record) => $record->id !== auth()->id()
                && in_array($record->status, [UserStatus::Active->value, UserStatus::Inactive->value])
                && UserResource::canEdit($record))
            ->requiresConfirmation()
            ->modalHeading(fn(User $record) => $record->status === UserStatus::Active->value ? 'غیرفعال‌سازی کاربر' : 'فعال‌سازی کاربر')
            ->modalDescription(fn(User $record) => $record->status === UserStatus::Active->value
                ? 'کاربر از داشبورد و فهرست‌ها حذف می‌شود و دیگر نمی‌تواند وارد شود؛ سوابقش (پیام‌ها، گزارش‌ها، رزروها) دست‌نخورده می‌ماند.'
                : 'کاربر دوباره می‌تواند وارد شود و در داشبورد و فهرست‌ها ظاهر می‌شود.')
            ->action(function (User $record) {
                try {
                    $record->forceFill([
                        'status' => $record->status === UserStatus::Active->value
                            ? UserStatus::Inactive->value
                            : UserStatus::Active->value,
                    ])->save();
                } catch (ValidationException $e) {
                    Notification::make()
                        ->title(collect($e->errors())->flatten()->first())
                        ->danger()
                        ->send();

                    return;
                }

                Notification::make()
                    ->title($record->status === UserStatus::Active->value ? 'کاربر فعال شد' : 'کاربر غیرفعال شد')
                    ->success()
                    ->send();
            });
    }
}
