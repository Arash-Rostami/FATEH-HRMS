<?php
namespace App\Filament\Resources\UserResource\Schemas;

use App\Enums\PresenceStatus;
use App\Enums\UserRole;
use App\Enums\UserStatus;
use App\Enums\UserType;
use App\Models\User;
use App\Traits\Filament\FilamentFormDivider;
use Filament\Infolists\Components\IconEntry;
use Filament\Infolists\Components\RepeatableEntry;
use Filament\Infolists\Components\TextEntry;
use Filament\Support\Enums\IconPosition;

class UserInfolistPresenter
{
    use FilamentFormDivider;

    public static function id(): TextEntry
    {
        return TextEntry::make('id')
            ->label(__('resources/user/strings.infolist.id'))
            ->badge()
            ->icon('heroicon-o-hashtag')
            ->copyable()
            ->color('zinc');
    }

    public static function name(): TextEntry
    {
        return TextEntry::make('name')
            ->label(__('resources/user/strings.infolist.name'))
            ->extraAttributes(['dir' => 'auto', 'style' => 'unicode-bidi: isolate;'])
            ->weight('bold')
            ->badge()
            ->color('primary');
    }

    public static function email(): TextEntry
    {
        return TextEntry::make('email')
            ->label(__('resources/user/strings.infolist.email'))
            ->copyable()
            ->icon('heroicon-o-envelope')
            ->color('info');
    }

    public static function emailVerifiedAt(): TextEntry
    {
        return TextEntry::make('email_verified_at')
            ->label(__('resources/user/strings.infolist.email_verified_at'))
            ->formatStateUsing(fn ($state) => $state ? toJalali($state, 'Y/m/d') : '-')
            ->extraAttributes(['dir' => 'ltr', 'style' => 'unicode-bidi: isolate;'])
            ->alignRight()
            ->iconPosition(IconPosition::After)
            ->placeholder('تأیید نشده')
            ->icon('heroicon-o-check-badge')
            ->color(fn ($state) => $state ? 'success' : 'danger');
    }

    public static function type(): TextEntry
    {
        return TextEntry::make('type')
            ->label(__('resources/user/strings.infolist.type'))
            ->badge()
            ->formatStateUsing(fn (string $state): string => UserType::tryFrom($state)?->getLabel() ?? $state)
            ->color(fn (string $state): string => UserType::tryFrom($state)?->getColor() ?? 'gray')
            ->icon(fn (string $state): string => UserType::tryFrom($state)?->getIcon() ?? '');
    }

    public static function role(): TextEntry
    {
        return TextEntry::make('role')
            ->label(__('resources/user/strings.infolist.role'))
            ->badge()
            ->formatStateUsing(fn (string $state): string => UserRole::tryFrom($state)?->getLabel() ?? $state)
            ->color(fn (string $state): string => UserRole::tryFrom($state)?->getColor() ?? 'gray')
            ->icon(fn (string $state): string => UserRole::tryFrom($state)?->getIcon() ?? '');
    }

    public static function status(): TextEntry
    {
        return TextEntry::make('status')
            ->label(__('resources/user/strings.infolist.status'))
            ->badge()
            ->formatStateUsing(fn (string $state): string => UserStatus::tryFrom($state)?->getLabel() ?? $state)
            ->color(fn (string $state): string => UserStatus::tryFrom($state)?->getColor() ?? 'gray')
            ->icon(fn (string $state): string => UserStatus::tryFrom($state)?->getIcon() ?? '');
    }

    public static function presence(): TextEntry
    {
        return TextEntry::make('presence')
            ->label(__('resources/user/strings.infolist.presence'))
            ->badge()
            ->formatStateUsing(fn ($state): string => $state instanceof PresenceStatus ? $state->label() : ($state ?? '-'))
            ->color(fn ($state): string => $state instanceof PresenceStatus ? $state->color() : 'info')
            ->icon(fn (User $record): ?string => $record->isFocusing() ? 'heroicon-o-clock' : null)
            ->tooltip(fn (User $record): ?string => $record->focusLabel());
    }

    public static function booking(): RepeatableEntry
    {
        return RepeatableEntry::make('booking')
            ->label(__('resources/user/strings.infolist.booking'))
            ->schema([
                TextEntry::make('key')
                    ->label(__('resources/user/strings.infolist.booking_key'))
                    ->weight('medium')
                    ->color('slate'),
                IconEntry::make('value')
                    ->label(__('resources/user/strings.infolist.booking_value'))
                    ->boolean()
                    ->color(fn ($state) => $state ? 'success' : 'gray'),
                TextEntry::make('max')
                    ->label(__('resources/user/strings.infolist.booking_max'))
                    ->placeholder('—')
                    ->numeric(),
            ])
            ->columns(3)
            ->grid(2)
            ->getStateUsing(fn ($record): array =>
            collect($record->booking ?? [])
                ->map(fn ($v, $k) => ['key' => $k, 'value' => (bool) $v, 'max' => $record->bookingMax($k)])
                ->values()
                ->toArray()
            )
            ->columnSpanFull();
    }

    public static function extra(): RepeatableEntry
    {
        return RepeatableEntry::make('extra')
            ->label(__('resources/user/strings.infolist.extra'))
            ->schema([
                TextEntry::make('key')
                    ->label(__('resources/user/strings.infolist.extra_key'))
                    ->weight('medium')
                    ->color('slate'),
                TextEntry::make('value')
                    ->label(__('resources/user/strings.infolist.extra_value'))
                    ->extraAttributes(['dir' => 'auto', 'style' => 'white-space: pre-wrap; unicode-bidi: isolate;'])
                    ->placeholder('-')
                    ->color('zinc'),
            ])
            ->columns(2)
            ->getStateUsing(fn ($record): array =>
            collect($record->extra['admin'] ?? [])
                ->except(User::PROTECTED_ADMIN_KEYS)
                ->map(fn ($v, $k) => ['key' => $k, 'value' => (string) $v])
                ->values()
                ->toArray()
            )
            ->columnSpanFull();
    }

    public static function lastSeen(): TextEntry
    {
        return TextEntry::make('last_seen')
            ->label(__('resources/user/strings.infolist.last_seen'))
            ->formatStateUsing(fn ($state) => $state ? toJalaliRelative($state) : '—')
            ->icon('heroicon-o-eye')
            ->placeholder('-')
            ->color('sky');
    }

    public static function createdAt(): TextEntry
    {
        return TextEntry::make('created_at')
            ->label(__('resources/user/strings.infolist.created_at'))
            ->formatStateUsing(fn ($state) => $state ? toJalali($state, 'Y/m/d') : '-')
            ->extraAttributes(['dir' => 'ltr', 'style' => 'unicode-bidi: isolate;'])
            ->alignRight()
            ->iconPosition(IconPosition::After)
            ->icon('heroicon-o-clock')
            ->color('zinc');
    }

    public static function updatedAt(): TextEntry
    {
        return TextEntry::make('updated_at')
            ->label(__('resources/user/strings.infolist.updated_at'))
            ->formatStateUsing(fn ($state) => $state ? toJalali($state, 'Y/m/d') : '-')
            ->extraAttributes(['dir' => 'ltr', 'style' => 'unicode-bidi: isolate;'])
            ->alignRight()
            ->iconPosition(IconPosition::After)
            ->icon('heroicon-o-arrow-path')
            ->color('zinc');
    }
}
