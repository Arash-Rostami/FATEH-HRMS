<?php

namespace App\Filament\Resources\TaskResource\Pages;

use App\Filament\Resources\TaskResource;
use App\Enums\TaskStatus;
use App\Models\Task;
use App\Services\ProjectTask\TaskMetrics;
use App\Traits\Filament\FilamentHeaderActions;
use App\Filament\Pages\ListRecords;
use Filament\Schemas\Components\Tabs\Tab;
use Illuminate\Database\Eloquent\Builder;

class ListTasks extends ListRecords
{
    use FilamentHeaderActions;

    protected static string $resource = TaskResource::class;

    public function getTabs(): array
    {
        if (!(auth()->user()?->getPreference('show_list_tabs', true) ?? true)) {
            return [];
        }

        return [
            'all' => Tab::make(__('resources/task/strings.tabs.all'))
                ->icon('heroicon-o-list-bullet'),

            'todo' => Tab::make(__('resources/task/strings.tabs.todo'))
                ->icon('heroicon-o-clock')
                ->badge(fn() => $this->getStats()->todo_count ?: null)
                ->badgeColor('gray')
                ->modifyQueryUsing(
                    fn(Builder $query) => $query->where('status', TaskStatus::Todo->value)
                ),

            'in_progress' => Tab::make(__('resources/task/strings.tabs.in_progress'))
                ->icon('heroicon-o-arrow-path')
                ->badge(fn() => $this->getStats()->in_progress_count ?: null)
                ->badgeColor('warning')
                ->modifyQueryUsing(
                    fn(Builder $query) => $query->where('status', TaskStatus::InProgress->value)
                ),

            'pending' => Tab::make(__('resources/task/strings.tabs.pending'))
                ->icon('heroicon-o-pause-circle')
                ->badge(fn() => $this->getStats()->pending_count ?: null)
                ->badgeColor('danger')
                ->modifyQueryUsing(
                    fn(Builder $query) => $query->where('status', TaskStatus::Pending->value)
                ),

            'done' => Tab::make(__('resources/task/strings.tabs.done'))
                ->icon('heroicon-o-check-circle')
                ->modifyQueryUsing(
                    fn(Builder $query) => $query->where('status', TaskStatus::Done->value)
                ),

            'overdue' => Tab::make(__('resources/task/strings.tabs.overdue'))
                ->icon('heroicon-o-exclamation-triangle')
                ->badge(fn() => $this->getStats()->overdue_count ?: null)
                ->badgeColor('danger')
                ->modifyQueryUsing(
                    fn(Builder $query) => TaskMetrics::overdue($query)
                ),

            'delegated' => Tab::make(__('resources/task/strings.tabs.delegated'))
                ->icon('heroicon-o-arrow-right-on-rectangle')
                ->modifyQueryUsing(
                    fn(Builder $query) => $query
                        ->whereNotNull('assigned_to')
                        ->whereColumn('assigned_to', '!=', 'user_id')
                ),

            'trashed' => Tab::make(__('resources/task/strings.tabs.trashed'))
                ->icon('heroicon-o-trash')
                ->badge(fn() => $this->getStats()->trashed_count ?: null)
                ->badgeColor('danger')
                ->modifyQueryUsing(
                    fn(Builder $query) => $query->onlyTrashed()
                ),
        ];
    }

    private function getStats(): object
    {
        return once(function () {
            $stats = Task::query()
                ->withTrashed()
                ->selectRaw("
            SUM(CASE WHEN status = ? AND deleted_at IS NULL THEN 1 ELSE 0 END) AS todo_count,
            SUM(CASE WHEN status = ? AND deleted_at IS NULL THEN 1 ELSE 0 END) AS in_progress_count,
            SUM(CASE WHEN status = ? AND deleted_at IS NULL THEN 1 ELSE 0 END) AS pending_count,
            SUM(CASE WHEN deleted_at IS NOT NULL THEN 1 ELSE 0 END) AS trashed_count
        ", [
                    TaskStatus::Todo->value,
                    TaskStatus::InProgress->value,
                    TaskStatus::Pending->value,
                ])
                ->first();

            $stats->overdue_count = TaskMetrics::overdue(Task::query())->count();

            return $stats;
        });
    }
}
