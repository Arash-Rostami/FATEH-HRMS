<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ChannelResource\Exports\ChannelExporter;
use App\Filament\Resources\ChannelResource\Pages\{CreateChannel, EditChannel, ListChannels};
use App\Filament\Resources\ChannelResource\RelationManagers\{ChannelMembersRelationManager, ChannelMessagesRelationManager};
use App\Filament\Resources\ChannelResource\Schemas\{ChannelFormPresenter, ChannelInfolistPresenter, ChannelTablePresenter};
use App\Filament\Pages\UnlockModules;
use App\Models\Channel;
use App\Models\Project;
use App\Support\LockPolicy;
use App\Traits\Filament\AuthorizesByPermission;
use App\Traits\Filament\FilamentActions;
use App\Traits\Filament\FilamentAdminGuide;
use App\Traits\Filament\FilamentFilters;
use Filament\Actions\Action;
use Filament\Actions\DeleteBulkAction;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class ChannelResource extends Resource
{
    use FilamentAdminGuide, FilamentActions, FilamentFilters, AuthorizesByPermission;

    protected static ?string $model = Channel::class;
    protected static ?string $recordTitleAttribute = 'name';
    protected static string|null|\BackedEnum $navigationIcon = 'heroicon-o-chat-bubble-left-right';
    protected static ?int $navigationSort = 8;

    protected static array $guide = [
        ['label' => 'بررسی', 'icon' => 'menu_book', 'view' => 'filament.resources.channel.guide.overview'],
        ['label' => 'نوع و دسترسی', 'icon' => 'lock', 'view' => 'filament.resources.channel.guide.type-access'],
        ['label' => 'کارهای مدیریتی', 'icon' => 'admin_panel_settings', 'view' => 'filament.resources.channel.guide.admin-ops'],
        ['label' => 'تجربهٔ کاربر', 'icon' => 'visibility', 'view' => 'filament.resources.channel.guide.user'],
    ];

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make(__('resources/channel/strings.form.section_meta'))
                ->icon('heroicon-o-chat-bubble-left-right')
                ->schema([
                    ChannelFormPresenter::name(),
                    ChannelFormPresenter::slug(),
                    ChannelFormPresenter::type(),
                    ChannelFormPresenter::owner(),
                ])
                ->columns(2),

            Section::make(__('resources/channel/strings.form.section_content'))
                ->icon('heroicon-o-document-text')
                ->schema([
                    ChannelFormPresenter::description(),
                ])
                ->columns(1),
        ]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->withoutGlobalScopes([SoftDeletingScope::class])
            ->with(['owner'])
            ->withCount(['members', 'messages']);
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            __('resources/channel/strings.fields.type') => $record->type?->getLabel() ?? '—',
            __('resources/channel/strings.fields.owner') => $record->owner?->name ?? '—',
        ];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return $record->name ?? '';
    }

    public static function getGlobalSearchResultUrl(Model $record): ?string
    {
        return LockPolicy::blocksRecord(static::moduleKey(), $record) ? null : static::getUrl('edit', ['record' => $record]);
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['name', 'slug', 'description'];
    }

    public static function getModelLabel(): string
    {
        return __('resources/channel/strings.label');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('resources/channel/strings.nav_group');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListChannels::route('/'),
            'create' => CreateChannel::route('/create'),
            'edit' => EditChannel::route('/{record}/edit'),
        ];
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/channel/strings.plural_label');
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()
                ->extraAttributes(['class' => 'fi-infolist-panel'])
                ->hiddenLabel()
                ->schema([
                    ChannelInfolistPresenter::name(),
                    ChannelInfolistPresenter::slug(),
                    ChannelInfolistPresenter::type(),
                    ChannelInfolistPresenter::owner(),
                    ChannelInfolistPresenter::membersCount(),
                    ChannelInfolistPresenter::messagesCount(),

                    ChannelInfolistPresenter::divider(),
                    ChannelInfolistPresenter::description(),

                    ChannelInfolistPresenter::divider(),
                    ChannelInfolistPresenter::createdAt(),
                    ChannelInfolistPresenter::updatedAt(),
                    ChannelInfolistPresenter::deletedAt(),
                    ChannelInfolistPresenter::prunableWarning(),
                ])
                ->columnSpanFull()
                ->columns(3),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                ChannelTablePresenter::id(),
                ChannelTablePresenter::name(),
                ChannelTablePresenter::slug(),
                ChannelTablePresenter::type(),
                ChannelTablePresenter::membersCount(),
                ChannelTablePresenter::messagesCount(),
                ChannelTablePresenter::createdAt(),
                ChannelTablePresenter::deletedAt(),
                ChannelTablePresenter::prunableWarning(),
            ])
            ->groups([
                ChannelTablePresenter::typeGroup(),
            ])
            ->filters([
                ChannelTablePresenter::typeFilter(),
                ChannelTablePresenter::pruningSoonFilter(),
                self::createdAtFilter(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                self::unlockAction(),
                self::viewAction(),
                self::editAction(),
                self::restoreAction(),
                self::deleteAction()->visible(fn($record) => !$record->trashed() && !in_array($record->id, self::projectChannelIds(), true)),
            ], RecordActionsPosition::AfterCells)
            ->groupedBulkActions(array_map(
                fn($action) => $action instanceof DeleteBulkAction ? $action->authorizeIndividualRecords() : $action,
                self::bulkActions(ChannelExporter::class),
            ))
            ->emptyStateIcon('heroicon-o-bookmark')
            ->defaultSort('created_at', 'desc')
            ->striped();
    }

    private static function unlockAction(): Action
    {
        return Action::make('unlock')
            ->label(__('resources/lock/strings.unlock.action'))
            ->icon('heroicon-m-lock-closed')
            ->iconButton()
            ->color('warning')
            ->visible(fn(Model $record): bool => LockPolicy::blocksRecord(self::moduleKey(), $record))
            ->url(fn(Model $record): string => UnlockModules::getUrl(['record' => $record->getKey()]));
    }

    private static function projectChannelIds(): array
    {
        return once(fn() => Project::withTrashed()->whereNotNull('channel_id')->pluck('channel_id')->all());
    }

    public static function getRelations(): array
    {
        return [
            ChannelMessagesRelationManager::class,
            ChannelMembersRelationManager::class,
        ];
    }
}