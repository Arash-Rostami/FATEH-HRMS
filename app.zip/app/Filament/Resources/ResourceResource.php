<?php

namespace App\Filament\Resources;

use App\Enums\ResourceType;
use App\Filament\Resources\ResourceResource\Exports\ResourceExporter;
use App\Filament\Resources\ResourceResource\Pages\CreateResource;
use App\Filament\Resources\ResourceResource\Pages\EditResource;
use App\Filament\Resources\ResourceResource\Pages\ListResources;
use App\Filament\Resources\ResourceResource\RelationManagers\ReservationsRelationManager;
use App\Filament\Resources\ResourceResource\Schemas\ResourceFormPresenter;
use App\Filament\Resources\ResourceResource\Schemas\ResourceInfolistPresenter;
use App\Filament\Resources\ResourceResource\Schemas\ResourceTablePresenter;
use App\Models\Resource as ResourceModel;
use App\Traits\Filament\AuthorizesByPermission;
use App\Traits\Filament\FilamentActions;
use App\Traits\Filament\FilamentAdminGuide;
use App\Traits\Filament\FilamentFilters;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class ResourceResource extends Resource
{
    use FilamentAdminGuide, FilamentActions, FilamentFilters, AuthorizesByPermission;

    protected static ?string $model = ResourceModel::class;
    protected static ?string $slug = 'reservation-resources';
    protected static string|null|BackedEnum $navigationIcon = 'heroicon-o-archive-box';
    protected static ?int $navigationSort = 4;

    protected static array $guide = [
        ['label' => 'بررسی', 'icon' => 'menu_book', 'view' => 'filament.resources.resource.guide.overview'],
        ['label' => 'افزودن', 'icon' => 'add_circle', 'view' => 'filament.resources.resource.guide.adding'],
        ['label' => 'ملاقات', 'icon' => 'person', 'view' => 'filament.resources.resource.guide.meeting'],
        ['label' => 'دسترسی', 'icon' => 'key', 'view' => 'filament.resources.resource.guide.permissions'],
        ['label' => 'چک‌لیست', 'icon' => 'checklist', 'view' => 'filament.resources.resource.guide.checklist'],
    ];

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Grid::make(['default' => 1, 'lg' => 2])
                ->schema([
                    Section::make(__('resources/resource/strings.form.section_main'))
                        ->icon('heroicon-o-archive-box')
                        ->schema([
                            ResourceFormPresenter::name(),
                            Grid::make(2)->schema([
                                ResourceFormPresenter::status(),
                                ResourceFormPresenter::type(),
                            ]),
                            ResourceFormPresenter::image(),
                            ResourceFormPresenter::divider(),
                            ResourceFormPresenter::notes(),
                        ])
                        ->columns(1),
                    Section::make(__('resources/resource/strings.form.section_metadata'))
                        ->icon('heroicon-o-adjustments-horizontal')
                        ->schema([
                            ResourceFormPresenter::floor(),
                            ResourceFormPresenter::unit(),
                            ResourceFormPresenter::cardNumber(),
                            ResourceFormPresenter::extension(),
                            ResourceFormPresenter::capacity(),
                            ResourceFormPresenter::availableDays(),
                            ResourceFormPresenter::showTime(),
                            ResourceFormPresenter::timeSlotStart(),
                            ResourceFormPresenter::timeSlotEnd(),
                            ResourceFormPresenter::divider(),
                            ResourceFormPresenter::customMetadata(),
                        ])
                        ->columns(2),
                ])->columnSpanFull(),
        ]);
    }

    public static function shouldRegisterNavigation(): bool
    {
        return ! ReservationResource::canViewAny() && ! tenantOffName(static::getSlug());
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->withCount('reservations')
            ->with(['relatedUser.profile:image,user_id']);
    }

    public static function getGlobalSearchResultActions(Model $record): array
    {
        return [
            Action::make('edit')
                ->icon('heroicon-m-pencil')
                ->url(static::getUrl('edit', ['record' => $record])),
        ];
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            __('resources/resource/strings.fields.type') => ResourceType::tryFrom($record->type)?->getLabel() ?? $record->type,
        ];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return $record->name;
    }

    public static function getGlobalSearchResultUrl(Model $record): string
    {
        return static::getUrl('edit', ['record' => $record]);
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['name', 'type'];
    }

    public static function getModelLabel(): string
    {
        return __('resources/resource/strings.label');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('resources/resource/strings.nav_group');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListResources::route('/'),
            'create' => CreateResource::route('/create'),
            'edit' => EditResource::route('/{record}/edit'),
        ];
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/resource/strings.plural_label');
    }

    public static function getRecordTitle(?Model $record): ?string
    {
        if (!$record) {
            return null;
        }

        return $record->labeled_name;
    }

    public static function getRelations(): array
    {
        return [ReservationsRelationManager::class];
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()
                ->extraAttributes(['class' => 'fi-infolist-panel'])
                ->hiddenLabel()
                ->schema([
                    ResourceInfolistPresenter::name(),
                    ResourceInfolistPresenter::type(),
                    ResourceInfolistPresenter::status(),
                    ResourceInfolistPresenter::reservationsCount(),

                    ResourceInfolistPresenter::divider(),
                    ResourceInfolistPresenter::floor(),
                    ResourceInfolistPresenter::unit(),
                    ResourceInfolistPresenter::cardNumber(),
                    ResourceInfolistPresenter::extension(),
                    ResourceInfolistPresenter::capacity(),
                    ResourceInfolistPresenter::availableDays(),
                    ResourceInfolistPresenter::timeSlots(),
                    ResourceInfolistPresenter::notes(),

                    ResourceInfolistPresenter::divider(),
                    ResourceInfolistPresenter::createdAt(),
                    ResourceInfolistPresenter::updatedAt(),
                ])
                ->columnSpanFull()
                ->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                ResourceTablePresenter::id(),
                ResourceTablePresenter::name(),
                ResourceTablePresenter::type(),
                ResourceTablePresenter::status(),
                ResourceTablePresenter::floor(),
                ResourceTablePresenter::reservationsCount(),
                ResourceTablePresenter::createdAt(),
            ])
            ->filters([
                ResourceTablePresenter::typeFilter(),
                ResourceTablePresenter::statusFilter(),
                ResourceTablePresenter::hasReservationsFilter(),
                self::createdAtFilter(),
            ])
            ->groups([ResourceTablePresenter::typeGroup()])
            ->recordActions([
                self::viewAction(),
                self::editAction(),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells)
            ->groupedBulkActions(self::bulkActions(ResourceExporter::class))
            ->emptyStateIcon('heroicon-o-bookmark')
            ->emptyStateHeading(__('resources/resource/strings.empty.heading'))
            ->emptyStateDescription(__('resources/resource/strings.empty.description'))
            ->emptyStateActions([self::setupGuideAction()])
            ->defaultSort('name')
            ->striped();
    }
}
