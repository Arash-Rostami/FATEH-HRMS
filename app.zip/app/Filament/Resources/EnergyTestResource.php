<?php

namespace App\Filament\Resources;

use App\Filament\Resources\EnergyResource\Exports\EnergyTestExporter;
use App\Traits\Filament\AuthorizesByPermission;
use App\Filament\Resources\EnergyResource\Pages\{ListEnergyTests, ViewEnergyTest};
use App\Filament\Resources\EnergyResource\Schemas\{EnergyTestInfolistPresenter, EnergyTestTablePresenter};
use App\Models\EnergyTest;
use App\Traits\Filament\FilamentActions;
use App\Traits\Filament\FilamentAdminGuide;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class EnergyTestResource extends Resource
{
    use FilamentAdminGuide, FilamentActions, AuthorizesByPermission;

    protected static ?string $model = EnergyTest::class;
    protected static string|null|\BackedEnum $navigationIcon = 'heroicon-o-bolt';
    protected static ?int $navigationSort = 3;

    protected static array $guide = [
        ['label' => 'بررسی', 'icon' => 'menu_book', 'view' => 'filament.resources.energy.guide.overview'],
        ['label' => 'کارهای مدیریتی', 'icon' => 'admin_panel_settings', 'view' => 'filament.resources.energy.guide.admin-ops'],
        ['label' => 'فهرست و فیلترها', 'icon' => 'filter_alt', 'view' => 'filament.resources.energy.guide.list-tabs'],
        ['label' => 'تجربهٔ کاربر', 'icon' => 'visibility', 'view' => 'filament.resources.energy.guide.user'],
    ];

    public static function canCreate(): bool
    {
        return false;
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->with('user');
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            __('resources/energy/strings.fields.overall_score') => number_format($record->overall_score ?? 0, 1),
            __('resources/energy/strings.fields.completed_at') => toJalaliSmart($record->completed_at),
        ];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return ($record->user?->name ?? '—') . ' — ' . number_format($record->overall_score ?? 0, 1);
    }

    public static function getGlobalSearchResultUrl(Model $record): string
    {
        return static::getUrl('view', ['record' => $record]);
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['user.name'];
    }

    public static function getRecordTitle(?Model $record): ?string
    {
        return $record?->user?->name;
    }

    public static function getModelLabel(): string
    {
        return __('resources/energy/strings.label');
    }


    public static function getNavigationGroup(): ?string
    {
        return __('resources/energy/strings.nav_group');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListEnergyTests::route('/'),
            'view' => ViewEnergyTest::route('/{record}'),
        ];
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/energy/strings.plural_label');
    }


    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()
                ->extraAttributes(['class' => 'fi-infolist-panel'])
                ->hiddenLabel()
                ->schema([
                    EnergyTestInfolistPresenter::user(),
                    EnergyTestInfolistPresenter::completedAt(),
                    EnergyTestInfolistPresenter::createdAt(),

                    EnergyTestInfolistPresenter::divider(),
                    EnergyTestInfolistPresenter::overallScore(),
                    EnergyTestInfolistPresenter::physiqueScore(),
                    EnergyTestInfolistPresenter::emotionScore(),
                    EnergyTestInfolistPresenter::mindScore(),
                    EnergyTestInfolistPresenter::soulScore(),

                    EnergyTestInfolistPresenter::divider(),
                    EnergyTestInfolistPresenter::questionsDetail(),
                    EnergyTestInfolistPresenter::answers(),
                ])
                ->columnSpanFull()
                ->columns(4),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                EnergyTestTablePresenter::id(),
                EnergyTestTablePresenter::user(),
                EnergyTestTablePresenter::overallScore(),
                EnergyTestTablePresenter::physiqueScore(),
                EnergyTestTablePresenter::emotionScore(),
                EnergyTestTablePresenter::mindScore(),
                EnergyTestTablePresenter::soulScore(),
                EnergyTestTablePresenter::completedAt(),
                EnergyTestTablePresenter::createdAt(),
            ])
            ->groups([
                EnergyTestTablePresenter::userGroup(),
                EnergyTestTablePresenter::monthGroup(),
            ])
            ->filters([
                EnergyTestTablePresenter::scoreRangeFilter(),
                EnergyTestTablePresenter::lowScoreFilter(),
                EnergyTestTablePresenter::dateRangeFilter(),
                EnergyTestTablePresenter::lastMonthFilter(),
                EnergyTestTablePresenter::userFilter(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                self::viewAction(),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells)
            ->groupedBulkActions(self::bulkActions(EnergyTestExporter::class))
            ->emptyStateIcon('heroicon-o-bolt')
            ->defaultSort('completed_at', 'desc')
            ->striped();
    }
}
