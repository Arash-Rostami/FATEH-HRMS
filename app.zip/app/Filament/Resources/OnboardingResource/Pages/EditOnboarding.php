<?php

namespace App\Filament\Resources\OnboardingResource\Pages;

use App\Filament\Resources\OnboardingResource;
use App\Filament\Resources\OnboardingResource\Pages\Action\EnforcesActiveOnboarding;
use App\Filament\Resources\OnboardingResource\Schemas\OnboardingFormPresenter;
use App\Traits\Filament\FilamentEditHeading;
use App\Traits\Filament\FilamentHeaderActions;
use App\Traits\Filament\FilamentPageBehavior;
use App\Filament\Pages\EditRecord;

class EditOnboarding extends EditRecord
{
    use FilamentEditHeading, FilamentHeaderActions, FilamentPageBehavior;

    protected static string $resource = OnboardingResource::class;

    protected function afterSave(): void
    {
        EnforcesActiveOnboarding::deactivateConflicting($this->record);
    }

    protected function mutateFormDataBeforeSave(array $data): array
    {
        return OnboardingFormPresenter::hydrateGuidesWithFileMeta($data);
    }

    protected function trackedFileColumns(): array
    {
        return ['guides' => ['url'], 'videos' => ['url', 'thumbnail']];
    }
}
