<?php

namespace App\Filament\Resources\FeedResource\Exports;

use App\Enums\FeedCategory;
use App\Models\Feed;
use App\Traits\Filament\FilamentVisibility;
use Filament\Actions\Exports\ExportColumn;
use Filament\Actions\Exports\Exporter;
use Filament\Actions\Exports\Models\Export;
use Illuminate\Database\Eloquent\Builder;

class FeedExporter extends Exporter
{
    use FilamentVisibility;

    protected static ?string $model = Feed::class;

    public static function getColumns(): array
    {
        return [
            ExportColumn::make('id')->label('ID'),
            ExportColumn::make('user.name')->label(__('resources/feed/strings.fields.user')),
            ExportColumn::make('category')
                ->label(__('resources/feed/strings.fields.category'))
                ->state(fn($record) => FeedCategory::tryFrom($record->category)?->getLabel() ?? $record->category),
            ExportColumn::make('content')
                ->label(__('resources/feed/strings.fields.content'))
                ->state(fn($record) => strip_tags($record->content ?? '')),
            self::activeExportColumn(),
            self::audienceExportColumn(),
            ExportColumn::make('comments_count')
                ->label(__('resources/feed/strings.fields.comments_count'))
                ->state(fn($record) => isset($record->comments_count) ? $record->comments_count : $record->comments()->count()),
            ExportColumn::make('reactions_count')
                ->label(__('resources/feed/strings.fields.reactions_count'))
                ->state(fn($record) => isset($record->reactions_count) ? $record->reactions_count : $record->reactions()->count()),
            ExportColumn::make('created_at')->label(__('resources/feed/strings.fields.created_at'))
                ->formatStateUsing(fn($state) => toJalaliSmart($state)),
        ];
    }

    public static function getCompletedNotificationBody(Export $export): string
    {
        $count = number_format($export->successful_rows);

        return __('resources/feed/strings.export.completed', ['count' => $count]);
    }

    public static function modifyQuery(Builder $query): Builder
    {
        return $query->with(['user'])->withCount(['comments', 'reactions']);
    }
}
