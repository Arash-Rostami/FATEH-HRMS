<?php

namespace App\Filament\Resources\FeedResource\Pages;

use App\Filament\Resources\FeedResource;
use App\Filament\Resources\FeedResource\Schemas\FeedFormPresenter;
use App\Traits\Filament\FilamentEditHeading;
use App\Traits\Filament\FilamentHeaderActions;
use App\Traits\Filament\FilamentPageBehavior;
use App\Filament\Pages\EditRecord;

class EditFeed extends EditRecord
{
    use FilamentEditHeading, FilamentHeaderActions, FilamentPageBehavior;

    protected static string $resource = FeedResource::class;

    protected function mutateFormDataBeforeFill(array $data): array
    {
        return FeedFormPresenter::unpackPollSettings(FeedFormPresenter::splitMediaPaths($data));
    }

    protected function mutateFormDataBeforeSave(array $data): array
    {
        return FeedFormPresenter::packPollSettings(FeedFormPresenter::mergeMediaPaths($data));
    }

    protected function trackedFileColumns(): array
    {
        return ['media_paths' => []];
    }
}
