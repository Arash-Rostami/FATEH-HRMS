<?php

namespace App\Filament\Resources\PostResource\Exports;

use App\Models\Post;
use App\Traits\Filament\FilamentVisibility;
use Filament\Actions\Exports\ExportColumn;
use Filament\Actions\Exports\Exporter;
use Filament\Actions\Exports\Models\Export;
use Illuminate\Database\Eloquent\Builder;

class PostExporter extends Exporter
{
    use FilamentVisibility;

    protected static ?string $model = Post::class;

    public static function modifyQuery(Builder $query): Builder
    {
        return $query->with(['user']);
    }

    public static function getColumns(): array
    {
        return [
            ExportColumn::make('id')->label('ID'),
            ExportColumn::make('title')->label(__('resources/post/strings.fields.title')),
            ExportColumn::make('body')
                ->label(__('resources/post/strings.fields.body'))
                ->state(fn($record) => strip_tags($record->body ?? '')),
            ExportColumn::make('user.name')->label(__('resources/post/strings.fields.user')),
            ExportColumn::make('pinned')
                ->label(__('resources/post/strings.fields.pinned'))
                ->formatStateUsing(fn($state) => $state ? 'بله' : 'خیر'),
            self::activeExportColumn(),
            self::audienceExportColumn(),
            ExportColumn::make('created_at')->label(__('resources/post/strings.fields.created_at'))
                ->formatStateUsing(fn($state) => toJalaliSmart($state)),
        ];
    }

    public static function getCompletedNotificationBody(Export $export): string
    {
        return __('resources/post/strings.export.completed', [
            'count' => number_format($export->successful_rows),
        ]);
    }
}
