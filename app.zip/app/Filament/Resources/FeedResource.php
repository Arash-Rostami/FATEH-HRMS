<?php

namespace App\Filament\Resources;

use App\Filament\Resources\FeedResource\Exports\FeedExporter;
use App\Traits\Filament\AuthorizesByPermission;
use BackedEnum;
use App\Filament\Resources\FeedResource\Pages\{CreateFeed, EditFeed, ListFeeds};
use App\Filament\Resources\FeedResource\RelationManagers\{CommentsRelationManager, PollsRelationManager, ReactionsRelationManager};
use App\Filament\Resources\FeedResource\Schemas\{FeedFormPresenter, FeedInfolistPresenter, FeedTablePresenter};
use App\Models\Feed;
use App\Traits\Filament\FilamentActions;
use App\Traits\Filament\FilamentAdminGuide;
use App\Traits\Filament\FilamentFilters;
use App\Traits\Filament\FilamentVisibility;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class FeedResource extends Resource
{
    use FilamentActions, FilamentAdminGuide, FilamentFilters, FilamentVisibility, AuthorizesByPermission;

    protected static ?string $model = Feed::class;
    protected static string|null|BackedEnum $navigationIcon = 'heroicon-o-rss';
    protected static ?int $navigationSort = 2;

    protected static array $guide = [
        ['label' => 'بررسی', 'icon' => 'newspaper', 'view' => 'filament.resources.feed.guide.overview'],
        ['label' => 'کارهای مدیریتی', 'icon' => 'build', 'view' => 'filament.resources.feed.guide.admin-ops'],
        ['label' => 'فهرست و فیلترها', 'icon' => 'filter_alt', 'view' => 'filament.resources.feed.guide.list-filters'],
        ['label' => 'تجربهٔ کاربر', 'icon' => 'visibility', 'view' => 'filament.resources.feed.guide.user'],
    ];

    public static function getRecordTitle(?Model $record): ?string
    {
        if (! $record) {
            return null;
        }

        return Str::limit(stripHtml($record->content ?? ''), 60);
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make(__('resources/feed/strings.form.section_content'))
                ->icon('heroicon-o-document-text')
                ->schema([
                    FeedFormPresenter::content(),
                ])
                ->columns(1),

            Section::make(__('resources/feed/strings.form.section_author'))
                ->icon('heroicon-o-user')
                ->schema([
                    FeedFormPresenter::userId(),
                    FeedFormPresenter::category(),
                    self::activeToggle(),
                    self::departmentsSelect(),
                    FeedFormPresenter::divider(),
                    FeedFormPresenter::pollSettings(),
                    FeedFormPresenter::pollOptions(),
                    FeedFormPresenter::mediaImages(),
                    FeedFormPresenter::mediaVideos(),
                ])
                ->columns(2),
        ]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->with('user')
            ->withCount(['comments', 'reactions', 'polls']);
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            __('resources/feed/strings.fields.user') => $record->user?->name ?? '—',
            __('resources/feed/strings.fields.category') => $record->category ?? '—',
        ];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return stripHtml(mb_substr($record->content ?? '', 0, 80));
    }

    public static function getGlobalSearchResultUrl(Model $record): string
    {
        return static::getUrl('edit', ['record' => $record]);
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['content', 'user.name'];
    }

    public static function getModelLabel(): string
    {
        return __('resources/feed/strings.label');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('resources/feed/strings.nav_group');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListFeeds::route('/'),
            'create' => CreateFeed::route('/create'),
            'edit' => EditFeed::route('/{record}/edit'),
        ];
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/feed/strings.plural_label');
    }

    public static function getRelations(): array
    {
        return [
            CommentsRelationManager::class,
            PollsRelationManager::class,
            ReactionsRelationManager::class,
        ];
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()
                ->extraAttributes(['class' => 'fi-infolist-panel'])
                ->hiddenLabel()
                ->schema([
                    FeedInfolistPresenter::user(),
                    FeedInfolistPresenter::category(),
                    FeedInfolistPresenter::commentsCount(),
                    FeedInfolistPresenter::reactionsCount(),
                    self::activeEntry(),
                    self::audienceEntry(),

                    FeedInfolistPresenter::divider(),
                    FeedInfolistPresenter::content(),
                    FeedInfolistPresenter::pollOptions(),
                    FeedInfolistPresenter::pollSettings(),
                    FeedInfolistPresenter::pollsTotal(),

                    FeedInfolistPresenter::divider(),
                    FeedInfolistPresenter::mediaImages(),
                    FeedInfolistPresenter::mediaVideosCount(),

                    FeedInfolistPresenter::divider(),
                    FeedInfolistPresenter::createdAt(),
                    FeedInfolistPresenter::updatedAt(),
                ])
                ->columns(4)
                ->columnSpanFull()
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                FeedTablePresenter::id(),
                FeedTablePresenter::mediaPreview(),
                FeedTablePresenter::user(),
                FeedTablePresenter::category(),
                self::activeColumn(),
                self::audienceColumn(),
                FeedTablePresenter::content(),
                FeedTablePresenter::commentsCount(),
                FeedTablePresenter::reactionsCount(),
                FeedTablePresenter::pollsCount(),
                FeedTablePresenter::mediaCount(),
                FeedTablePresenter::createdAt(),
            ])
            ->groups([
                FeedTablePresenter::categoryGroup(),
                self::activeGroup(),
            ])
            ->filters([
                self::activeFilter(),
                self::audienceFilter(),
                self::visibilityFilter(),
                FeedTablePresenter::categoryFilter(),
                FeedTablePresenter::userFilter(),
                self::createdAtFilter(),
                FeedTablePresenter::hasMediaFilter(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                self::viewAction(),
                self::editAction(),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells)
            ->groupedBulkActions([
                ...self::bulkActions(FeedExporter::class),
                ...self::bulkVisibilityActions(),
            ])
            ->emptyStateIcon('heroicon-o-newspaper')
            ->defaultSort('created_at', 'desc')
            ->striped();
    }
}
