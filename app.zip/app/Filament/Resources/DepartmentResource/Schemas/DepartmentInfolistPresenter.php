<?php

namespace App\Filament\Resources\DepartmentResource\Schemas;

use App\Traits\Filament\FilamentFormDivider;
use Filament\Infolists\Components\IconEntry;
use Filament\Infolists\Components\TextEntry;
use Filament\Support\Enums\FontFamily;
use Filament\Support\Enums\FontWeight;
use Filament\Support\Enums\IconPosition;
use Filament\Support\Enums\TextSize;

class DepartmentInfolistPresenter
{
    use FilamentFormDivider;

    public static function code(): TextEntry
    {
        return TextEntry::make('code')
            ->label(__('resources/department/strings.fields.code'))
            ->badge()
            ->color('primary')
            ->fontFamily(FontFamily::Mono)
            ->copyable()
            ->copyMessageDuration(1500);
    }

    public static function createdAt(): TextEntry
    {
        return TextEntry::make('created_at')
            ->label(__('resources/department/strings.fields.created_at'))
            ->formatStateUsing(fn($state) => $state ? toJalali($state, 'Y/m/d') : '-')
            ->extraAttributes(['dir' => 'ltr', 'style' => 'unicode-bidi: isolate;'])
            ->alignRight()
            ->iconPosition(IconPosition::After)
            ->icon('heroicon-o-clock')
            ->color('gray')
            ->placeholder('-');
    }

    public static function description(): TextEntry
    {
        return TextEntry::make('description')
            ->label(__('resources/department/strings.fields.description'))
            ->extraAttributes(['dir' => 'auto', 'style' => 'white-space: pre-wrap; unicode-bidi: isolate;'])
            ->columnSpanFull()
            ->placeholder('-');
    }

    public static function freeAssignment(): IconEntry
    {
        return IconEntry::make('free_assignment')
            ->label(__('resources/department/strings.fields.free_assignment'))
            ->boolean()
            ->trueIcon('heroicon-o-check-circle')
            ->falseIcon('heroicon-o-x-circle')
            ->trueColor('success')
            ->falseColor('danger');
    }

    public static function level(): TextEntry
    {
        return TextEntry::make('level')
            ->label(__('resources/department/strings.fields.level'))
            ->formatStateUsing(fn(int $state): string => __("resources/department/strings.fields.level_{$state}"))
            ->badge();
    }

    public static function name(): TextEntry
    {
        return TextEntry::make('name')
            ->label(__('resources/department/strings.fields.name'))
            ->extraAttributes(['dir' => 'auto', 'style' => 'unicode-bidi: isolate;'])
            ->size(TextSize::Small)
            ->weight(FontWeight::Bold);
    }

    public static function sections(): TextEntry
    {
        return TextEntry::make('sections')
            ->label(__('resources/department/strings.fields.sections'))
            ->badge()
            ->placeholder('-');
    }

    public static function units(): TextEntry
    {
        return TextEntry::make('units')
            ->label(__('resources/department/strings.fields.units'))
            ->badge()
            ->placeholder('-');
    }

    public static function subordinateTo(): TextEntry
    {
        return TextEntry::make('subordinate_to')
            ->label(__('resources/department/strings.fields.subordinate_to'))
            ->badge()
            ->color('gray')
            ->placeholder('-');
    }

    public static function updatedAt(): TextEntry
    {
        return TextEntry::make('updated_at')
            ->label(__('resources/department/strings.fields.updated_at'))
            ->formatStateUsing(fn($state) => $state ? toJalali($state, 'Y/m/d') : '-')
            ->extraAttributes(['dir' => 'ltr', 'style' => 'unicode-bidi: isolate;'])
            ->alignRight()
            ->iconPosition(IconPosition::After)
            ->icon('heroicon-o-arrow-path')
            ->color('gray')
            ->placeholder('-');
    }

    public static function usersCount(): TextEntry
    {
        return TextEntry::make('users_count')
            ->label(__('resources/department/strings.fields.users_count'))
            ->state(fn($record): int => $record->users_count ?? $record->currentUsers()->count())
            ->badge()
            ->color('info')
            ->icon('heroicon-m-users');
    }
}
