<?php

namespace App\Filament\Resources\DepartmentResource\RelationManagers;

use App\Filament\Resources\ReportResource\Schemas\ReportFormPresenter;
use App\Filament\Resources\ReportResource\Schemas\ReportInfolistPresenter;
use App\Filament\Resources\ReportResource\Schemas\ReportTablePresenter;
use App\Traits\Filament\FilamentActions;
use App\Filament\RelationManagers\RelationManager;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class ReportsRelationManager extends RelationManager
{
    use FilamentActions;

    protected static string $relationship = 'reports';

    public static function getModelLabel(): string
    {
        return __('resources/report/strings.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/report/strings.plural_label');
    }

    public static function getTitle(Model $ownerRecord, string $pageClass): string
    {
        return __('resources/report/strings.plural_label');
    }

    public function form(Schema $schema): Schema
    {
        return $schema->components([
            Tabs::make()
                ->tabs([
                    Tab::make(__('resources/report/strings.form.tab_main'))
                        ->icon('heroicon-o-information-circle')
                        ->schema([
                            Section::make(__('resources/report/strings.form.section_main'))
                                ->description(__('resources/report/strings.form.section_description'))
                                ->icon('heroicon-o-document-text')
                                ->schema([
                                    ReportFormPresenter::title(),
                                    ReportFormPresenter::userId(),
                                    ReportFormPresenter::active(),
                                    ReportFormPresenter::description(),
                                ])
                                ->columns(2)
                                ->columnSpanFull(),
                        ]),

                    Tab::make(__('resources/report/strings.form.tab_files'))
                        ->icon('heroicon-o-paper-clip')
                        ->schema([
                            Section::make(__('resources/report/strings.form.section_files'))
                                ->icon('heroicon-o-folder-open')
                                ->schema([
                                    ReportFormPresenter::coverImage(),
                                    ReportFormPresenter::filePath(),
                                ])
                                ->columns(2)
                                ->columnSpanFull(),
                        ]),
                ])
                ->columnSpanFull()
        ]);
    }

    public function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()
                ->hiddenLabel()
                ->schema([
                    ReportInfolistPresenter::thumbnail(),
                    ReportInfolistPresenter::title(),
                    ReportInfolistPresenter::description(),
                    ReportInfolistPresenter::user(),
                    ReportInfolistPresenter::fileType(),
                    ReportInfolistPresenter::active(),
                    ReportInfolistPresenter::createdAt(),
                    ReportInfolistPresenter::updatedAt(),
                ])
                ->columnSpanFull()
                ->columns(2),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->with(['user']))
            ->columns([
                ReportTablePresenter::id(),
                ReportTablePresenter::title(),
                ReportTablePresenter::user(),
                ReportTablePresenter::fileType(),
                ReportTablePresenter::active(),
                ReportTablePresenter::createdAt(),
            ])
            ->groups([
                ReportTablePresenter::activeGroup(),
            ])
            ->filters([
                ReportTablePresenter::activeFilter(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                self::viewAction(),
                self::editAction()->using(fn (\Illuminate\Database\Eloquent\Model $record, array $data): \Illuminate\Database\Eloquent\Model => $this->updateDeletingDroppedFiles($record, $data, ['cover_image' => [], 'file_path' => []])),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells)
            ->emptyStateIcon('heroicon-o-bookmark')
            ->defaultSort('created_at', 'desc')
            ->striped();
    }
}
