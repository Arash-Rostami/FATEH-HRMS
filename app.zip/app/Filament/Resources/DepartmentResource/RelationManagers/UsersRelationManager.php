<?php

namespace App\Filament\Resources\DepartmentResource\RelationManagers;

use App\Filament\Resources\UserResource\Schemas\UserFormPresenter;
use App\Filament\Resources\UserResource\Schemas\UserInfolistPresenter;
use App\Filament\Resources\UserResource\Schemas\UserTablePresenter;
use App\Traits\Filament\FilamentActions;
use App\Filament\RelationManagers\RelationManager;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class UsersRelationManager extends RelationManager
{
    use FilamentActions;

    protected static string $relationship = 'users';

    public function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make(__('resources/user/strings.form.section_identity'))
                ->schema([
                    UserFormPresenter::name(),
                    UserFormPresenter::email(),
                    UserFormPresenter::password(),
                    UserFormPresenter::passwordConfirmation(),
                ])->columns(1),

            Section::make(__('resources/user/strings.form.section_access'))
                ->schema([
                    UserFormPresenter::type(),
                    UserFormPresenter::role(),
                    UserFormPresenter::status(),
                    UserFormPresenter::presence(),
                ])->columns(2),

            Section::make(__('resources/user/strings.form.section_booking'))
                ->schema([
                    UserFormPresenter::booking(),
                ])->columnSpanFull(),

            Section::make(__('resources/user/strings.form.section_extra'))
                ->schema([
                    UserFormPresenter::extra(),
                ])->columnSpanFull(),
        ]);
    }

    public static function getModelLabel(): string
    {
        return __('resources/user/strings.navigation.singular');
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/user/strings.navigation.plural');
    }

    public static function getTitle(Model $ownerRecord, string $pageClass): string
    {
        return __('resources/department/strings.relations.users');
    }

    public function infolist(Schema $schema): Schema
    {
        return $schema
            ->components([
                Tabs::make()
                    ->tabs([
                        Tabs\Tab::make(__('resources/user/strings.infolist.section_identity'))
                            ->icon('heroicon-o-user-circle')
                            ->schema([
                                Section::make()
                                    ->schema([
                                        UserInfolistPresenter::id(),
                                        UserInfolistPresenter::name(),
                                        UserInfolistPresenter::email(),
                                        UserInfolistPresenter::emailVerifiedAt(),
                                        UserInfolistPresenter::divider(),
                                        UserInfolistPresenter::type(),
                                        UserInfolistPresenter::role(),
                                        UserInfolistPresenter::status(),
                                        UserInfolistPresenter::presence(),
                                        UserInfolistPresenter::divider(),
                                        UserInfolistPresenter::booking(),
                                    ])->columns(3),
                            ])
                            ->columnSpanFull(),

                        Tabs\Tab::make(__('resources/user/strings.infolist.section_extra'))
                            ->icon('heroicon-o-adjustments-horizontal')
                            ->schema([
                                Section::make()
                                    ->schema([
                                        UserInfolistPresenter::extra(),
                                        UserInfolistPresenter::divider(),
                                        UserInfolistPresenter::lastSeen(),
                                        UserInfolistPresenter::createdAt(),
                                        UserInfolistPresenter::updatedAt(),
                                    ])->columns(3),
                            ])
                            ->columnSpanFull(),
                    ])
                    ->columnSpanFull(),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->with(['profile']))
            ->columns([
                UserTablePresenter::id(),
                UserTablePresenter::avatar(),
                UserTablePresenter::name(),
                UserTablePresenter::status(),
                UserTablePresenter::role(),
                UserTablePresenter::type(),
                UserTablePresenter::email(),
                UserTablePresenter::presence(),
                UserTablePresenter::lastSeen(),
                UserTablePresenter::createdAt(),
            ])
            ->groups([
                UserTablePresenter::statusGroup(),
                UserTablePresenter::roleGroup(),
                UserTablePresenter::presenceGroup(),
            ])
            ->filters([
                UserTablePresenter::statusFilter(),
                UserTablePresenter::roleFilter(),
                UserTablePresenter::typeFilter(),
                UserTablePresenter::presenceFilter(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                self::viewAction(),
                self::editAction(),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells)
            ->striped()
            ->emptyStateIcon('heroicon-o-bookmark')
            ->defaultSort('id', 'desc');
    }
}
