<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ThsResource\Exports\ThsExporter;
use App\Traits\Filament\AuthorizesByPermission;
use App\Filament\Resources\ThsResource\Pages\{CreateTicket, EditTicket, ListTickets};
use App\Filament\Resources\ThsResource\Schemas\{TicketFormPresenter, TicketInfolistPresenter, TicketTablePresenter};
use App\Livewire\Dashboard\Ths\Workspace;
use App\Models\Ticket;
use App\Traits\Filament\FilamentActions;
use App\Traits\Filament\FilamentAdminGuide;
use App\Traits\Filament\FilamentFilters;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Livewire;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class ThsResource extends Resource
{
    use FilamentActions, FilamentFilters, AuthorizesByPermission, FilamentAdminGuide;

    protected static ?string $model = Ticket::class;
    protected static ?string $recordTitleAttribute = 'request_subject';
    protected static string|null|\BackedEnum $navigationIcon = 'heroicon-o-lifebuoy';
    protected static ?int $navigationSort = 2;

    protected static array $guide = [
        ['label' => 'بررسی', 'icon' => 'menu_book', 'view' => 'filament.resources.ths.guide.overview'],
        ['label' => 'زبانه‌ها و فیلترها', 'icon' => 'list_alt', 'view' => 'filament.resources.ths.guide.list-tabs'],
        ['label' => 'کارهای مدیریتی', 'icon' => 'admin_panel_settings', 'view' => 'filament.resources.ths.guide.admin-ops'],
        ['label' => 'تجربهٔ کاربر', 'icon' => 'visibility', 'view' => 'filament.resources.ths.guide.user'],
    ];

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Tabs::make()
                ->tabs([
                    Tab::make(__('resources/ths/strings.form.tab_request'))
                        ->icon('heroicon-o-inbox')
                        ->schema([
                            Section::make(__('resources/ths/strings.form.section_requester'))
                                ->icon('heroicon-o-user')
                                ->schema([
                                    TicketFormPresenter::requesterId(),
                                    TicketFormPresenter::departmentDisplay(),
                                    TicketFormPresenter::targetDepartment(),
                                ])
                                ->columns(3),

                            Section::make(__('resources/ths/strings.form.section_request'))
                                ->icon('heroicon-o-document-text')
                                ->schema([
                                    TicketFormPresenter::requestType(),
                                    TicketFormPresenter::requestArea(),
                                    TicketFormPresenter::priority(),
                                    TicketFormPresenter::divider(),
                                    TicketFormPresenter::requestSubject(),
                                    TicketFormPresenter::description(),
                                    TicketFormPresenter::requesterFiles(),
                                ])
                                ->columns(3),
                        ]),

                    Tab::make(__('resources/ths/strings.form.tab_response'))
                        ->icon('heroicon-o-chat-bubble-bottom-center-text')
                        ->schema([
                            Section::make(__('resources/ths/strings.form.section_assignment'))
                                ->icon('heroicon-o-user-circle')
                                ->schema([
                                    TicketFormPresenter::assignedTo(),
                                    TicketFormPresenter::status(),
                                    TicketFormPresenter::completionDate(),
                                    TicketFormPresenter::completionDeadlineDate(),
                                    TicketFormPresenter::completionDeadlineTime(),
                                ])
                                ->columns(3),

                            Section::make(__('resources/ths/strings.form.section_response'))
                                ->icon('heroicon-o-chat-bubble-left-right')
                                ->schema([
                                    TicketFormPresenter::effectiveness(),
                                    TicketFormPresenter::satisfactionScore(),
                                    TicketFormPresenter::divider(),
                                    TicketFormPresenter::actionResult(),
                                    TicketFormPresenter::additionalNotes(),
                                    TicketFormPresenter::assigneeFiles(),
                                ])
                                ->columns(2),

                            Section::make(__('resources/ths/strings.form.section_workspace'))
                                ->icon('heroicon-o-chat-bubble-oval-left-ellipsis')
                                ->visible(fn(?Ticket $record) => $record !== null)
                                ->schema([
                                    Livewire::make(Workspace::class, fn(?Ticket $record) => ['ticketId' => $record?->id ?? 0, 'embedded' => true]),
                                ]),
                        ]),
                ])
                ->columnSpanFull(),
        ]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->with(['requester', 'assignee']);
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            __('resources/ths/strings.fields.requester') => $record->requester?->name ?? '—',
            __('resources/ths/strings.fields.status') => $record->status,
        ];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return TicketTablePresenter::formatTicketId($record) . ' — ' . $record->request_subject;
    }

    public static function getGlobalSearchResultUrl(Model $record): string
    {
        return static::getUrl('edit', ['record' => $record]);
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['request_subject', 'description', 'requester.name', 'assignee.name'];
    }

    public static function getModelLabel(): string
    {
        return __('resources/ths/strings.label');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('resources/ths/strings.nav_group');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListTickets::route('/'),
            'create' => CreateTicket::route('/create'),
            'edit' => EditTicket::route('/{record}/edit'),
        ];
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/ths/strings.plural_label');
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Tabs::make()
                ->tabs([
                    Tab::make(__('resources/ths/strings.infolist.section_request'))
                        ->icon('heroicon-o-inbox-arrow-down')
                        ->schema([
                            Section::make()
                                ->extraAttributes(['class' => 'fi-infolist-panel'])
                                ->hiddenLabel()
                                ->schema([
                                    TicketInfolistPresenter::ticketId(),
                                    TicketInfolistPresenter::status(),
                                    TicketInfolistPresenter::priority(),
                                    TicketInfolistPresenter::requestType(),
                                    TicketInfolistPresenter::requestArea(),

                                    TicketInfolistPresenter::divider(),
                                    TicketInfolistPresenter::requester(),
                                    TicketInfolistPresenter::department(),
                                    TicketInfolistPresenter::targetDepartment(),

                                    TicketInfolistPresenter::divider(),
                                    TicketInfolistPresenter::subject(),
                                    TicketInfolistPresenter::description(),
                                    TicketInfolistPresenter::requesterFiles(),

                                    TicketInfolistPresenter::divider(),
                                    TicketInfolistPresenter::createdAt(),
                                    TicketInfolistPresenter::updatedAt(),
                                ])
                                ->columns(4),
                        ]),

                    Tab::make(__('resources/ths/strings.infolist.section_response'))
                        ->icon('heroicon-o-chat-bubble-left-ellipsis')
                        ->schema([
                            Section::make()
                                ->extraAttributes(['class' => 'fi-infolist-panel'])
                                ->hiddenLabel()
                                ->schema([
                                    TicketInfolistPresenter::assignee(),
                                    TicketInfolistPresenter::completionDeadline(),
                                    TicketInfolistPresenter::completionDate(),

                                    TicketInfolistPresenter::divider(),
                                    TicketInfolistPresenter::effectiveness(),
                                    TicketInfolistPresenter::satisfaction(),
                                    TicketInfolistPresenter::actionResult(),
                                    TicketInfolistPresenter::additionalNotes(),

                                    TicketInfolistPresenter::divider(),
                                    TicketInfolistPresenter::assigneeFiles(),
                                ])
                                ->columns(4),
                        ]),

                    Tab::make(__('resources/ths/strings.insight.tab_ticket'))
                        ->icon('heroicon-o-light-bulb')
                        ->schema([
                            Section::make()
                                ->extraAttributes(['class' => 'fi-infolist-panel'])
                                ->hiddenLabel()
                                ->schema([
                                    TicketInfolistPresenter::ticketInsights(),

                                    TicketInfolistPresenter::divider(),
                                    TicketInfolistPresenter::effectiveness(),
                                    TicketInfolistPresenter::satisfaction(),
                                    TicketInfolistPresenter::actionResult(),
                                ])
                                ->columns(4),
                        ]),

                    Tab::make(__('resources/ths/strings.insight.tab_department'))
                        ->icon('heroicon-o-chart-bar')
                        ->schema([
                            Section::make()
                                ->extraAttributes(['class' => 'fi-infolist-panel'])
                                ->hiddenLabel()
                                ->schema([
                                    TicketInfolistPresenter::departmentInsights(),
                                ]),
                        ]),
                ])
                ->columnSpanFull()
                ->extraAttributes(['class' => 'fi-infolist-panel']),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TicketTablePresenter::ticketId(),
                TicketTablePresenter::targetDepartment(),
                TicketTablePresenter::status(),
                TicketTablePresenter::requester(),
                TicketTablePresenter::priority(),
                TicketTablePresenter::requestType(),
                TicketTablePresenter::requestArea(),
                TicketTablePresenter::department(),
                TicketTablePresenter::subject(),
                TicketTablePresenter::assignee(),
                TicketTablePresenter::completionDeadline(),
                TicketTablePresenter::completionDate(),
                TicketTablePresenter::satisfaction(),
                TicketTablePresenter::effectiveness(),
                TicketTablePresenter::createdAt(),
            ])
            ->groups([
                TicketTablePresenter::statusGroup(),
                TicketTablePresenter::assigneeGroup(),
                TicketTablePresenter::typeGroup(),
            ])
            ->filters([
                TicketTablePresenter::departmentFilter(),
                TicketTablePresenter::priorityFilter(),
                TicketTablePresenter::typeFilter(),
                TicketTablePresenter::areaFilter(),
                TicketTablePresenter::assigneeFilter(),
                TicketTablePresenter::requesterFilter(),
                TicketTablePresenter::unassignedFilter(),
                self::createdAtFilter(),
                TicketTablePresenter::overdueFilter(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                TicketTablePresenter::takeAction(),
                TicketTablePresenter::closeAction(),
                self::viewAction(),
                self::editAction(),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells)
            ->groupedBulkActions(self::bulkActions(ThsExporter::class))
            ->emptyStateIcon('heroicon-o-ticket')
            ->defaultSort('created_at', 'desc')
            ->recordClasses(fn($record) => $record->status !== 'closed' && !$record->completion_date && $record->completion_deadline && now()->gt($record->completion_deadline)
                ? '[&>td]:bg-[color-mix(in_srgb,var(--md-sys-color-error)_8%,transparent)]'
                : null)
            ->striped();
    }
}
