<?php

namespace App\Filament\Resources\DmsResource\Schemas;

use App\Enums\DocumentStatus;
use App\Filament\Resources\DmsResource\Schemas\Action\GenerateOwnerPreview;
use App\Models\Department;
use App\Models\User;
use App\Rules\UniqueLiveDocument;
use App\Support\FileNamer;
use App\Traits\Filament\FilamentFormDivider;
use Closure;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\KeyValue;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Illuminate\Support\Str;
use Livewire\Features\SupportFileUploads\TemporaryUploadedFile;

class DmsFormPresenter
{
    use FilamentFormDivider;

    public static function code(): TextInput
    {
        return TextInput::make('code')
            ->label(__('resources/dms/strings.fields.code'))
            ->required()
            ->maxLength(100)
            ->rule(self::uniqueLiveRule())
            ->helperText(__('resources/dms/strings.hints.code'));
    }

    public static function extra(): KeyValue
    {
        return KeyValue::make('extra')
            ->label(__('resources/dms/strings.fields.extra'))
            ->keyLabel(__('resources/dms/strings.fields.extra_key'))
            ->valueLabel(__('resources/dms/strings.fields.extra_value'))
            ->helperText(__('resources/dms/strings.fields.extra_hint'))
            ->columnSpanFull();
    }

    public static function file(): FileUpload
    {
        return FileUpload::make('file')
            ->label(__('resources/dms/strings.fields.file'))
            ->disk('public')
            ->directory('dms')
            ->openable()
            ->downloadable()
            ->previewable()
            ->imageEditor()
            ->maxSize(config('file_upload_limits.document'))
            ->getUploadedFileNameForStorageUsing(
                fn(TemporaryUploadedFile $file): string => self::forgeFileName($file)
            )
            ->required()
            ->columnSpanFull()
            ->helperText(__('resources/dms/strings.hints.file'));
    }

    public static function extraFiles(): FileUpload
    {
        return FileUpload::make('extra_files')
            ->label(__('resources/dms/strings.fields.extra_files'))
            ->disk('public')
            ->directory('dms')
            ->multiple()
            ->openable()
            ->downloadable()
            ->previewable()
            ->imageEditor()
            ->maxSize(config('file_upload_limits.document'))
            ->acceptedFileTypes([
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/vnd.ms-excel',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'text/csv',
                'text/plain',
            ])
            ->getUploadedFileNameForStorageUsing(
                fn(TemporaryUploadedFile $file): string => self::forgeFileName($file)
            )
            ->nullable()
            ->columnSpanFull()
            ->helperText(__('resources/dms/strings.hints.extra_files'));
    }

    public static function owners(): Select
    {
        return Select::make('owners')
            ->label(__('resources/dms/strings.fields.owners'))
            ->options(fn() => array_merge(
                ['ALL' => __('resources/dms/strings.fields.all_departments')],
                Department::getCachedOptions()->toArray()
            ))
            ->multiple()
            ->searchable()
            ->live()
            ->afterStateUpdated(function (Set $set, ?array $state) {
                $preview = app(GenerateOwnerPreview::class)->handle($state ?? []);
                $set('owners_preview_display', $preview);
            })
            ->required()
            ->helperText(__('resources/dms/strings.hints.owners'));
    }

    public static function ownersPreview(): Textarea
    {
        return Textarea::make('owners_preview_display')
            ->label(__('resources/dms/strings.fields.owners_preview'))
            ->disabled()
            ->dehydrated(false)
            ->afterStateHydrated(fn($component, $record) => $component->state($record
                ? app(GenerateOwnerPreview::class)->handle($record->owners ?? [])
                : null)
            )
            ->rows(5)
            ->placeholder(__('resources/dms/strings.fields.owners_preview_placeholder'))
            ->columnSpanFull()
            ->helperText(__('resources/dms/strings.hints.owners_preview'));
    }

    public static function revision(): Textarea
    {
        return Textarea::make('revision')
            ->label(__('resources/dms/strings.fields.revision'))
            ->rows(6)
            ->maxLength(3000)
            ->nullable()
            ->placeholder(__('resources/dms/strings.fields.revision_placeholder'))
            ->columnSpanFull()
            ->helperText(__('resources/dms/strings.hints.revision'));
    }

    public static function status(): Select
    {
        return Select::make('status')
            ->label(__('resources/dms/strings.fields.status'))
            ->options(DocumentStatus::class)
            ->required()
            ->default(DocumentStatus::Live->value)
            ->rule(self::uniqueLiveRule())
            ->helperText(__('resources/dms/strings.hints.status'));
    }

    public static function tags(): KeyValue
    {
        return KeyValue::make('tags')
            ->label(__('resources/dms/strings.fields.tags'))
            ->columnSpanFull()
            ->helperText(__('resources/dms/strings.fields.tags_hint'));
    }

    public static function title(): TextInput
    {
        return TextInput::make('title')
            ->label(__('resources/dms/strings.fields.title'))
            ->required()
            ->maxLength(255)
            ->helperText(__('resources/dms/strings.hints.title'));
    }

    public static function type(): Toggle
    {
        return Toggle::make('type')
            ->label(fn($state) => $state
                ? __('resources/dms/strings.type.systematic')
                : __('resources/dms/strings.type.non_systematic')
            )
            ->default(true)
            ->columnSpanFull()
            ->live()
            ->helperText(fn($state) => $state
                ? __('resources/dms/strings.hints.type.systematic')
                : __('resources/dms/strings.hints.type.non_systematic')
            );
    }

    public static function users(): Select
    {
        return Select::make('users')
            ->label(__('resources/dms/strings.fields.users'))
            ->helperText(__('resources/dms/strings.fields.users_hint'))
            ->options(fn() => User::getCachedActiveOptions()->toArray())
            ->multiple()
            ->searchable()
            ->preload()
            ->nullable();
    }

    public static function version(): TextInput
    {
        return TextInput::make('version')
            ->label(__('resources/dms/strings.fields.version'))
            ->required()
            ->maxLength(50)
            ->rule(self::uniqueLiveRule())
            ->helperText(__('resources/dms/strings.hints.version'));
    }

    private static function forgeFileName(TemporaryUploadedFile $file): string
    {
        $prefix = FileNamer::prefix() . '-DMS';
        $date = now()->format('Ymd');
        $unique = Str::random(12) . '-' . time();
        $ext = $file->getClientOriginalExtension();

        $name = Str::of(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME))
            ->ascii()
            ->replaceMatches('/[^A-Za-z0-9]/', '')
            ->replace(' ', '')
            ->kebab()
            ->limit(30);

        return "{$prefix}-{$date}-{$unique}-{$name}.{$ext}";
    }

    /** (code, version) unique among LIVE docs only — attached to code/version/status alike so the warning surfaces on whichever field changed; Filament validates the whole form on submit, so the triple re-checks regardless of which of the three was edited. */
    private static function uniqueLiveRule(): Closure
    {
        return function (Get $get, $record): UniqueLiveDocument {
            $status = $get('status');

            return new UniqueLiveDocument(
                code: (string)($get('code') ?? ''),
                version: (string)($get('version') ?? ''),
                status: $status instanceof DocumentStatus ? $status->value : (string)($status ?? ''),
                exceptId: $record?->id,
            );
        };
    }
}
