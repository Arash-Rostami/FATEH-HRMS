<?php

namespace App\Filament\Resources;

use App\Filament\Resources\UserResource\Exports\UserExporter;
use App\Filament\Resources\UserResource\Pages\CreateUser;
use App\Filament\Resources\UserResource\Pages\EditUser;
use App\Filament\Resources\UserResource\Pages\ListUsers;
use App\Filament\Resources\UserResource\RelationManagers\CredentialRelationManager;
use App\Filament\Resources\UserResource\RelationManagers\EnergyTestsRelationManager;
use App\Filament\Resources\UserResource\RelationManagers\PermissionsRelationManager;
use App\Filament\Resources\UserResource\RelationManagers\ProfileRelationManager;
use App\Filament\Resources\UserResource\RelationManagers\ReportsRelationManager;
use App\Filament\Resources\UserResource\RelationManagers\ReservationsRelationManager;
use App\Filament\Resources\UserResource\RelationManagers\SkillsRelationManager;
use App\Filament\Resources\UserResource\RelationManagers\SuggestionsRelationManager;
use App\Filament\Resources\UserResource\RelationManagers\TasksRelationManager;
use App\Filament\Resources\UserResource\RelationManagers\TicketsRelationManager;
use App\Filament\Resources\UserResource\RelationManagers\WorkflowsRelationManager;
use App\Filament\Resources\UserResource\Schemas\UserFormPresenter;
use App\Filament\Resources\UserResource\Schemas\UserInfolistPresenter;
use App\Filament\Resources\UserResource\Schemas\UserTablePresenter;
use App\Models\User;
use App\Services\User\UserKeyGrouper;
use App\Traits\Filament\AuthorizesByPermission;
use App\Traits\Filament\FilamentActions;
use App\Traits\Filament\FilamentAdminGuide;
use App\Traits\Filament\FilamentFilters;
use Filament\Actions\Action;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class UserResource extends Resource
{
    use FilamentActions, FilamentFilters, AuthorizesByPermission, FilamentAdminGuide;

    protected static ?string $model = User::class;
    protected static ?string $recordTitleAttribute = 'name';
    protected static string|null|\BackedEnum $navigationIcon = 'heroicon-o-users';
    protected static ?int $navigationSort = 1;

    protected static array $guide = [
        ['label' => 'بررسی', 'icon' => 'groups', 'view' => 'filament.resources.user.guide.overview'],
        ['label' => 'دسترسی و نقش‌ها', 'icon' => 'shield_person', 'view' => 'filament.resources.user.guide.access'],
        ['label' => 'زبانه‌ها و فیلترها', 'icon' => 'filter_alt', 'view' => 'filament.resources.user.guide.list-tabs'],
        ['label' => 'کارهای مدیریتی', 'icon' => 'admin_panel_settings', 'view' => 'filament.resources.user.guide.admin-ops'],
    ];

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make(__('resources/user/strings.form.section_identity'))
                ->schema([
                    UserFormPresenter::name(),
                    UserFormPresenter::email(),
                    UserFormPresenter::emailTrusted(),
                    UserFormPresenter::divider(),
                    UserFormPresenter::password(),
                    UserFormPresenter::passwordConfirmation(),
                ])->columns(1)
                ->columnSpan(2),

            Section::make(__('resources/user/strings.form.section_access'))
                ->schema([
                    UserFormPresenter::type(),
                    UserFormPresenter::role(),
                    UserFormPresenter::presence(),
                    UserFormPresenter::divider(),
                    UserFormPresenter::status(),
                ])->columns(3)
                ->columnSpan(3),

            Section::make(__('resources/user/strings.form.section_booking'))
                ->schema([
                    UserFormPresenter::booking(),
                ])->columnSpanFull(),

            Section::make(__('resources/user/strings.form.section_extra'))
                ->schema([
                    UserFormPresenter::extra(),
                ])->columnSpanFull(),

            Section::make(__('resources/correspondence/strings.admin.user.section'))
                ->schema([
                    UserFormPresenter::signature(),
                    UserFormPresenter::signCode(),
                    UserFormPresenter::signCodePassword(),
                    UserFormPresenter::registryPermission(),
                ])->columns(2)
                ->visible(fn (string $operation): bool => $operation === 'edit' && ! tenantOffName('correspondence'))
                ->columnSpanFull(),
        ])->columns(5);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->with(['profile']);
    }

    public static function canEdit(Model $record): bool
    {
        $actor = auth()->user();

        return static::permits('update', $record) && (!$record->isDeveloper() || $actor?->isDeveloper() || $actor?->is($record));
    }

    public static function getGlobalSearchResultActions(Model $record): array
    {
        return [
            Action::make('edit')
                ->icon('heroicon-m-pencil')
                ->url(static::getUrl('edit', ['record' => $record])),
        ];
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            'ایمیل' => $record->email,
        ];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return $record->name;
    }

    public static function getGlobalSearchResultUrl(Model $record): string
    {
        return static::getUrl('edit', ['record' => $record]);
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['name', 'email'];
    }

    public static function getModelLabel(): string
    {
        return __('resources/user/strings.navigation.singular');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('resources/user/strings.navigation.group');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListUsers::route('/'),
            'create' => CreateUser::route('/create'),
            'edit' => EditUser::route('/{record}/edit'),
        ];
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/user/strings.navigation.plural');
    }

    public static function getRelations(): array
    {
        return [
            ProfileRelationManager::class,
            CredentialRelationManager::class,
            PermissionsRelationManager::class,
            EnergyTestsRelationManager::class,
            ReportsRelationManager::class,
            ReservationsRelationManager::class,
            SkillsRelationManager::class,
            SuggestionsRelationManager::class,
            TasksRelationManager::class,
            TicketsRelationManager::class,
            WorkflowsRelationManager::class,
        ];
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema
            ->components([
                Tabs::make()
                    ->tabs([
                        Tabs\Tab::make(__('resources/user/strings.infolist.section_identity'))
                            ->icon('heroicon-o-user-circle')
                            ->schema([
                                Section::make()
                                    ->extraAttributes(['class' => 'fi-infolist-panel'])
                                    ->schema([
                                        UserInfolistPresenter::id(),
                                        UserInfolistPresenter::name(),
                                        UserInfolistPresenter::email(),
                                        UserInfolistPresenter::emailVerifiedAt(),
                                        UserInfolistPresenter::divider(),
                                        UserInfolistPresenter::type(),
                                        UserInfolistPresenter::role(),
                                        UserInfolistPresenter::status(),
                                        UserInfolistPresenter::presence(),
                                        UserInfolistPresenter::divider(),
                                        UserInfolistPresenter::booking(),
                                    ])->columns(3),
                            ])
                            ->columnSpanFull(),

                        Tabs\Tab::make(__('resources/user/strings.infolist.section_extra'))
                            ->icon('heroicon-o-adjustments-horizontal')
                            ->schema([
                                Section::make()
                                    ->extraAttributes(['class' => 'fi-infolist-panel'])
                                    ->schema([
                                        UserInfolistPresenter::extra(),
                                        UserInfolistPresenter::divider(),
                                        UserInfolistPresenter::lastSeen(),
                                        UserInfolistPresenter::createdAt(),
                                        UserInfolistPresenter::updatedAt(),
                                    ])->columns(3),
                            ])
                            ->columnSpanFull(),
                    ])
                    ->columnSpanFull()
                    ->persistTabInQueryString()
                    ->extraAttributes(['class' => 'fi-infolist-panel']),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                UserTablePresenter::id(),
                UserTablePresenter::avatar(),
                UserTablePresenter::name(),
                UserTablePresenter::status(),
                UserTablePresenter::role(),
                UserTablePresenter::type(),
                UserTablePresenter::email(),
                UserTablePresenter::presence(),
                UserTablePresenter::lastSeen(),
                UserTablePresenter::createdAt(),
            ])
            ->groups([
                UserTablePresenter::statusGroup(),
                UserTablePresenter::roleGroup(),
                UserTablePresenter::presenceGroup(),
                ...UserKeyGrouper::groups(),
            ])
            ->filters([
                UserTablePresenter::statusFilter(),
                UserTablePresenter::roleFilter(),
                UserTablePresenter::typeFilter(),
                UserTablePresenter::presenceFilter(),
                self::createdAtFilter(),
                ...UserKeyGrouper::filters(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                Action::make('tasksheet')
                    ->label('مشاهده تسک‌شیت')
                    ->icon('heroicon-o-arrow-top-right-on-square')
                    ->iconButton()
                    ->url(fn($record) => route('tasksheet', ['user' => $record->id]))
                    ->openUrlInNewTab(),
                UserTablePresenter::shareTasksheet(),
                self::viewAction(),
                self::editAction(),
                UserTablePresenter::toggleStatusAction(),
            ], RecordActionsPosition::AfterCells)
            ->recordClasses(fn($record) => $record->isActive() ? null : 'opacity-60')
            ->striped()
            ->groupedBulkActions([
                UserTablePresenter::bulkDeactivateAction(),
                self::bulkExportAction(UserExporter::class),
            ])
            ->emptyStateIcon('heroicon-o-bookmark')
            ->defaultSort('id', 'desc');
    }
}
