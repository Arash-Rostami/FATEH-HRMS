<?php

namespace App\Filament\Resources\PermissionResource\Pages;

use App\Filament\Resources\PermissionResource;
use App\Traits\Filament\FilamentPageBehavior;
use App\Filament\Pages\CreateRecord;

class CreatePermission extends CreateRecord
{
    use FilamentPageBehavior;

    protected static string $resource = PermissionResource::class;
}
