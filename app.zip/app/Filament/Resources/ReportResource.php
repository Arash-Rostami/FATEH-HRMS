<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ReportResource\Exports\ReportExporter;
use App\Filament\Resources\ReportResource\Pages\CreateReport;
use App\Filament\Resources\ReportResource\Pages\EditReport;
use App\Filament\Resources\ReportResource\Pages\ListReports;
use App\Filament\Resources\ReportResource\Schemas\ReportFormPresenter;
use App\Filament\Resources\ReportResource\Schemas\ReportInfolistPresenter;
use App\Filament\Resources\ReportResource\Schemas\ReportTablePresenter;
use App\Models\Report;
use App\Traits\Filament\AuthorizesByPermission;
use App\Traits\Filament\FilamentActions;
use App\Traits\Filament\FilamentAdminGuide;
use App\Traits\Filament\FilamentFilters;
use App\Traits\Filament\FilamentResourceSwitch;
use App\Traits\Filament\FilamentVisibility;
use Filament\Actions\Action;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Schema;
use Filament\Tables\Enums\RecordActionsPosition;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class ReportResource extends Resource
{
    use FilamentAdminGuide, FilamentActions, FilamentFilters, FilamentVisibility, AuthorizesByPermission, FilamentResourceSwitch;

    protected static function switchGroup(): array
    {
        return array_values(array_filter(
            [self::class, MediaResource::class, KnowledgeProgressResource::class, AiReportResource::class],
            fn (string $resource) => ! tenantOffName($resource::getSlug())
                && ! (in_array($resource, [MediaResource::class, KnowledgeProgressResource::class], true) && tenantOff('knowledge:media'))
        ));
    }

    public static function knowledgeEntry(): ?string
    {
        foreach ([self::class, MediaResource::class, KnowledgeProgressResource::class] as $resource) {
            if (! tenantOffName($resource::getSlug())
                && ! ($resource !== self::class && tenantOff('knowledge:media'))
                && $resource::canViewAny()) {
                return $resource;
            }
        }

        return null;
    }

    public static function shouldRegisterNavigation(): bool
    {
        return static::knowledgeEntry() === static::class;
    }

    public static function getNavigationLabel(): string
    {
        return __('resources/report/strings.nav_label');
    }

    protected static ?string $model = Report::class;
    protected static ?string $recordTitleAttribute = 'title';
    protected static string|null|\BackedEnum $navigationIcon = 'heroicon-o-presentation-chart-line';
    protected static ?int $navigationSort = 5;

    protected static array $guide = [
        ['label' => 'بررسی', 'icon' => 'description', 'view' => 'filament.resources.report.guide.overview'],
        ['label' => 'کارهای مدیریتی', 'icon' => 'admin_panel_settings', 'view' => 'filament.resources.report.guide.admin-ops'],
        ['label' => 'دسترسی واحدها', 'icon' => 'lock', 'view' => 'filament.resources.report.guide.visibility'],
        ['label' => 'زبانه‌های فهرست و فیلترها', 'icon' => 'filter_list', 'view' => 'filament.resources.report.guide.list-tabs'],
        ['label' => 'تجربهٔ کاربر', 'icon' => 'visibility', 'view' => 'filament.resources.report.guide.user'],
    ];

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Tabs::make()
                ->tabs([
                    Tab::make(__('resources/report/strings.form.tab_main'))
                        ->icon('heroicon-o-information-circle')
                        ->schema([
                            Section::make(__('resources/report/strings.form.section_main'))
                                ->description(__('resources/report/strings.form.section_description'))
                                ->icon('heroicon-o-document-text')
                                ->schema([
                                    ReportFormPresenter::title(),
                                    ReportFormPresenter::departmentId(),
                                    ReportFormPresenter::departments(),
                                    ReportFormPresenter::userId(),
                                    ReportFormPresenter::active(),
                                    ReportFormPresenter::pinned(),
                                    ReportFormPresenter::divider(),
                                    ReportFormPresenter::reportDate(),
                                    ReportFormPresenter::expiresAt(),
                                    ReportFormPresenter::divider(),
                                    ReportFormPresenter::description(),
                                ])
                                ->columns(2)
                                ->columnSpanFull(),
                        ]),

                    Tab::make(__('resources/report/strings.form.tab_files'))
                        ->icon('heroicon-o-paper-clip')
                        ->schema([
                            Section::make(__('resources/report/strings.form.section_files'))
                                ->icon('heroicon-o-folder-open')
                                ->schema([
                                    ReportFormPresenter::coverImage(),
                                    ReportFormPresenter::divider(),
                                    ReportFormPresenter::filePath(),
                                ])
                                ->columns(2)
                                ->columnSpanFull(),
                        ]),
                ])
                ->columnSpanFull()
                ->persistTabInQueryString(),
        ]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->with(['department', 'user']);
    }

    public static function getGlobalSearchResultActions(Model $record): array
    {
        return [
            Action::make('edit')
                ->icon('heroicon-m-pencil')
                ->url(static::getUrl('edit', ['record' => $record])),
        ];
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            __('resources/report/strings.fields.department') => $record->department?->displayLabel() ?? '-',
            __('resources/report/strings.fields.user') => $record->user?->name ?? '-',
        ];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return $record->title;
    }

    public static function getGlobalSearchResultUrl(Model $record): string
    {
        return static::getUrl('edit', ['record' => $record]);
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['title', 'description'];
    }

    public static function getModelLabel(): string
    {
        return __('resources/report/strings.label');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('resources/report/strings.nav_group');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListReports::route('/'),
            'create' => CreateReport::route('/create'),
            'edit' => EditReport::route('/{record}/edit'),
        ];
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/report/strings.plural_label');
    }

    public static function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()
                ->extraAttributes(['class' => 'fi-infolist-panel'])
                ->hiddenLabel()
                ->schema([
                    ReportInfolistPresenter::thumbnail(),
                    ReportInfolistPresenter::title(),
                    ReportInfolistPresenter::description(),

                    ReportInfolistPresenter::divider(),
                    ReportInfolistPresenter::department(),
                    ReportInfolistPresenter::audience(),
                    ReportInfolistPresenter::user(),
                    ReportInfolistPresenter::fileType(),

                    ReportInfolistPresenter::divider(),
                    ReportInfolistPresenter::active(),
                    ReportInfolistPresenter::pinned(),

                    ReportInfolistPresenter::divider(),
                    ReportInfolistPresenter::reportDate(),
                    ReportInfolistPresenter::expiresAt(),
                    ReportInfolistPresenter::createdAt(),
                    ReportInfolistPresenter::updatedAt(),
                ])
                ->columnSpanFull()
                ->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                ReportTablePresenter::id(),
                ReportTablePresenter::title(),
                ReportTablePresenter::department(),
                ReportTablePresenter::audience(),
                ReportTablePresenter::user(),
                ReportTablePresenter::fileType(),
                self::activeColumn(),
                ReportTablePresenter::pinned(),
                ReportTablePresenter::reportDate(),
                ReportTablePresenter::createdAt(),
            ])
            ->groups([
                ReportTablePresenter::activeGroup(),
                ReportTablePresenter::departmentGroup(),
                ReportTablePresenter::pinnedGroup(),
            ])
            ->filters([
                ReportTablePresenter::activeFilter(),
                ReportTablePresenter::departmentFilter(),
                ReportTablePresenter::visibilityFilter(),
                ReportTablePresenter::pinnedFilter(),
                ReportTablePresenter::reportDateRangeFilter(),
                self::createdAtFilter(),
            ])
            ->filtersFormColumns(2)
            ->recordActions([
                self::viewAction(),
                self::editAction(),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells)
            ->groupedBulkActions([
                ...self::bulkActions(ReportExporter::class),
                ReportTablePresenter::shareWithDepartmentsBulkAction(),
                ...self::bulkVisibilityActions(),
            ])
            ->emptyStateIcon('heroicon-o-bookmark')
            ->defaultSort('created_at', 'desc')
            ->striped();
    }
}
