<?php

namespace App\Filament\Resources\ReportResource\Schemas;

use App\Models\Department;
use App\Services\PersianDateFieldService;
use App\Support\FileNamer;
use App\Traits\Filament\FilamentFormDivider;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\RichEditor\TextColor;
use Filament\Forms\Components\RichEditor\ToolbarButtonGroup;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Components\FusedGroup;
use Livewire\Features\SupportFileUploads\TemporaryUploadedFile;

class ReportFormPresenter
{
    use FilamentFormDivider;

    public static function active(): Toggle
    {
        return Toggle::make('active')
            ->label(__('resources/report/strings.fields.active'))
            ->default(true)
            ->helperText(__('resources/report/strings.hints.active'))
            ->inline(false);
    }

    public static function coverImage(): FileUpload
    {
        return FileUpload::make('cover_image')
            ->label(__('resources/report/strings.fields.cover_image'))
            ->image()
            ->downloadable()
            ->openable()
            ->previewable()
            ->disk('public')
            ->directory('reports/covers')
            ->imageEditor()
            ->maxSize(config('file_upload_limits.image'))
            ->getUploadedFileNameForStorageUsing(
                fn(TemporaryUploadedFile $file): string => FileNamer::stored('report', $file)
            )
            ->nullable()
            ->helperText(__('resources/report/strings.hints.cover_image'));
    }

    public static function departmentId(): Select
    {
        return Select::make('department_id')
            ->label(__('resources/report/strings.fields.department'))
            ->options(fn() => Department::getCachedOptions()->toArray())
            ->searchable()
            ->nullable()
            ->helperText(__('resources/report/strings.hints.department_id'));
    }

    public static function departments(): Select
    {
        return Select::make('departments')
            ->label(__('resources/report/strings.fields.departments'))
            ->options(fn() => Department::getCachedOptions()->toArray())
            ->multiple()
            ->searchable()
            ->preload()
            ->nullable()
            ->helperText(__('resources/report/strings.hints.departments'));
    }

    public static function pinned(): Toggle
    {
        return Toggle::make('pinned')
            ->label(__('resources/report/strings.fields.pinned'))
            ->default(false)
            ->inline(false)
            ->helperText(__('resources/report/strings.hints.pinned'));
    }

    public static function reportDate(): FusedGroup
    {
        return PersianDateFieldService::make(
            prefix: 'report_date',
            label: __('resources/report/strings.fields.report_date'),
            required: false,
            yearFrom: 1380,
            fullWidth: true,
        )->helperText(__('resources/report/strings.hints.report_date'));
    }

    public static function expiresAt(): FusedGroup
    {
        return PersianDateFieldService::make(
            prefix: 'expires_at',
            label: __('resources/report/strings.fields.expires_at'),
            required: false,
            yearFrom: 1380,
            fullWidth: true,
        )->helperText(__('resources/report/strings.hints.expires_at'));
    }

    public static function description(): RichEditor
    {
        return RichEditor::make('description')
            ->label(__('resources/report/strings.fields.description'))
            ->nullable()
            ->maxLength(65535)
            ->columnSpanFull()
            ->placeholder(__('resources/report/strings.placeholders.description'))
            ->helperText(__('resources/report/strings.helper_text.description'))
            ->textColors([
                'primary' => TextColor::make('Primary', '#1D4ED8', darkColor: '#60a5fa'),
                'success' => TextColor::make('Success', '#15803D', darkColor: '#4ade80'),
                'warning' => TextColor::make('Warning', '#B45309', darkColor: '#fbbf24'),
                'danger' => TextColor::make('Danger', '#B91C1C', darkColor: '#f87171'),
                ...TextColor::getDefaults(),
            ])
            ->extraInputAttributes(['class' => 'fi-prose', 'style' => 'min-height: 280px;'])
            ->customTextColors()
            ->toolbarButtons([
                ['textColor', 'bold', 'italic', 'underline', 'strike', 'subscript', 'superscript', 'code', 'clearFormatting'],
                [ToolbarButtonGroup::make('Headings', ['paragraph', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
                    ->icon('fi-o-heading')
                    ->textualButtons()],
                [ToolbarButtonGroup::make('Alignment', ['alignStart', 'alignCenter', 'alignEnd', 'alignJustify'])],
                ['blockquote', 'bulletList', 'orderedList'],
                ['codeBlock', 'horizontalRule', 'highlight', 'small'],
                ['link'],
                ['table'],
                ['undo', 'redo'],
            ])
            ->floatingToolbars([
                'paragraph' => ['textColor', 'bold', 'italic', 'underline', 'strike', 'link', 'highlight'],
                'heading' => ['h1', 'h2', 'h3', 'alignStart', 'alignCenter', 'alignEnd'],
                'table' => [
                    'tableAddColumnBefore', 'tableAddColumnAfter', 'tableDeleteColumn',
                    'tableAddRowBefore', 'tableAddRowAfter', 'tableDeleteRow',
                    'tableMergeCells', 'tableSplitCell', 'tableToggleHeaderRow', 'tableDelete',
                ],
            ]);
    }

    public static function filePath(): FileUpload
    {
        return FileUpload::make('file_path')
            ->label(__('resources/report/strings.fields.file_path'))
            ->downloadable()
            ->openable()
            ->previewable()
            ->disk('public')
            ->directory('reports/files')
            ->acceptedFileTypes([
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/vnd.ms-excel',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-powerpoint',
                'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            ])
            ->maxSize(config('file_upload_limits.document'))
            ->getUploadedFileNameForStorageUsing(
                fn(TemporaryUploadedFile $file): string => FileNamer::stored('report', $file)
            )
            ->required()
            ->helperText(__('resources/report/strings.hints.file_path'));
    }

    public static function title(): TextInput
    {
        return TextInput::make('title')
            ->label(__('resources/report/strings.fields.title'))
            ->required()
            ->maxLength(255)
            ->helperText(__('resources/report/strings.hints.title'));
    }

    public static function userId(): Select
    {
        return Select::make('user_id')
            ->label(__('resources/report/strings.fields.user'))
            ->relationship('user', 'name', fn($query, $get) => $query->visibleOnBoardOr($get('user_id')))
            ->searchable()
            ->preload()
            ->helperText(__('resources/report/strings.hints.user_id'))
            ->required();
    }
}
