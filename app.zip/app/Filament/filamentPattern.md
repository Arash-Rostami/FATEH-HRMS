# Filament 5 Module Structure Guide

Preferred module structure for a Filament PHP 5 resource — each concern isolated, reusable, and consistent with the Livewire module pattern used elsewhere.

> Before implementing, study the latest Filament PHP 5 docs: https://filamentphp.com/docs/5.x/resources/overview

Filament's resource model centers on a main resource class plus dedicated `Pages`; tables hold columns/filters/groups/actions; forms and infolists are schema-driven UI; relation managers manage related records inside a resource.

---

## Core idea

Each module is organized around a main `Resource` class that acts as the entry point — it only composes the module and defines page registration, query behavior, and high-level layout. The resource does **not** contain inline form/table/infolist definitions; it calls static methods from dedicated schema classes (presenters).

---

## Recommended structure

```text
App/
└── Filament/
    └── Resources/
        └── UserResource/
            ├── UserResource.php
            ├── Pages/
            │   ├── ListUsers.php
            │   ├── CreateUser.php
            │   ├── EditUser.php
            │   └── ViewUser.php
            ├── Schemas/
            │   ├── UserFormPresenter.php
            │   ├── UserTablePresenter.php
            │   ├── UserInfolistPresenter.php
            │   └── Grouping/
            │       └── SomeComplexGroup.php
            ├── Actions/
            │   └── StoreUserAction.php
            ├── Exports/
            │   └── UserExporter.php
            └── RelationManagers/
                └── RolesRelationManager.php

App/
├── Enums/                      (all enums, flat)
└── Traits/
    ├── Filament/               (21 admin-only traits: AuthorizesByPermission, FilamentActions, FilamentAdminGuide, FilamentFilters, FilamentHeaderActions, FilamentPageBehavior, HandlesDroppedFiles, ...)
    ├── Livewire/               (13 user-panel traits: AuthValidationRules, FocusOnRecord, ChatComposer, ManagesTaskModal, ...)
    └── (root)                  CleansAttachedFiles, StoresAttachedFiles, DepartmentAxis, ResolvesTaskDeadline
```

### Key structural rules

- **Filters are merged into `UserTablePresenter.php`** — no separate Filters folder.
- **Grouping logic with non-trivial queries lives in `Schemas/Grouping/`** as a dedicated class.
- **Forms, Tables, and Infolists live under `Schemas/`**.
- **Names are intentionally module-qualified**: `UserFormPresenter`, `UserTablePresenter`, `UserInfolistPresenter`.
- **Pages are flexible**: a resource may have `Manage`, `Create`, `Edit`, `List`, and `View` pages.
- **Actions are optional** and used only when a module needs reusable write operations.
- **No Validators folder**: *simple* validation rules and messages stay inside each field method as fluent chain calls (`->required()`, `->maxLength()`, `->email()`, `->unique()` on a plain column, etc.). *Complex* validation — cross-field checks, DB-backed uniqueness beyond a plain column, business-rule thresholds — is extracted to `App\Rules\*` (a top-level, project-wide folder, not Filament-specific). See "Extracting validation logic to `App\Rules`" below for the criteria and the two established shapes.
- **Shared cross-cutting behavior lives in Traits** (admin-only traits live in `app/Traits/Filament/`; traits shared with Models/Services or the user panel sit in the `app/Traits/` root, e.g. `CleansAttachedFiles`/`StoresAttachedFiles` (Rules 67/68 below); Livewire-only ones such as `ChatComposer` are in `app/Traits/Livewire/`; home rule: `app/Traits/traitPattern.md` §3): `FilamentActions`, `FilamentFilters`, `AuthorizesByPermission`, `FilamentHeaderActions`, `FilamentPageBehavior`, `FilamentEditHeading` (Edit pages only), `FilamentPreferences`, `FilamentVisibility`, `FilamentIconOptions`, and `FilamentAdminGuide` (applied to all 31 resources, `NotifyRuleResource` included — the `moduleGuide` modal; full spec in §3.4). `FilamentViewActionDefaults` is the provider-registered exception — not mixed into any resource (§3.5). **`FilamentResourceSwitch` belongs ONLY to the PRIMARY resource of a switch group** (it declares the abstract `switchGroup()`): a SECONDARY resource (`AiReportResource`, `MediaResource`, `KnowledgeProgressResource`) must NOT use the trait — it hides itself with `shouldRegisterNavigation()` (`! Primary::canViewAny() && ! tenantOffName(static::getSlug())`; the Knowledge group is the exception — `Media`/`KnowledgeProgress` use `ReportResource::knowledgeEntry() === static::class` and `AiReportResource` uses `knowledgeEntry() === null`) and its list page prepends `Primary::switchActions(static::$resource)`. Using the trait on a secondary makes the class fatal at load (abstract method not implemented), which takes down EVERY request and artisan command at Filament resource discovery (found 2026-11-21 when the Media resources were first booted; verify any new resource with `php artisan --version`). The remaining traits (`FilamentDateHandler`, `FilamentFormDivider`, `FilamentPreferences`) are narrower helpers documented in their own sections below.

---

## Responsibility of each part

### 1) Main Resource

The main resource is the module orchestrator.

It should:

- define the model, navigation icon, navigation sort, navigation group
- define localized model labels (`getModelLabel`, `getPluralModelLabel`)
- define high-level schema composition: tabs, sections, accordions — structural layout only, not field logic
- define query behavior (`getEloquentQuery`) with all eager-loaded relationships
- define global search attributes, result title, details, URL, and actions
- define page routes
- delegate form/table/infolist logic entirely to schema classes
- use `FilamentActions` trait for centralized action methods

> All relationships MUST be eager-loaded inside `getEloquentQuery` for performance. When using `withCount`, add it here too.

Example:

```php
class DepartmentResource extends Resource
{
    use FilamentActions;

    protected static ?string $model = Department::class;
    protected static string|null|BackedEnum $navigationIcon = 'heroicon-o-building-office-2';
    protected static ?int $navigationSort = 5;

    public static function getModelLabel(): string
    {
        return __('resources/department/strings.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('resources/department/strings.plural_label');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('resources/department/strings.nav_group');
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['code', 'name', 'description'];
    }

    public static function getGlobalSearchResultTitle(Model $record): string
    {
        return $record->name;
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            __('resources/department/strings.fields.code') => $record->code,
        ];
    }

    public static function getGlobalSearchResultUrl(Model $record): string
    {
        return static::getUrl('edit', ['record' => $record]);
    }

    public static function getGlobalSearchResultActions(Model $record): array
    {
        return [
            Action::make('edit')
                ->icon('heroicon-m-pencil')
                ->url(static::getUrl('edit', ['record' => $record])),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->withCount('users');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make(__('resources/department/strings.form.section_main'))
                ->icon('heroicon-o-building-office-2')
                ->description(__('resources/department/strings.form.section_description'))
                ->schema([
                    DepartmentFormPresenter::code(),
                    DepartmentFormPresenter::name(),
                    DepartmentFormPresenter::description(),
                    DepartmentFormPresenter::divider(),
                    DepartmentFormPresenter::units(),
                    DepartmentFormPresenter::sections(),
                ])
                ->columns(2)
                ->columnSpan(2),

            Section::make(__('resources/department/strings.form.section_structure'))
                ->icon('heroicon-o-squares-2x2')
                ->schema([
                    DepartmentFormPresenter::level(),
                    DepartmentFormPresenter::subordinateTo(),
                ])
                ->columns(1),

            Section::make(__('resources/department/strings.form.section_tickets'))
                ->icon('heroicon-o-ticket')
                ->schema([
                    DepartmentFormPresenter::ticketOptions(),
                ])
                ->columnSpanFull(),
        ])->columns(3);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                DepartmentTablePresenter::id(),
                DepartmentTablePresenter::code(),
                DepartmentTablePresenter::name(),
                DepartmentTablePresenter::description(),
                DepartmentTablePresenter::usersCount(),
                DepartmentTablePresenter::createdAt(),
            ])
            ->groups([DepartmentTablePresenter::usersCountGroup()])
            ->filters([
                DepartmentTablePresenter::hasUsersFilter(),
                DepartmentTablePresenter::createdAtFilter(),
            ])
            ->recordActions([
                self::viewAction(),
                self::editAction(),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells)
            ->groupedBulkActions(self::bulkActions(DepartmentExporter::class))
            ->emptyStateIcon('heroicon-o-bookmark')
            ->defaultSort('name');
    }

    public static function infolist(Schema $schema): Schema
    {
        // Section stays unlabeled — see "Infolist layout — Section/Tabs discipline" below (§2.3)
        return $schema->components([
            Section::make()
                ->schema([
                    DepartmentInfolistPresenter::code(),
                    DepartmentInfolistPresenter::name(),
                    DepartmentInfolistPresenter::usersCount(),
                    DepartmentInfolistPresenter::description(),
                    DepartmentInfolistPresenter::createdAt(),
                    DepartmentInfolistPresenter::updatedAt(),
                ])
                ->columnSpanFull()
                ->columns(2),
        ]);
    }

    public static function getRelations(): array
    {
        return [UsersRelationManager::class];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListDepartments::route('/'),
            'create' => CreateDepartment::route('/create'),
            'edit' => EditDepartment::route('/{record}/edit'),
        ];
    }
}
```

**Custom classification + full export (THS, 2026-10-14).** A ticket's `request_type`/`request_area` may be department-defined (`Department::ticket_options`), so admin surfaces never read the static `Ticket::$requestAreaOptions` or the `RequestType` enum alone: labels come from `Ticket::getCustomRequestTypeLabel()` / `getCustomRequestAreaLabel()` (with `extra.target_department`), and filters from `Ticket::requestTypeFilterOptions()` / `requestAreaFilterOptions()` (defaults + every department's custom keys + every distinct value present in tickets, independent multi-select, no cascade; label resolver and fallback order: thsPattern item 10). The Area column is visible by default; Type/Area search by raw key OR any label and sort by label; `ThsExporter` adds `request_type_key` / `request_area_key` beside the label columns. `ThsExporter` exports the full record set (descriptions, custom labels, replies, files); Export goes only through the default bulk export action on `ThsExporter` (no separate header `ExportAction`; "select all" exports the whole filtered query, all departments).

**THS insight tabs (2026-10-16).** `ThsResource::infolist()` has two extra read-only tabs after «پاسخ و نتیجه»: «تحلیل این تیکت» (a `ViewEntry` + the existing effectiveness/satisfaction/action-result entries) and «خلاصهٔ واحد» (a `ViewEntry`). Both `ViewEntry`s take their state from `App\Services\Ticket\TicketInsightsService` (never compute in the presenter/blade) and render the shared `filament.resources.ths.insights.*` partials (Filament `x-filament::badge` cards, `wire:key` on every conditional branch). THS has no View page — the infolist is the list's view modal, so links to other tickets go to `edit`. Details: thsPattern item 12.

**Form layout — multi-card discipline (added 2026-09-21).** Never ship a single full-width Section carrying all of a resource's fields. Split by domain into two or more cards and play the widths on a shared root grid: a fat content card at `->columnSpan(2)` beside a slim `->columnSpan(1)` settings rail on a `->columns(3)` root (Post and now `DepartmentResource::form()` are the references), or a 50/50 `Grid::make(2)` for two equal-weight domains (`SuggestionResource::form()`). Wide components that need horizontal room (multi-column `Repeater`s, full rich text) go in their own `columnSpanFull()` card below the pair — never squeezed into the rail. Fields that cross-talk via `Get`/`Set` (`level` + `subordinate_to`) belong in the SAME card so their interaction is visible.

When the resource has many fields, use tabs in form and infolist to group logically connected data:

```php
public static function form(Schema $schema): Schema
{
    return $schema->components([
        Tabs::make()
            ->tabs([
                Tab::make(__('resources/profile/strings.form.section_identity_header'))
                    ->icon('heroicon-o-user-circle')
                    ->schema([
                        Section::make(__('resources/profile/strings.form.section_identity'))
                            ->schema([
                                ProfileFormPresenter::personnelId(),
                                ProfileFormPresenter::gender(),
                                // ...
                            ])
                            ->columns(2)
                            ->columnSpan(1),

                        Section::make(__('resources/profile/strings.form.section_contact'))
                            ->icon('heroicon-o-phone')
                            ->schema([
                                ProfileFormPresenter::cellphone(),
                                // ...
                            ])
                            ->columns(2)
                            ->columnSpan(1),
                    ])
                    ->columns(2),

                Tab::make(__('resources/profile/strings.form.section_media'))
                    ->icon('heroicon-o-paper-clip')
                    ->schema([
                        ProfileFormPresenter::image(),
                        ProfileFormPresenter::attachments(),
                    ])
                    ->columns(2),
            ])
            ->columnSpanFull()
            ->persistTabInQueryString(),
    ]);
}
```

---

### 2) Schema classes (Dedicated Classes, NOT traits)

The `Schemas/` folder contains reusable UI definitions for the resource.

These classes are the Filament equivalent of the Livewire presentation layer: pure UI composition, no business writes.

#### 2.1 Form schema

One method per input component. Validation and messages live inside the method.

```php
class UserFormPresenter
{
    public static function name(): TextInput
    {
        return TextInput::make('name')
            ->label(__('resources/user/strings.form.name'))
            ->required()
            ->maxLength(255);
    }
}
```

##### Reactive / mutually-exclusive fields

When two fields are mutually exclusive (only one should hold a value at a time — e.g. `GalleryFormPresenter` `department_id` single vs `departments` multi), wire both as `->live()` and cross-clear with `->afterStateUpdated(fn (Set $set) => $set('otherField', null))`. Disable the subordinate field with `->disabled(fn (Get $get) => filled($get('otherField')))`.

**Import gotcha:** in Filament v5 the closure `Get`/`Set` come from `Filament\Schemas\Components\Utilities\Get` / `Filament\Schemas\Components\Utilities\Set` — **not** `Filament\Forms\Get` (that class no longer matches what Filament injects, and the wrong import throws `Argument #1 ($get) must be of type Filament\Forms\Get, Filament\Schemas\Components\Utilities\Get given`). This is the import every `*FormPresenter` in this repo uses.

In Filament v5 a **disabled field is not dehydrated by default** (see `ContactFormPresenter` `->disabled()->dehydrated(false)`). To persist the cleared (`null`) value of a disabled field instead of silently keeping the old DB value, add `->dehydrated(true)` (see `FAQFormPresenter`). This is mandatory whenever the disabled state must produce a saved `null`.

```php
Select::make('department_id')
    ->live()
    ->disabled(fn (Get $get) => filled($get('departments')))
    ->dehydrated(true)
    ->afterStateUpdated(fn (Set $set) => $set('departments', null));
```

##### Browser-only hide with `hiddenJs()` (2026-11-25)

When a field or section only needs to disappear based on a sibling field (no `->live()` needed on the sibling — `hiddenJs`/`visibleJs` read the browser state, so the Media `kind` select dropped its `->live()` and its round trip; keep `->live()` only where the server must react, e.g. the file upload's duration probe), `->hiddenJs('$get(\'kind\') === \'series\'')` hides it in the browser with no server round-trip (`MediaResource` Files tab: file, duration, tracks hidden for a series; episodes form untouched because its kind is audio/video only). The field is NOT cleared by this and still submits its state, so pair it with the data-layer guard (`HasMediaHooks::guardStructureOnSaving` nulls the four file fields on EVERY series save, before its dirty-check return, and `cleanReplacedFilesOnUpdated` then removes the old file; converting a record that already holds a file to a series is refused with a `data.kind` error rather than silently deleting the file). A `hiddenJs` field still dehydrates, so the Media `parent_id` select also carries `dehydrateStateUsing(... kind === series ? null : $state)` (otherwise a parent picked before switching to series is submitted and refused). The file upload's `afterStateUpdated` writes `duration_seconds` (null when the probe fails) only on a real upload or removal, so the old file's length never survives a replacement and the save hook re-probes; Filament re-fires `afterStateUpdated` on every save with the stored path string, so it must NOT write unconditionally (a refused save would blank the duration). The bulk Activate/Deactivate error is prefixed with the offending record's title. The same method appends a new episode last (`position` = sibling max + 1 when `parent_id` changes and position is 0). `MediaFormPresenter::filePath()` is `required` for a non-series that is active, uses `fetchFileInformation(false)` so a stored path missing on disk does not look empty, and sets `kind` from the uploaded extension (`config('media.mimes')`). The same hook refuses turning `active` on for a fileless non-series item (`data.active`, activation moment only — a plain save of a legacy fileless row still passes), so the table toggle, bulk activate and imports are covered without wiring any consumer.

**The 2026-11-26 sweep — five more resources converted, and the stale-state dehydration rule it established.** The same conversion was applied to every remaining `->live()` whose ONLY consumer was show/hide: `Event` (`private` → `user_id` `visibleJs` + `saved(fn)` mirror, keeping the `required` closure; `enabled` → mood/confetti/messages `visibleJs`, their pre-existing `dehydrated` closures kept), `Feed` (`category` → the poll Grid + `poll_options` `visibleJs`; both got `dehydrated` mirrors, and `poll_options`' `minItems` became a closure — a JS-hidden field is still server-validated, so an unconditional `minItems(2)` would block saving a non-poll feed with a stale options list), `NotifyRule` (`events` → `extra.watch` `visibleJs` with a JS-translated `?.includes('updated')` expression + `dehydrated` mirror; departments `visibleJs` + `dehydrated` mirror + gate-mirrored `required` closure), `Reservation` (`status` → `cancel_reason` `visibleJs` + `dehydrated` mirror), `User` (`clear_sign_code` → `sign_code` `hiddenJs`, and `sign_code`'s `dehydrated` gained `&& ! $get('clear_sign_code')` so a typed-but-then-cleared code never hashes over the clear). **Rule: a `visibleJs`/`hiddenJs` conversion is NEVER complete without the server-side gate mirror of the same condition** — server `visible()` deactivates (drops state + validation), JS hiding does not, so three things must be mirrored: (1) dehydration — a `dehydrated(fn)` (or data-layer guard that runs on EVERY save path — `mergeExtra` runs only on Edit and the one-off wizard action, NOT on `CreateNotifyRule`, so it does NOT count); (2) relationship saving — for a `relationship()` select, `dehydrated(fn)` does NOT gate the write: relationship saving is a distinct pass (`BelongsToModel::saveRelationships()` → `Select.php`'s `saveRelationshipsUsing` → `associate($state)`) that skips only on server-hidden or `!isSaved()`, so use `->saved(fn ...)` on the field instead (it gates BOTH the associate pass and, via the `isDehydrated ?? isSaved()` default, dehydration — Event's `user_id`; upstream filamentphp/filament#17778); (3) validation — a JS-hidden field is still server-validated, so any unconditional `required()`, inner-Repeater `required()`, or `minLength()` on it must become a gate-mirrored closure or it blocks the save with an error the admin cannot see (NotifyRule `departments`' `required`; Feed's inner poll `option` `required` via `$get('../../category')`; User `sign_code`'s `minLength` → 0 when clear is toggled). Guard tests: `EventResourceTest::test_public_event_create_drops_a_stale_user_id`, `FeedResourceTest::test_non_poll_feed_create_drops_stale_poll_state`, `ReservationResourceTest::test_active_reservation_create_drops_a_stale_cancel_reason`, `UserResourceTest::test_clearing_the_sign_code_wins_over_a_stale_sign_code_field`. Two suspects audited and cleared as LEGITIMATE `live()` (do not remove): `PermissionFormPresenter`'s abilities-Repeater `module` select (its pick refreshes the repeater item's server-rendered header label) and `ResourceFormPresenter::showTime()` (the time-slot pickers' server `visible()` reads `$livewire->data['show_time']`, and `isFullDay()` is DB-backed enum logic that cannot run in the browser). A third keep, found by the independent review pass: `NotifyRule`'s `extra.audience` Radio RETAINS `->live()` — the one-off send wizard's step-2 summary is a server-evaluated `Text` closure reading the audience (`SendMessageAction.php`), and this Filament version has no `JsContent`/client-side content utility to replace that re-render, so removing the Radio's round-trip would leave the wizard summary stale; its departments consumer stays `visibleJs` regardless. The second review pass and the external third pass (validated against vendor + the bundled `vendor/filament/forms/docs/23-validation.md`) finalized the rules: (1) Feed's `poll_mode` joined the gate-mirrored required set (its never-null default made the unconditional `required` latent rather than blocking). (2) A consumer whose SERVER `visible()` must turn TRUE (a Section that has to APPEAR) cannot be JS-gated — the browser cannot render what the server never sent, so the gate field KEEPS its `->live()`: `Event`'s `private` toggle retains `live()` because its countdown Section is server-`visible(!private)` and must appear when «خصوصی» turns off (a first attempt at a `visibleJs` mirror on the Section only fixed the hide direction and left the reveal broken until reload — third-pass finding). JS-gating is safe only for consumers that are always server-rendered and merely HIDE (`user_id`, mood/confetti/messages, the poll block, departments, watch, cancel_reason, sign_code). (3) Every field carrying a `dehydrated(fn)`/`saved(fn)` gate ALSO gets `->validatedWhenNotDehydrated(false)` — the documented companion (bundled validation docs: "When a field is not saved, it is still validated. To disable validation for fields that are not saved, use the validatedWhenNotDehydrated() method"), restoring the old server-hidden validation skip wholesale so a stale hidden value (a too-long sign code, a stale watch/departments entry, a stale cancel reason, a non-poll maxItems/maxLength) can never block a save invisibly; the gate-mirrored required/minLength closures stay as the readable secondary layer. (4) Some gate closures are deliberately redundant — e.g. `user_id`'s `visibleJs` with `private` back on `live()`, and the required closures beside the flag — kept as harmless belt-and-braces. Pins added/extended across the passes: `test_private_event_create_persists_the_audience_user`, `test_private_event_without_an_audience_user_is_refused`, `test_non_poll_feed_create_drops_stale_poll_state` (a single blank stale row pins the minItems gate and the inner required gate; the dehydration drop itself is DOUBLY guarded — the mirror plus `packPollSettings`, which already nulls poll options for non-poll feeds — so the test proves the validation gates, not the drop), `test_create_drops_a_stale_watch_list_without_the_updated_event`, `test_updated_event_with_a_model_persists_the_watch_list`, `test_departments_audience_persists_the_selected_departments`, `test_departments_audience_without_a_selection_is_refused`, `test_cancelled_reservation_persists_the_cancel_reason`, `test_clearing_the_sign_code_wins_over_a_stale_sign_code_field` (a SHORT stale code, so the length gate is actually exercised), and `test_short_sign_code_without_the_clear_toggle_still_fails` (the gate never over-relaxes validation when the field is visible).

##### Toggle-driven mutual exclusion (Permission `is_super_admin`)

When one **boolean toggle** decides which of two *sections* is authoritative (not a field disabled by another field), the form-side cross-clear goes on the toggle itself, branching on the new state: `PermissionFormPresenter::isSuperAdmin()` uses `->afterStateUpdated(function (Set $set, ?bool $state) { $set($state ? 'abilities' : 'excluded_modules', null); })`, and each section is `->visible(fn (Get $get) => (bool)$get('is_super_admin'))` / `!$get(...)`. The same presenter is reused by both `PermissionResource::form()` and the `UserResource` `PermissionsRelationManager::form()`, so the one edit covers both.

Because `Permission::can()` ignores `abilities` while `is_super_admin` is true and ignores `excluded_modules` while it is false, a row carrying a value on the dead side is **misleading** (reads as "granted" but is never consulted). The form clear only fires on toggle interaction, so the invariant is **also enforced at the data layer** in `Permission::booted()` via a `static::saving` hook that nulls the inactive side — this guarantees a clean row regardless of which form path wrote it and cleans up any stale row on its next save. Prefer this two-layer (UX + model) approach whenever the dead-side value would otherwise be misread as a grant.

> **Full permission workflow** (role-first model, developer bypass sites, the two admin tiers, module vs action granularity, validation, caching) is documented in `app/Providers/Filament/adminPanelPermissionLogicPattern.md` — read it before changing anything in the permission chain.

##### Cross-field validation rule that re-runs when any sibling changes

When a uniqueness/consistency rule depends on **several fields together** (not just the field it's on), make the `Illuminate\Contracts\Validation\ValidationRule` **field-agnostic**: pass the whole triple (all values read from siblings via `Get` in the form) through the constructor, and have `validate()` ignore `$value` (the field's own submitted value) — the constructor is the single source of truth. Then attach the **same** `->rule(fn (Get $get, $record) => new TheRule(...$get siblings..., exceptId: $record?->id))` closure to **every** field in the triple.

Why: Filament validates the **whole form on submit**, so any one attachment already re-runs the check with the current sibling values regardless of which field the user edited. Attaching to all three is not for coverage — it is so the **failure message surfaces on the field the user actually changed**. Extract the closure into a private `static` helper (`uniqueLiveRule()` below) so each attachment is one line and the triple wiring lives in one place.

Note `->live()` only re-renders + fires `afterStateUpdated` hooks (`InteractsWithSchemas::updatedInteractsWithSchemas` → `callAfterStateUpdated`); it does **not** call `validate()`. So `->live()` alone gives no live validation — rules still run at submit. Don't add `->live()` just for validation; it only buys server round-trips.

Reference: `App\Rules\UniqueLiveDocument` — `(code, version)` must be unique among LIVE DMS docs only (non-live duplicates are allowed, so a plain DB unique index would wrongly block them; this stays form-layer). It is attached to `code`, `version`, **and** `status` in `DmsFormPresenter` via `uniqueLiveRule()`, so flipping `status` to `live`, or editing `version`, re-validates the same triple and the warning appears under the changed field.

##### Extracting validation logic to `App\Rules`

**Why a top-level folder, not `Schemas/Validators/`:** the rule class is a plain `Illuminate\Contracts\Validation\ValidationRule` with no Filament dependency — it's reusable outside the admin panel (a user-panel Livewire form, a job, an API request) if the same business rule is ever needed there. Keeping it under `App\Rules` instead of nested inside the Filament resource module keeps that reuse cheap. The Filament layer only supplies the *wiring* (a private static closure on the `*FormPresenter` that reads `Get`/`$record`/`$operation` and constructs the rule).

**Decision test — extract only when the logic is genuinely rule-shaped, not just present:**
- ✅ Extract: a private method/closure that reads **multiple sibling fields** via `Get`, or runs a **DB query** inside the validation path, or encodes a **business threshold/cap**, or is **duplicated** across two or more field definitions.
- ❌ Leave inline: a single-sibling `->required(fn (Get $get) => (bool) $get('other'))` one-liner, any closure feeding `->visible()`/`->disabled()`/`->options()`/`->formatStateUsing()` (pure UI-state/display, never fails/rejects), or a plain `Rule::unique('table','col')->ignore($record?->id)` builder call (still "simple" even with an extra `->whereNull('deleted_at')` clause, unless it starts duplicating custom PHP across resources).
- Pure data-shaping/persistence-sync logic (pack/unpack helpers, relationship-sync `saveRelationshipsUsing`, toggle-driven sibling auto-correction) is **not** extraction-worthy here even when non-trivial — it never calls `$fail()`, so it doesn't fit `ValidationRule`'s contract. That's a separate concern (Service/Action territory), not this pattern.

**Two established shapes**, both `readonly`-constructor, single terse doc-line above the class, no inline comments:

1. **Field-agnostic / cross-field** (constructor holds the whole state, `validate()` ignores `$value`) — used when the check depends on *several sibling fields together* and must re-validate identically no matter which one the same rule instance is attached to. `App\Rules\UniqueLiveDocument` (above) and `App\Rules\ExtraRequiresInternalUrl` (`LinkFormPresenter` — `extra`/`internal_url` must be filled together or both empty; attached to both fields via a `fn (Get $get) => new ExtraRequiresInternalUrl($get('extra'), $get('internal_url'))` wiring closure).
2. **Per-field / contextual** (constructor holds surrounding context — a `$record`, an `$operation`, a gating flag — and `validate()` uses `$value` normally) — used when the check is independent per field but needs create/edit-aware or record-aware context. `App\Rules\SuperAdminExclusion` (`PermissionFormPresenter` — caps excluded modules at 20%, gated by `is_super_admin`), `App\Rules\UniqueActiveSkillName` (`SkillFormPresenter` — DB-backed name-conflict check, active-only on create, any-collision on edit, shared by `name()` and `name_en()`), `App\Rules\SuggestionSubmitterNotFromMa` (`SuggestionFormPresenter::userId()` — blocks MA-department submitters; moved off `CreateSuggestion`'s page lifecycle, where it used to throw a late `ValidationException` + fire a redundant `Notification`, so the error now surfaces as a normal field error at submit time, before record creation ever starts). `App\Rules\TaskLabelLength` (`TaskFormPresenter::labels()` — caps each tag at 30 chars; **context-free**, so unlike the `Get`/`$record` rules above it wires directly as `->rule(new TaskLabelLength())` with no closure factory, and guards `!is_array($value)` because `TagsInput` can submit a non-array under edge cases). `App\Rules\FileSizeByType` (2026-10-05, also context-free — `->rules([new FileSizeByType])`) is the one rule in this catalog aimed at `FileUpload` instead of a text input: for a field that genuinely accepts more than one media category in the same slot (`GalleryFormPresenter::path()` — images AND video together), a flat `->maxSize()` forces one number onto every type, which is either too tight for video or absurdly loose for a photo. The rule reads the file's real `getMimeType()` and checks it against the matching `config('file_upload_limits.*')` tier (`image`/`video`/`document`) instead of one blanket ceiling. Only reach for it when a single field's `acceptedFileTypes()` genuinely spans tiers — a single-type field (a plain image field, a plain document field) has no ambiguity to resolve and just calls `->maxSize(config('file_upload_limits.image'))` directly, same as every other `FileUpload` in this codebase.

**Wiring convention:** keep the original field-method's private static helper name unchanged (e.g. `noNameConflictRule()`, `extraRequiresInternalUrl()`) and reduce its body to a one-line closure that constructs the new rule class — this keeps both call sites (`->rule(self::helperName())` on each field) untouched, so the extraction is a pure move, not a rename.

**Test convention:** one `tests/Feature/Rules/<RuleClass>Test.php` per rule, mirroring `SuperAdminExclusionTest`/`UniqueLiveDocumentTest` — a private `fails(Rule $rule, ...): bool` helper that calls `validate()` directly with a closure flipping a bool, no Filament/Livewire involved. Use the standard `useMysql()` + `DB::beginTransaction()`/`rollBack()` setUp/tearDown convention (see "Admin panel feature-test convention" below) for any rule touching real models; only reach for `UniqueLiveDocumentTest`'s from-scratch `Schema::create` approach when a table's migration genuinely isn't picked up by `RefreshDatabase` (DMS-specific, not the default). Add a matching resource-level feature test in the `*ResourceTest.php` only if the rule wasn't already covered end-to-end there.

**Known gotcha — a rule attached to a `->visible()`-gated field can silently never fire in one direction.** If field A is only visible when field B is filled (`->visible(fn (Get $get) => filled($get('b')))`), and the same rule is attached to both A and B: (1) Filament excludes a hidden, non-`dehydratedWhenHidden()` field from `getValidationRules()` entirely, so A's copy of the rule never runs while A is hidden; (2) independently, Laravel's own validator skips any non-`ImplicitRule` custom rule when the *attached* field's own submitted value is blank — so B's copy also skips whenever B itself is blank. Net effect: the "A filled, B blank" direction can be structurally unreachable even though the rule code is correct. This isn't a bug in the rule — it's a property of `->visible()` + non-implicit rules — but check it explicitly when a cross-field rule involves a field that's conditionally hidden by its counterpart (confirmed on `App\Rules\ExtraRequiresInternalUrl` / `LinkFormPresenter::companyIps()`).

**Known gotcha — constraining a field to a fixed enum/catalog can retroactively lock out unrelated saves on rows that already hold a stale, no-longer-valid value.** Swapping a free-form input (`ColorPicker`) for `Select::make(...)->options(EnumClass::class)` is the right minimal fix when a field should only ever hold one of N known values (`ProfileFormPresenter::favoriteColors()` → `App\Enums\FavoriteColor`, closing a bug where an off-catalog admin-set color was invisible to the user's own catalog-only checkbox UI). But Filament's `Select::getInValidationRuleValues()` builds `Rule::in([...])` from the option list, and for the field's *current* value, if it doesn't match any option, the resolved rule is `Rule::in([])` — an empty allow-list that rejects **any** value, not just the stale one. Net effect: a row that already carries a value outside the new catalog (from before the constraint existed) will fail validation the next time an admin opens Edit and saves, **even if they never touch that field** — blocking the whole save, not silently dropping the stale entry. Not a crash, no data loss, but worth an explicit prod audit for existing stale values before shipping this kind of fix (e.g. `Profile::whereNotNull('favorite_colors')->get()->filter(fn($p) => array_diff($p->favorite_colors, EnumClass::values())`) — confirmed zero such rows for `favorite_colors` at the time this was fixed). If any are found, cleaning them up needs explicit approval per the no-data-erase-without-approval policy; otherwise the forced-fix-on-next-edit behavior is an acceptable, self-healing side effect.

##### Packing virtual form fields into one JSON column

When several form controls do not map 1:1 to model columns but must be persisted together inside one JSON/array column, expose them as **virtual** Filament fields (no matching model attribute) and pack/unpack them through the resource page mutators — the same mechanism already used for `FeedResource` media (`splitMediaPaths`/`mergeMediaPaths`) and poll settings (`unpackPollSettings`/`packPollSettings`):

- `mutateFormDataBeforeFill` → `unpackX($data)` (split the stored column into the virtual fields for editing).
- `mutateFormDataBeforeCreate` and `mutateFormDataBeforeSave` → `packX($data)` (recombine the virtual fields back into the column and `unset()` the virtual keys so they never reach mass assignment).

Example: `FeedFormPresenter` stores poll mode + 2 toggles in the first 3 slots of `poll_options`, with real choices after; `Feed::extractPollSettings()` is the single source of truth for that split so the form, action, view and relation manager all agree. Always keep the split logic in one model method and reuse it — do not re-derive the format at each call site.

**Virtual sub-field names are bare — they do NOT restate the column name.** When a JSON column is named X, the virtual fields packed into it are `enabled` / `messages` (or whatever the sub-keys are), NOT `X_enabled` / `X_messages`. The column already names the feature; the prefix is redundant. `EventFormPresenter` exposes `Toggle::make('enabled')` + `Repeater::make('messages')` packed into the `events.countdown` JSON column by `Event::packCountdown`/`unpackCountdown` (read `$data['enabled']`/`$data['messages']`, write `$data['countdown'] = ['enabled'=>…,'messages'=>…]`, `unset()` the bare keys). On edit, omitted mood/confetti/messages are restored from stored countdown settings when disabled before packing. Same rule for any future JSON-column pack/unpack.

#### 2.2 Table schema

Contains: column definitions, filter definitions, group definitions, row actions and bulk actions when shared at module level, and table-level presentation logic.

All relationships MUST be eager-loaded. Table columns default to hidden unless essential. Only ID, name, status, and a few operational fields should be visible by default. Everything else is toggleable and hidden.

> **`modifyQueryUsing` closure parameter MUST be named `$query`.** Filament invokes table scopes via `HasQuery::applyQueryScopes` → `evaluate($scope, ['query' => $query, 'isResolvingRecord' => bool])`, and `EvaluatesClosures` resolves the closure's parameters **by name** against that array. A parameter named anything else (`$q`, `$builder`) misses the `'query'` key and falls back to container resolution of `Illuminate\Database\Eloquent\Builder`, which yields a model-less builder — `$query->with([...])` then fatals with `Call to a member function newQueryWithoutRelationships() on null` (HTTP 500 on the table page). Always write `fn (Builder $query) => $query->with([...])`. **Correction (2026-09-29): the previous version of this note over-claimed the exemption.** Only `TernaryFilter::queries($true, $false, $blank)`'s three inner closures are positional (`TernaryFilter::queries()` invokes `$true($query, $data)` directly, not through `evaluate()`) — `$q` is genuinely fine there, and inside a plain `->when()`. But a bare `Filter::make(...)->query($closure)` (not `queries()`) goes through the exact same by-name `evaluate()` path as `modifyQueryUsing`, `SelectFilter::query()`/relationship-query customization, and `HasRelationship`'s query callback — all inject `'query' => $query` by name via `Concerns\InteractsWithTableQuery`/`HasRelationship`. A misnamed param here has the identical silent-mutation failure mode as the `Group::orderQueryUsing`/`scopeQueryByKeyUsing` bug below: it mutates a throwaway model-less builder instead of the real query, so the filter renders successfully but silently matches everything (or nothing), no error. Caught 2026-09-29 in `ThsResource\Schemas\TicketTablePresenter::overdueFilter()` (`fn(Builder $q) => $q->whereNotNull(...)`) — the "overdue" toggle showed every ticket regardless of state. Always name the first param `$query` on ANY `->query(...)` callback except the three closures passed into `TernaryFilter::queries()`.

> **Same by-name rule applies to every `evaluate()`-backed closure, not just `modifyQueryUsing`** — `Group::getTitleFromRecordUsing`/`getKeyFromRecordUsing`/`getDescriptionFromRecordUsing`, column `getStateUsing`, etc. all inject their record under the key `'record'`. A closure param named anything but `$record` (and untyped, so no `Model` typed-injection fallback either) silently resolves to `null` via `allowsNull()` instead of erroring — the call succeeds but crashes on first property access (`FeedTablePresenter::categoryGroup()` shipped with `fn($r) => ...->category` and crashed the Feed table's category grouping in production every time, since `$r` never received the row; `OnboardingTablePresenter::audienceGroup()` had the identical shape). Always name the param `$record`, or type-hint it `Model $record` (or the concrete model class) for the typed-injection path.
>
> **`Group::groupQueryUsing`/`orderQueryUsing`/`scopeQueryByKeyUsing` need the same `$query` name — and the failure mode here is silent, not a crash.** Unlike `modifyQueryUsing`, `CanGroupRecords::applyGroupingToTableQuery()` and `HasBulkActions`'s "select all in group" both call `$group->orderQuery($query, ...)` / `$tableGrouping->scopeQueryByKey($query, $group)` **without reassigning the return value** — they rely on the closure mutating the SAME `$query` object in place. If the closure's first param is misnamed (`$q`) and untyped, `evaluate()` still resolves it to a *separate*, model-less `Eloquent\Builder` via container auto-resolution (it does not fall through to `null` here, because the param is typed `Builder` and typed-injection container resolution succeeds) — the closure mutates that throwaway object instead, the real `$query` is never touched, and the page renders fine with no error. The user-visible bug is silent: the group's custom ordering never applies, and "select all in this group" silently selects across every group instead of just the clicked one. Found 2026-09-29 in `AuthorityResource\Schemas\Grouping\JsonEnumGroup` and `PermissionResource\Schemas\Grouping\ModuleGroup` (both used `fn(Builder $q)`); fixed by renaming to `$query`. `groupQueryUsing` itself is currently dead code in this app (only reachable via a table-summary row, and no table here calls `->summarize()`) but keep it named `$query` regardless for when that changes. `(2026-09-29: the former centralized `tests/Feature/Filament/FilamentClosureConventionTest.php` full-tree scan was deleted; the naming check now lives as `test_group_and_query_closures_use_correct_param_names` inside each resource's own `<Module>ResourceTest.php`, scanning only that resource's `Schemas/*TablePresenter.php`/`Schemas/Grouping/*.php`.)`
>
> **`->sortable()` on a column backed by a PHP-only accessor (no matching real DB column) sorts nothing.** A plain `->sortable()` tells Filament to `ORDER BY` the column's own name — if that "column" is actually a model accessor like `Reservation::getLabeledNameAttribute()` (exposed via `TextColumn::make('resource.labeled_name')`), there is no `labeled_name` column in the DB, so the sort is a silent no-op (or errors depending on the relation shape), never a crash. Found 2026-09-29 in `ReservationTablePresenter::resource()`. Fix: pass `->sortable(query: fn (Builder $query, string $direction) => $query->orderBy(<a correlated subquery or real column expression>, $direction))` — see that method for the correlated-subquery pattern (`Resource::select('name')->whereColumn('resources.id', 'reservations.resource_id')`) when the sortable value lives on a related table with no direct join already applied. A relation-dotted column that maps to one real related column (`user.name`, `department.description`) does NOT need this — Filament v5's `RelationshipOrderer` already auto-joins those correctly; this only bites computed/composed accessor values.

Table configuration options to always consider:

- `->groups([...])` — row grouping via `Group::make()` or dedicated grouping class
- `->filters([...])` — comprehensive filters (not just a few — every filter with real UX value)

> **Group objects go in `->groups([...])`, never `->filters([...])`.** A `Group::make()` is not a
> filter — Filament treats every item in `->filters([...])` as a `Filter` and calls `getName()`
> on it; `Group` has no `getName()`, so dropping a group there fatals the table page with
> `BadMethodCallException: Method Filament\Tables\Grouping\Group::getName does not exist` (HTTP 500).

**Dynamic, per-key grouping for JSON-object columns** — when a column holds a variable set of
keys (`extra`, `tags` — both stored as JSON *objects*, e.g. `tags = {"type":"test1","روش":"test1"}`),
don't write one static `Group` per column. Instead a Service extracts the union of distinct keys
across all rows and emits **one `Group` per merged key** — the group list auto-grows with the data,
0 or N keys, no code change. Reference implementation: `app/Services/Dms/DmsKeyGrouper.php` (DMS).
**Same-key merging**: keys equal after `trim()` + `mb_strtolower()` (e.g. `Category`, `Category `,
`category`) collapse into ONE group; the label is the most frequent original variant. Genuine
typos (`Catergory`) stay separate — only whitespace/case variants merge, never edit-distance. Pattern:

- `map()` (cached, the core) — **raw SQL**, single query, MySQL 5.7+/8.x compatible. Unnests each
  row's keys positionally via a numbers derived table (`0..N`, the 5.7 substitute for 8.x
  `JSON_TABLE`): `JSON_UNQUOTE(JSON_EXTRACT(JSON_KEYS(col), CONCAT('$[', n, ']')))`, `UNION ALL`
  across `extra` and `tags`, grouped with `GROUP BY CAST(k AS BINARY)` and `COUNT(*)` per variant.
  **The BINARY cast is essential** — MySQL's default collation uses PAD SPACE, so a plain group key
  collapses `Category` and `Category ` (trailing space) into one row before PHP ever sees them, and
  then the trailing-space record's value could be lost. BINARY keeps every byte-distinct variant
  separate at extraction time; the trim+case-fold merge happens in PHP afterward. Returns
  `list<{norm, label, variants}>` sorted by label. TTL-cached (`Cache::remember`, no model flush
  hook — same convention as `DMS::getDocumentCounts()`; `php artisan cache:clear` for instant
  refresh). `MAX_KEYS_PER_OBJECT` bounds the numbers table; bump it if an object can hold more keys.
- `valueFor($record, $variants)` — tries every original variant byte-exactly (`array_key_exists`)
  across `extra` then `tags` (both objects); first hit wins; `null`/missing → `—`. Byte-exact so a
  variant like `Category ` resolves only on the record that actually carries it.
- `groups()` — `array_map` over `map()` → `Group::make(self::idFor($norm))->label($label)` with
  `getKeyFromRecordUsing` + `getTitleFromRecordUsing` both returning `valueFor($record, $variants)`,
  plus `->orderQueryUsing(fn($q) => $q)` **and** `->scopeQueryByKeyUsing(fn($q,$k) => …)`. **Both
  are essential** — the group id is an opaque hash, not a real column. `orderQueryUsing` stops
  Filament appending `ORDER BY <hash-id>` (throws `Unknown column 'dyn_…'` when the group is
  selected). `scopeQueryByKeyUsing` is the second crash site: "select all in group" (grouped bulk
  actions, `HasBulkActions`) calls `scopeQueryByKey($query, $value)` → `WHERE <hash-id> = <value>`
  → same `Unknown column`. Rebuild the scope as a raw `COALESCE(JSON_UNQUOTE(JSON_EXTRACT(col,
  '$."k"')) …) = ?` over the variants (mirrors `valueFor`); for the `—` bucket use `IS NULL`
  (matches valueFor's "no variant / null" case). With both, the query keeps its default sort and
  buckets are computed PHP-side via `getKeyFromRecordUsing`; "select all in group" scopes in SQL.
- `idFor($norm)` = `'dyn_' . substr(sha1($norm), 0, 16)` — a **stable, unique, ASCII-safe** id per
  *merged* key (hash the normalized form, not the label, so case variants share one id). The id is
  an internal identifier; the **label** shown to the user is the original key.
  - `valueExpression($variants)` / `jsonPath($key)` build the COALESCE + escaped JSON path used by
  `scopeQueryByKeyUsing`. Escape `"` and `\` (JSON path) **and** `'` (the wrapping single-quoted SQL
  string — the path is interpolated into `whereRaw`, and the key is user-controlled via the KeyValue
  field, so an unescaped `'` would close the literal and allow SQL injection/crash):
  `addcslashes($key, '"\'\\')`.
- Register with a spread: `->groups([..., ...DmsKeyGrouper::groups()])`.
- **Known Filament limitation**: with `getKeyFromRecordUsing`, Filament groups the **paginated
  page** (it loads the page, then buckets those rows) — it does not SQL `GROUP BY` the full result
  set (`groupQuery`/`groupBy` is only used for table summaries). So a selected group reflects only
  the current page's records. Accept this, or load all rows when grouped, if full grouping is needed.

**Grouping by a JSON array column (multi-value, not per-key like `extra`/`tags`)** — e.g. `owners`
on DMS, a JSON array of department codes (`["MA","IT"]` or the `"ALL"` sentinel). Same
`scopeQueryByKeyUsing` requirement as above applies whenever `getKeyFromRecordUsing` returns
anything other than a raw column value — here it's `implode(',', $record->owners ?? [])`, so the
scope must reconstruct that exact string server-side via `GROUP_CONCAT(JSON_UNQUOTE(JSON_EXTRACT(
owners, CONCAT('$[', n, ']'))) ORDER BY n SEPARATOR ',')` over a numbers-table unnest (same 5.7/8.x
technique as `DmsKeyGrouper`), bound via `?` — never trust the `implode` to be reproducible any
other way. Missing this scope doesn't crash (the column is real, unlike a hash id) — it silently
selects **zero rows** on "select all in group", which is easy to miss in manual QA. Reference:
`DmsTablePresenter::ownersGroup()` / `ownersKeyExpression()`.

**MariaDB fails to match a JSON object key when the stored document has it `\uXXXX`-escaped but the
query's JSON path references it via literal UTF-8 bytes** — confirmed live on production (MariaDB
10.6.20, Laravel's generic `mysql` driver). PHP's default `json_encode()` (what Eloquent's `array`
cast uses to save `dms.tags`/`dms.extra`, and what a Filament `KeyValue` field submission goes
through) escapes non-ASCII characters to `\uXXXX` — so a Persian key like `نوع سند` is stored as
literal ASCII bytes (`نوع سند`), not literal UTF-8. Any raw PHP string
built from that same logical key (e.g. from a rendered button's click value, or a variant computed
in PHP) contains the literal UTF-8 bytes instead. Both represent the identical JSON value and
`json_decode` treats them as equal — but MariaDB's `JSON_CONTAINS`/`JSON_EXTRACT`+`JSON_UNQUOTE`
path-matching does **not**: querying `JSON_EXTRACT(tags, '$."نوع سند"')` (literal-bytes path)
against a document whose key was stored escaped returns nothing, even when the key/value pulled
directly from that exact row is used verbatim in the query — a real MariaDB JSON-path defect, not a
collation/locale/`strtolower()` issue (all ruled out via direct empirical testing; `mb_strtolower`
and `strtolower` produced byte-identical output for Persian text, and MySQL's *native* `json()`
column type on local dev auto-canonicalizes storage to literal UTF-8, silently sidestepping the bug
entirely — so this class of bug is invisible in local testing and only surfaces against MariaDB).
**This affects any JSON-path SQL expression built from a dynamic, non-ASCII, admin-entered key** —
confirmed broken in `App\Livewire\Dashboard\Dms\Main::getBaseQuery()`'s `activeFilter` tag matching
(fixed — see `app/Livewire/livewirePattern.md` for the applied fix), but **`DmsKeyGrouper` and
`UserKeyGrouper`'s `scopeQueryByKeyUsing`/`valueExpression`/`jsonPath` mechanism above builds the
identical `JSON_UNQUOTE(JSON_EXTRACT(col, '$."k"'))` shape and has not yet been audited or fixed for
this — treat "select all in group" on a Persian-keyed dynamic group as suspect on MariaDB until
verified.** The fix applied to the Livewire board: match dynamic keys in PHP after fetching (decode
via the model's own array cast, compare with plain PHP equality/`in_array`) instead of pushing the
key into a SQL JSON path — sidesteps the MariaDB defect entirely regardless of storage encoding,
since PHP's `json_decode` already normalizes both forms. The same fix direction would apply to
`DmsKeyGrouper`/`UserKeyGrouper` if their grouped-bulk-action `scopeQueryByKeyUsing` is ever
confirmed broken the same way (currently unverified, not yet reproduced against MariaDB for these
two).

**Sibling defect, same root cause, different mechanism:** `getBaseQuery()`'s free-text search (not the `activeFilter` tag matching above) independently hit a second bug from the identical `json_encode()`-ASCII-escapes-non-ASCII root cause — but via MySQL `LIKE`'s own backslash-escape handling stripping the `\uXXXX` sequences from a search pattern, not via `JSON_EXTRACT` path encoding. Fixed by switching every free-text clause to `INSTR()` (no escape-character semantics at all) instead of `LIKE`. Full writeup: `app/Livewire/livewirePattern.md` § "`getBaseQuery()` free-text search — `INSTR()`, not `LIKE`, for every free-text OR-clause".

**Filtering a JSON array column that carries an "all/wildcard" sentinel** — if the column's
semantics include a sentinel value meaning "matches everyone" (e.g. `owners` containing `"ALL"`),
every `SelectFilter`/`Filter` that does `orWhereJsonContains(column, $specificValue)` must also
`orWhereJsonContains(column, 'ALL')` inside the same `where()` group, or wildcard-owned rows
silently disappear the moment any specific value is selected — a "the filter doesn't work" bug
report with no error, just wrong (under-inclusive) results. Reference: `DmsTablePresenter::ownersFilter()`.

**Dynamic per-key classifier on a single JSON-object column (groups **and** filters)** — when a model
has one JSON-object column holding admin-defined key/value tags with no fixed schema (e.g.
`users.extra` routed by its accessor into the `$.admin` sub-object), reuse the `DmsKeyGrouper` shape
but scope to that one column at its JSON path. Reference: `app/Services/User/UserKeyGrouper.php`.
- The `User::extra` accessor has a two-bucket setter: `preferences` (merged) and `admin` (the
  catch-all — every top-level key that isn't `preferences`/`admin` is routed into `$.admin`). So
  classifier keys live at `$.admin.<key>`, and the grouper's `map()` uses the 2-arg
  `JSON_KEYS(extra, '$.admin')` (MySQL 5.7.9+/MariaDB 10.6+, returns NULL on a missing/non-object
  path — no error). This is the only divergence from `DmsKeyGrouper`, which reads top-level keys of
  two columns via the 1-arg `JSON_KEYS(col)`.
- Emits **both** `Group[]` (via `groups()`, same `scopeQueryByKeyUsing`/`orderQueryUsing(fn($q)=>$q)`
  pattern as DMS) **and** `SelectFilter[]` (via `filters()`). Each filter's `->options(fn() => ...)`
  is a lazy `SELECT DISTINCT (COALESCE(...))` over the variants — one small query per dropdown open,
  not on page render. Register with spreads: `->groups([..., ...UserKeyGrouper::groups()])` and
  `->filters([..., ...UserKeyGrouper::filters()])`. Grouper ids are `dyn_<sha1:16>` — no collision
  with hand-written filter/group names.
- Cache invalidation: the grouper cache (`user_dynamic_group_keys`, 900s) is busted on every
  `User::saved` (unconditional, because classifier edits change `extra` which `wasChanged(['name',
  'role','status'])` would miss) **and** on `User::deleted` (so a deleted user's values stop
  appearing as filter options). `touchLastSeen()` uses `saveQuietly()`, which skips `saved`, so the
  frequent heartbeat does NOT bust the cache. See `User::booted()`.
- `jsonPath` escapes the same `"`/`'`/`\` set as DMS (`addcslashes($key, '"\'\\')`) — the key is
  admin-controlled via the KeyValue field, so this is the SQL-injection surface and must stay escaped.
- Reusing the same classifier outside Filament (a plain Livewire board, not a table filter): don't
  duplicate the `whereRaw` condition — `UserKeyGrouper::applyFilter(Builder $query, array $variants,
  string $value): Builder` is the public, parameterized query builder `filters()` itself calls
  internally; call it directly. Reference: `Status::applyClassifier()` in
  `app/Livewire/Dashboard/Tab/Status.php`, which encodes the active selection as a single
  `"{norm}|{value}"` string property (same shape as the pre-existing `Dms` Livewire board's
  `activeFilter`), resolves `$norm` back to its `variants` via `UserKeyGrouper::map()`, and applies it
  identically in both `stats()` and `users()` (AND-combined with the existing presence/search filters,
  never replacing them).
- **Admin-only tags**: since any admin-typed key auto-surfaces as a filter, some tags may not be meant
  for every authenticated user to see (the Status board sits behind plain `auth` middleware, wider than
  the admin panel). Convention: a key whose normalized form starts with `UserKeyGrouper::HIDDEN_PREFIX`
  (`_`, e.g. `_Salary`) is excluded from any user-facing surface via `UserKeyGrouper::isHidden($norm)`
  — checked both when building the visible group list (so it never renders as a button) **and** inside
  the query-applying method (so a hand-crafted/tampered filter value targeting a hidden key is a no-op,
  not a narrowing leak). The admin's own Filament `SelectFilter`/`Group` (`filters()`/`groups()`) are
  unaffected by this — hidden tags stay fully usable there. Deliberately opt-out (visible by default,
  hide via prefix), not opt-in, to match the feature's no-predefined-enum design; a hardcoded
  sensitive-keyword blocklist was rejected as fragile (typos, language variants) and against that same
  design intent.
- Free-text values interpolated into inline Alpine expressions (`@click`, `:class`, etc.) must go
  through `{{ \Illuminate\Support\Js::from($value) }}`, never a bare `{{ $value }}` inside a JS string
  literal — Blade's `{{ }}` only HTML-attribute-escapes, so an admin-typed value containing a quote
  breaks out of the JS string once the browser HTML-decodes the attribute. Reference:
  `resources/views/livewire/dashboard/tab/status/filters.blade.php` and the pre-existing precedent in
  the sibling `grid.blade.php`.

**Visibility scope for colleague pickers/lists (`scopeVisibleOnBoard`)** — to hide `UserType::Guest`
from every surface that lists/selects "colleagues" (originally just the "وضعیت همکاران" Status
board; as of 2026-08 also the Contact sidebar, Channel member picker, TaskBoard assignee picker,
Calendar event-share picker, admin Task assignee, admin DMS owners — see `livewirePattern.md`/
`contactPattern.md`), add a named combo scope on the model rather than reusing `scopeActive` (which
other call sites — login, notification-recipient pools, per-user badges — still depend on staying
Guest-inclusive). Reference: `User::scopeVisibleOnBoard()` = `active()->whereNot('type',
UserType::Guest->value)`. `UserType::Guest` was a defined-but-unused enum case — repurposing it as
the hide signal needs no migration, no new column, no new enum case. Admin side surfaces these users
via a list tab (`ListUsers::getTabs()` → `'hidden'` tab filtering `type = guest`) plus the
pre-existing `typeFilter`. Note: `whereNot` excludes NULL-typed rows in SQL; safe here only because
the schema defaults `type` to `'employee'`. **Deliberately still Guest-inclusive**: login/auth,
notification "nudge" recipient pools (`app/Services/Menu/Notifications/*.php`, incl. `DmsNudge` via
`DMS::pendingRecipients()`), and any per-user badge/count keyed by the acting user's own id (e.g.
`DMS::hasPendingFor($userId)`) — those answer "should this specific user be told/see their own
state", not "who should appear in a colleague list", so they intentionally keep `scopeActive`.

**Same exclusion applies to org-wide headcount stats, not just the status board.** `ModuleAnalyticsWidget::usersData()`/`departmentsData()` originally counted every row in `users` with no `type` filter, so `UserType::Guest`/`UserType::VIP` inflated the admin dashboard's "users" and per-department headcount stats. Fixed with `->whereNotIn('type', [UserType::Guest->value, UserType::VIP->value])` — on the raw `DB::table('users')` query for `usersData()`, and inside a `withCount(['users' => fn($query) => ...])` closure for `departmentsData()` (`Department::users()` is `HasManyThrough` via `profiles`; neither `departments` nor `profiles` has a `type` column, so the closure's `type` reference is structurally unambiguous — always resolves to `users.type`). `VIP` is included here (unlike `scopeVisibleOnBoard`, which only excludes `Guest`) because these are org-wide *statistics*, not the status board's narrower "hide non-employees from the colleague list" concern — match the exclusion set to what the specific surface is actually counting, don't reflexively copy `scopeVisibleOnBoard`'s exact set.
- `->filtersFormColumns(2)` — use 2-column filter layout when there are multiple filters
- `->recordActions([...], RecordActionsPosition::AfterCells)` — always position after cells
- `->groupedBulkActions([...])` — use `self::bulkActions(ExporterClass::class)` from `FilamentActions` trait
- `->emptyStateIcon('heroicon-o-bookmark')` — always set
- `->defaultSort(...)` — always set a sensible default
- `->striped()` — use on dense tables for readability
- all validationMessages are from GLOBAL STRINGS within lan.fa folders

```php
class UserTablePresenter
{
    public static function id(): TextColumn
    {
        return TextColumn::make('id')
            ->sortable()
            ->toggleable(isToggledHiddenByDefault: false);
    }

    public static function name(): TextColumn
    {
        return TextColumn::make('name')
            ->label(__('resources/user/strings.table.name'))
            ->sortable()
            ->searchable()
            ->toggleable(isToggledHiddenByDefault: false);
    }

    public static function email(): TextColumn
    {
        return TextColumn::make('email')
            ->label(__('resources/user/strings.table.email'))
            ->sortable()
            ->searchable()
            ->toggleable(isToggledHiddenByDefault: true);
    }

    public static function statusFilter(): SelectFilter
    {
        return SelectFilter::make('status')
            ->label(__('resources/user/strings.table.status'));
    }

    public static function statusGroup(): Group
    {
        return Group::make('status')
            ->label(__('resources/user/strings.table.status'))
            ->collapsible();
    }
}
```

##### `ListRecords` tabs (`getTabs()`) — default-view gotcha

When a `List*` page defines `getTabs()`, Filament's un-overridden `getDefaultActiveTab()` returns `array_key_first()` of the tabs array — whichever tab is listed first silently becomes the default, hard-scoping the page's default view to that tab's `modifyQueryUsing`. If the desired default is "show everything" (no hard scope), **don't** override `getDefaultActiveTab()` to return `null` — a blank `activeTab` never string-matches a tab key, so no tab pill highlights on load even though a separate `->default(...)`'d dropdown filter may still be silently narrowing the visible rows underneath. Instead follow `ListUsers.php`'s established idiom: add an `'all'` tab as the **first** key, with no `modifyQueryUsing` — `array_key_first()` naturally selects it, it imposes zero query constraint, and its pill correctly highlights (`'all' === 'all'`). Reference: `ListSkillRequests::getTabs()` — one tab per `SkillRequestStatus` case, icon/color/badge sourced straight from the enum's own `->heroicon()`/`->color()` methods via `collect(Enum::cases())->mapWithKeys(...)`, with `'all'` prepended via array union (`['all' => Tab::make(...)] + collect(...)->mapWithKeys(...)->all()`) so the status tabs stay enum-generated rather than hand-written per case. Same partition idea reused non-enum-driven in `ListSkills::getTabs()` (`catalog`/`inactive`/`ghosts`, mutually exclusive on `is_active`/`is_ghost` — no `'all'` tab needed there since the three together are already exhaustive).

#### 2.3 Infolist schema

One method per display entry. Each method returns a single read-only entry.

```php
class UserInfolistPresenter
{
    public static function createdAt(): TextEntry
    {
        return TextEntry::make('created_at')
            ->label(__('resources/user/strings.infolist.created_at'))
            ->formatStateUsing(fn($state, $record) => $record->createdLabel())
            ->color('gray')
            ->placeholder('-');
    }
}
```
Note my persian date helper ideal for table and infolist.
Make maximum practical use of all infolist options. Apply color, icons, and badges purposefully for clarity and hierarchy.

**Infolist layout — Section/Tabs discipline (added 2026-09-21, baseline reviewed from sibling project BMS-CM).** Every infolist wraps its entries in exactly **one unlabeled `Section::make()`** (no heading argument) per screen or per tab — never stack multiple headed sub-sections back to back; that reads as a wall of separately-boxed cards with repeated padding, not one polished view. `Tabs` exist only to separate genuinely distinct data domains (e.g. core profile fields vs. free-form admin metadata) — never as a substitute for what should be one flat Section. Each tab body is still just one bare Section with a `->columns(2|3)` grid, matched to field density. `ProjectResource::infolist()` is the reference (one Section, `columns(3)`, no tabs needed); `UserResource::infolist()` was the anti-pattern this fixed — 5 stacked headed Sections (`section_identity`/`section_access`/`section_booking`/`section_extra`/`section_meta`) across 2 tabs, collapsed down to one bare Section per tab. The same anti-pattern still exists, not yet fixed, in `DepartmentResource\RelationManagers\UsersRelationManager` and `ProfileResource\RelationManagers\UserRelationManager` (both embed the same over-segmented User infolist shape).

Field-level checklist, applied to every infolist entry for a uniform, polished look:
- Icon on every entry (`heroicon-o-*`), except a record's primary title field styled as a bold badge. **`KeyValueEntry` has NO `->icon()`** (unlike `TextEntry`/`IconEntry`) — calling it throws `BadMethodCallException` at render (`DmsInfolistPresenter::extra()` hit this during the 2026-09-21 rollout). Skip the icon on `KeyValueEntry` fields entirely.
- `placeholder('-')` (or `'—'`) wherever the value can be empty.
- `copyable()` on identifiers (id, name, email, slug, code).
- `badge()->color(...)` for every enum/status field, color sourced from the enum itself where one exists.
- Timestamp/date fields whose formatted value is `/`-separated Jalali digits (`toJalali()`) get `->extraAttributes(['dir' => 'ltr', 'style' => 'unicode-bidi: isolate;'])->alignRight()->iconPosition(IconPosition::After)` so the icon and date separators sit correctly against the RTL flow instead of reordering — reference: `ProjectInfolistPresenter::createdAt()`, `UserInfolistPresenter::createdAt()`, `DmsInfolistPresenter::createdAt()`. Relative-time strings (`toJalaliRelative()`, already natural Persian prose) don't need this treatment. Never apply `dir: ltr` to prose/free-text — that's the separate pre-wrap rule below.
- Long free text / repeatables get `columnSpanFull()`; short scalar fields stay in the grid.
- Between logical field clusters inside the same flat Section, insert a hairline separator with `static::divider()` (the `App\Traits\Filament\FilamentFormDivider` trait — its name predates infolist usage, but it's a generic gradient-fade `TextEntry` divider that works identically in either context; add `use FilamentFormDivider;` to the Infolist presenter). Never re-introduce a headed sub-`Section` to achieve the same grouping effect. Reference: `UserInfolistPresenter`/`ProjectInfolistPresenter`.

Every infolist's outer `Section::make()`, and every `Tabs::make()` if used, MUST carry `->extraAttributes(['class' => 'fi-infolist-panel'])` — the same marker class on both. The panel's actual background/shadow color itself is CSS-owned (`resources/css/adminStylesPattern.md` §4.4, targeting `.fi-infolist-panel .fi-section` and `.fi-sc-tabs.fi-infolist-panel.fi-contained`), and that marker class is what scopes the CSS to infolists — mandatory on every resource, not optional. Do NOT reach for `Tabs::make()->contained(false)` to strip its default card — it also reroutes the tab-BUTTON row through an unrelated vendor CSS branch that re-centers it (`mx-auto`), breaking RTL tab alignment as an unrelated side effect (see `adminStylesPattern.md` §4.4 for the incident). Never hand-roll a different `->extraAttributes(['style' => 'background: ...'])` per resource — the shared class is the single source so every infolist stays visually identical.

**Explicitly wrong — flag on sight (added 2026-09-21):** any "card"-like nested container inside an infolist body — a `Section`/`Fieldset`/styled `Grid` with its own border, background, or shadow wrapping a sub-group of fields — is the same anti-pattern as a headed sub-Section, just re-skinned. This is especially bad when two or more such cards sit **side by side with their own titles**, which reads as a mini-dashboard bolted onto a record view rather than one coherent detail page. The divider is the only sanctioned separator between clusters; nothing else gets its own box.

**RichEditor-stored fields in infolist/table MUST use `->html()` (or `->prose()`, which implies html).** A `RichEditor` column stores HTML (`<p><strong>…</strong></p>`); a bare `TextEntry::make('field')` renders that as literal `<p>`/`<strong>` text (raw tags visible). `->html()` renders it as real elements (bold, paragraphs) — the intended "view" behavior. This is safe-by-construction, NOT a stored-XSS vector: Filament's `CanFormatState::formatState()` runs `Str::sanitizeHtml()` on every `->html()` value before wrapping it in `HtmlString`, and `Str::sanitizeHtml` is Symfony's `HtmlSanitizer` with `->allowSafeElements()` (allowlist — `<script>`, `on*` event handlers, `<iframe>`, etc. are stripped). So `->html()` is sanitized output, not raw. Uniform across every RichEditor field: `Post` body/title, `FAQ` answer/question, `Feed` content, `Report` description, `Onboarding` value, `Suggestion` description (`->prose()`), `Authority` `details.duty` (read via `getStateUsing(fn $r => $r->details['duty'])` + `->html()`). The trap: a `getStateUsing()` that pulls RichEditor HTML from a JSON sub-field (`details.duty`) is easy to leave without `->html()` since the field name doesn't match a top-level column — always pair it with `->html()`.

**Two infolist `TextEntry` state traps (2026-11-16, production errors on the Project and Task view modals).** (1) An array-cast attribute (`member_ids`) is split by Filament into one entry per item, so `formatStateUsing` receives a single scalar, not the array — wrap it with `(array) $state` before `whereIn`. (2) An enum-cast attribute (`Task::priority` → `TaskPriority`) already arrives as the enum instance; `getStateUsing(fn($r) => $r->priority)` is enough, and `Enum::tryFrom($record->attr)` throws a `TypeError`. Guarded by `test_view_modal_renders_*` in `ProjectResourceTest` and `TaskResourceTest`.

#### 2.4 Grouping classes (dedicated, in `Schemas/Grouping/`)

When a group requires a non-trivial query (computed counts, raw SQL, bucket logic), extract it to a dedicated class under `Schemas/Grouping/`.

The table presenter method simply calls `GroupingClass::make()`.

```php
// Schemas/Grouping/UserCountGroup.php
class UserCountGroup
{
    private const SUBQUERY = <<<'SQL'
(
    SELECT COUNT(*)
    FROM `users`
    INNER JOIN `profiles`
        ON `profiles`.`user_id` = `users`.`id`
    WHERE `profiles`.`department_id` = `departments`.`code`
)
SQL;

    private const BUCKETS = [
        '0'     => ['min' => 0,  'max' => 0,    'label' => 'بدون کاربر'],
        '1-3'   => ['min' => 1,  'max' => 3,    'label' => '۱ تا ۳ کاربر'],
        '4-6'   => ['min' => 4,  'max' => 6,    'label' => '۴ تا ۶ کاربر'],
        '7-10'  => ['min' => 7,  'max' => 10,   'label' => '۷ تا ۱۰ کاربر'],
        '11-20' => ['min' => 11, 'max' => 20,   'label' => '۱۱ تا ۲۰ کاربر'],
        '20+'   => ['min' => 21, 'max' => null, 'label' => 'بیشتر از ۲۰ کاربر'],
    ];

    public static function make(): Group
    {
        $expr = self::expression();

        return Group::make('users_count')
            ->label(__('resources/department/strings.fields.users_count'))
            ->groupQueryUsing(fn(Builder $query) => $query
                ->addSelect('departments.*')
                ->selectRaw("{$expr} as users_count"))
            ->scopeQueryByKeyUsing(function (Builder $query, string $key) use ($expr) {
                $bucket = self::BUCKETS[$key] ?? null;
                if ($bucket === null) return $query;
                return match (true) {
                    $bucket['max'] === null               => $query->whereRaw("{$expr} >= ?", [$bucket['min']]),
                    $bucket['min'] === $bucket['max']     => $query->whereRaw("{$expr} = ?",  [$bucket['min']]),
                    default                               => $query->whereRaw("{$expr} BETWEEN ? AND ?", [$bucket['min'], $bucket['max']]),
                };
            })
            ->orderQueryUsing(function (Builder $query, string $direction) use ($expr) {
                return $query->orderByRaw("{$expr} " . (strtolower($direction) === 'desc' ? 'desc' : 'asc'));
            })
            ->getKeyFromRecordUsing(fn($record) => self::bucket((int)($record->users_count ?? 0))['key'])
            ->getTitleFromRecordUsing(fn($record) => self::bucket((int)($record->users_count ?? 0))['label'])
            ->titlePrefixedWithLabel(false)
            ->collapsible();
    }

    private static function bucket(int $count): array
    {
        foreach (self::BUCKETS as $key => $bucket) {
            if ($count < $bucket['min']) continue;
            if ($bucket['max'] !== null && $count > $bucket['max']) continue;
            return ['key' => $key, 'label' => $bucket['label']];
        }
        return ['key' => '0', 'label' => self::BUCKETS['0']['label']];
    }

    private static function expression(): string
    {
        return 'COALESCE(' . self::SUBQUERY . ', 0)';
    }
}
```

The presenter then delegates:

```php
// In DepartmentTablePresenter
public static function usersCountGroup(): Group
{
    return UserCountGroup::make();
}
```

---

### 3) Shared Traits

Cross-cutting traits used across all resources and pages (§3.5 is registered once from a provider instead of being mixed into classes). They must not contain resource-specific logic.

#### 3.1 `FilamentActions`

Centralizes all reusable action definitions. Every resource uses this trait instead of defining actions inline.

```php
trait FilamentActions
{
    public static function viewAction(): ViewAction
    {
        return ViewAction::make()
            ->tooltip(__('resources/general/strings.table.action_view'))
            ->iconButton();
    }

    public static function editAction(): EditAction
    {
        return EditAction::make()
            ->tooltip(__('resources/general/strings.table.action_edit'))
            ->iconButton();
    }

    public static function deleteAction(): DeleteAction
    {
        return DeleteAction::make()
            ->tooltip(__('resources/general/strings.table.action_delete'))
            ->iconButton()
            ->requiresConfirmation()
            ->modalHeading(__('resources/general/strings.table.action_delete_confirm'))
            ->modalDescription(__('resources/general/strings.table.action_delete_body'));
    }

    public static function bulkActions(string $exporterClass): array
    {
        return [
            static::bulkDeleteAction(),
            static::bulkExportAction($exporterClass),
        ];
    }

    public static function bulkDeleteAction(): DeleteBulkAction
    {
        return DeleteBulkAction::make()
            ->label(__('resources/general/strings.table.bulk_delete'));
    }

    public static function bulkExportAction(string $exporterClass): ExportBulkAction
    {
        return ExportBulkAction::make()
            ->label(__('resources/general/strings.table.bulk_export'))
            ->exporter($exporterClass);
    }

    public static function assignAction(callable $handler): Action
    {
        return Action::make('assign')
            ->label(__('resources/general/strings.table.action_assign'))
            ->icon('heroicon-m-user-plus')
            ->color('success')
            ->iconButton()
            ->requiresConfirmation()
            ->modalHeading(__('resources/general/strings.table.action_assign_heading'))
            ->modalDescription(__('resources/general/strings.table.action_assign_description'))
            ->action(function (Model $record) use ($handler): void {
                $handler($record);
                Notification::make()
                    ->title(__('resources/general/strings.notifications.assigned'))
                    ->success()
                    ->send();
            });
    }

    public static function unassignAction(callable $handler): Action
    {
        return Action::make('unassign')
            ->label(__('resources/general/strings.table.action_unassign'))
            ->icon('heroicon-m-user-minus')
            ->color('danger')
            ->iconButton()
            ->requiresConfirmation()
            ->modalHeading(__('resources/general/strings.table.action_unassign_heading'))
            ->modalDescription(__('resources/general/strings.table.action_unassign_description'))
            ->action(function (Model $record) use ($handler): void {
                $handler($record);
                Notification::make()
                    ->title(__('resources/general/strings.notifications.unassigned'))
                    ->success()
                    ->send();
            });
    }

    public static function bulkUnassignAction(callable $handler): BulkAction
    {
        return BulkAction::make('bulk_unassign')
            ->label(__('resources/general/strings.table.action_bulk_unassign'))
            ->icon('heroicon-m-user-minus')
            ->color('danger')
            ->requiresConfirmation()
            ->action(function (Collection $records) use ($handler): void {
                $records->each($handler);
                Notification::make()
                    ->title(__('resources/general/strings.notifications.bulk_unassigned'))
                    ->success()
                    ->send();
            });
    }
}
```

Usage in table:

```php
->recordActions([
    self::viewAction(),
    self::editAction(),
    self::deleteAction(),
], RecordActionsPosition::AfterCells)
->groupedBulkActions(self::bulkActions(UserExporter::class))
```

> **`UserResource` is the deliberate exception (2026-10-02): user deletion is removed everywhere.** Hard-deleting a user 500s on FK history (18+ tables RESTRICT-reference users), so: the row action is `UserTablePresenter::toggleStatusAction()` (active⇄inactive toggle, state-honest icons, hidden for your own account, hidden for suspended users — suspension changes only via the edit form, gated by `UserResource::canEdit()`), the bulk action is `UserTablePresenter::bulkDeactivateAction()` (skips self, silent when nothing eligible, gated by `canEditAny()`), and `EditUser` overrides `getHeaderActions()` to drop the shared trait's header `DeleteAction` — a class method overrides the trait method, no trait special-case needed. Inactive status is enforced at login and on every request in both panels (see `app/Http/httpPattern.md`). Every other resource keeps the shared trait's real delete.

#### 3.2 `FilamentHeaderActions`

Centralizes page-level header actions with a `match` dispatch on page type. Used on all Page classes.

```php
trait FilamentHeaderActions
{
    protected function getHeaderActions(): array
    {
        return match (true) {
            $this instanceof ListRecords => $this->listHeaderActions(),
            $this instanceof EditRecord  => $this->editHeaderActions(),
            default => [],
        };
    }

    private function editHeaderActions(): array
    {
        $actions = [
            CreateAction::make()
                ->icon('heroicon-o-sparkles')
                ->label(__('resources/general/strings.table.action_create')),
            ViewAction::make()
                ->icon('heroicon-o-eye')
                ->label(__('resources/general/strings.table.action_view')),
            DeleteAction::make()
                ->icon('heroicon-o-trash')
                ->label(__('resources/general/strings.table.action_delete')),
        ];

        if (in_array(SoftDeletes::class, class_uses_recursive(static::getResource()::getModel()), true)) {
            $actions[] = RestoreAction::make()
                ->icon('heroicon-o-arrow-uturn-left')
                ->label(__('resources/general/strings.table.action_restore'));
        }

        return $actions;
    }

    private function listHeaderActions(): array
    {
        $actions = [
            CreateAction::make()
                ->icon('heroicon-o-sparkles')
                ->label(__('resources/general/strings.table.action_create')),
        ];

        $resource = static::getResource();
        if (method_exists($resource, 'guideTabs') && !empty($resource::guideTabs())) {
            array_unshift($actions, $resource::setupGuideAction());
        }

        return $actions;
    }
}
```

`listHeaderActions()` auto-prepends the module-guide button (see §3.4) when the resource exposes a non-empty `guideTabs()`. All `ListRecords` and `EditRecord` pages must use this trait rather than defining `getHeaderActions()` inline. Pages that suppress the Create button (e.g. `canCreate() = false`) override `listHeaderActions()` and return `[ResourceClass::setupGuideAction()]` explicitly.

**Edit-page shortcut buttons (2026-10-28):** `editHeaderActions()` also carries a `ViewAction` (opens the resource's infolist read-only in a modal — the same peek `ListNotifyLogs` already had) and, ONLY when the resource's model uses `SoftDeletes` (today: Channel, Project, Task), a `RestoreAction`. `RestoreAction` additionally self-hides on non-trashed records (v5 `visible` gate), so it can never render as a dead button; the trait's `class_uses_recursive` check keeps the action object off the other resources' pages entirely. `SkillRequestResource` (the one resource without an infolist) has no Edit page, so no empty View modal is reachable.

#### 3.3 `FilamentPageBehavior`

Centralizes notification titles and redirect behavior after create/save. Used on all `CreateRecord` and `EditRecord` pages.

```php
trait FilamentPageBehavior
{
    protected function getCreatedNotificationTitle(): ?string
    {
        return __('resources/general/strings.notifications.created');
    }

    protected function getSavedNotificationTitle(): ?string
    {
        return __('resources/general/strings.notifications.saved');
    }

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
```

All `CreateRecord` and `EditRecord` pages must use this trait.

#### 3.4 `FilamentAdminGuide`

Gives a resource a tabbed in-panel admin guide (foolproof usage/setup doc) with no inline Action code. The resource declares `protected static array $guide = [['label','icon','view'], …]` (one entry per tab); the trait exposes `guideTabs()`, `setupGuideAction()` (modalContent → shared `filament/components/admin-guide.blade.php`), and `guideEmptyStateActions()`. The wrapper renders an Alpine `x-data="{ tab: 0 }"` tab bar + a `max-h-[60vh]` scroll region that `@include`s each tab view — so each tab is a self-contained Blade fragment under `resources/views/filament/resources/<module>/guide/<tab>.blade.php` (NO modal chrome, NO tab bar inside partials). Styling matches `policy/legend.blade.php`: MD3 `--md-sys-color-*` tokens, `material-symbols-rounded`, `rounded-2xl` cards, `divide-y divide-[var(--md-sys-color-outline-variant)]`, RTL, `convertToPersian()` for digits. Lang keys live once in `resources/general/strings.php` under `guide.*` (label/heading/cancel).

```php
trait FilamentAdminGuide
{
    public static function guideTabs(): array
    {
        return property_exists(static::class, 'guide') ? static::$guide : [];
    }

    public static function setupGuideAction(): Action
    {
        return Action::make('moduleGuide')
            ->label(__('resources/general/strings.guide.label'))
            ->icon('heroicon-o-book-open')
            ->modalHeading(static::getPluralModelLabel() . ' — ' . __('resources/general/strings.guide.heading'))
            ->modalContent(fn() => view('filament.components.admin-guide', ['tabs' => static::guideTabs()]))
            ->modalSubmitAction(false)
            ->modalCancelActionLabel(__('resources/general/strings.guide.cancel'));
    }

    public static function guideEmptyStateActions(): array
    {
        return [static::setupGuideAction()];
    }
}
```

The trait does **not** declare `$guide` itself — a class cannot override a trait static property with a different default (PHP fatal: "the definition differs and is considered incompatible"). The `property_exists` guard lets a trait-using resource that forgot `$guide` degrade to "no guide" instead of fatalling. To wire: `use FilamentAdminGuide` on the resource + declare `$guide`; the header button auto-appears via §3.2. Empty-state opt-in: `->emptyStateActions(self::guideEmptyStateActions())` in `table()`.

**Icon convention — admin panel vs user panel (stress this).** The two panels use different icon systems and must not be mixed:

- **Admin (Filament) → Heroicons** (`heroicon-o-*` outline / `heroicon-m-*` mini / `heroicon-s-*` solid) for every Filament-native surface: actions, infolist entries, form fields, table columns, navigation, `Section` icons, widgets, resource `navigationIcon`, enum `getIcon()`. Filament's icon prop expects a Heroicons name.
- **User panel (Livewire/Dashboard) → Google Material Symbols** (`material-symbols-rounded`) — the MD3 design language used across dashboard blade + `dashboard.css`.

Never cross the streams: no Heroicons in user-panel blade; no Material Symbols names passed to Filament-native icon props.

**One documented exception — custom rich-content admin blade inside a Filament modal.** The `FilamentAdminGuide` tab partials use `material-symbols-rounded`. This renders because the admin Vite theme `resources/css/core/filament.css` does `@import "../../icons/generated/rounded.css";` (line 6 — the generated ~225 KB icon subset, see `resources/icons/iconsPattern.md`) and its base layer excludes the class from the sans override — `*:not(.material-symbols-rounded) { font-family: var(--font-sans) !important }` (line 73) — so the Google font loads inside Filament. Use Material Symbols here only where Heroicons lacks a suitable glyph (`event_repeat`, `hourglass_top`, `verified_user`, `center_focus_strong`, `tips_and_updates`, …); otherwise prefer Heroicons.

**Material Symbols names must be real ligatures** — an invalid name renders as broken literal text, not a missing glyph. **Source of truth = the woff2 ligature table**, NOT `node_modules/material-symbols/index.d.ts` (the d.ts lists only current canonical names and omits legacy aliases like `done`, `email`, `phone`, `tips_and_updates`, `expand_more`, `remove_circle` that the font still renders fine — trusting the d.ts produces false positives and "fixes" working icons). A sorted 4167-entry list extracted from the installed `material-symbols-rounded.woff2` (v0.40.2) is committed at `.claude/material-symbols-ligatures.txt`. **Every** ligature used in a guide partial, legend, or `$guide` tab icon must be verified with `grep -xF "name" .claude/material-symbols-ligatures.txt` before saving — this is mandatory for the guide/legend pipeline (see §3.4 pipeline policy). Regenerate the file with fontTools if the package is upgraded (iterate GSUB → unwrap type-7 `ExtSubTable` → type-4 `ligatures` → rebuild strings from cmap-reversed glyph ids). Confirmed-NOT-in-font (never use): `shield_check`, `checklist_partial`, `event_share`, `event_add`, `widget` (singular — only `widgets` exists). Substitutions: `shield_check`→`verified_user`, `checklist_partial`→`rule`, `event_share`→`share`, `event_add`→`event`/`group_add`, `widget`→`widgets`. (`share_reviews` IS valid — do not "fix" it.)

**Guide + legend are a MANDATORY pipeline step** (treated like doc-sync + test-coverage, never skipped): every admin Filament resource ships a `FilamentAdminGuide` (`$guide` array + partials under `resources/views/filament/resources/<x>/guide/*.blade.php`); every user-panel Livewire/Dashboard module ships a `legend.blade.php` (TaskBoard tabbed pattern — see livewirePattern.md "User-panel legend pattern"). Module on both sides → both surfaces (guide includes a «تجربهٔ کاربر» tab); one side only → that side only. Review must verify: real Material Symbols ligatures (quick pre-check: `grep -xF "name" .claude/material-symbols-ligatures.txt`; the font build in `iconsPattern.md` is authoritative), JIT-safe `match` for chip classes (never Blade interpolation inside `bg-[var(--md-sys-color-{{ }}-container)]` arbitrary-value brackets), no comments, `convertToPersian()` for digits, non-obvious nuggets only (no visual noise), and every claim traceable to actual code (no hallucination).

**Same mandatory-fan-out rule applies to dashboard stats.** Every admin Filament resource with meaningful aggregate data (counts, status breakdowns) also gets a tab in `ModuleAnalyticsWidget` (`app/Filament/Widgets/ModuleAnalyticsWidget.php`) — see "Widget sorting convention" above and the full checklist in `widgetsPattern.md`. Skip only for a pure pivot/junction resource already folded into its parent's tab.

#### 3.5 `FilamentViewActionDefaults`

Panel-wide defaults for the infolist VIEW modal (since 2026-10-28). NOT mixed into resources — `FilamentServiceProvider` does `use FilamentViewActionDefaults;` and registers the two wirings inside its `registerComponentHooks()` boot step (2026-10-29, folded in beside the other render hooks for uniformity; the trait itself now holds only the static helpers), wiring two things:

1. **`ViewAction::configureUsing(...)`** — every `ViewAction::make()` gains `extraModalFooterActions(...)`: the view modal footer gets labeled Create / Edit / Delete buttons. **Create mirrors the table's own create surface (2026-10-28):** main resource tables get a generic `CreateAction` (auto-gated by `canCreate()` through the auth trait — see the AuthorizesByPermission section); relation-manager tables get a clone of the RM's own header create action, carrying its custom `visible()` rules (the User RMs' department/blank-profile gates hold inside the modal); RMs with no header create (ChannelMembers attach-only, Occurrences read-only) get NO create; `ListNotifyLogs` and `ListSkillRequests` — the two List pages whose headers carry no create — are the explicit exceptions (the SkillRequests one is inert today: its table has no view row action, so no view modal ever opens there; the exception future-proofs it). Edit and Delete are **clones of that table's own row actions** (`$table->getRecordActions()` flattened through ActionGroups, matched by name `edit`/`delete`, then `getClone()->button()`), so every per-resource rule keeps applying inside the modal: `->visible/hidden(fn($record))` gates re-evaluate against the mounted record (ticket-linked task edit stays hidden, ghost skills stay uneditable), `->using(...)` file-cleanup processes are preserved, `->url(...)` row overrides (ReservationPolicy) still navigate to the edit page. A resource whose rows have no edit action (EnergyTest — the one resource without an Edit page) simply gets no Edit button — the whole "skip when the resource lacks an edit page" rule with zero per-resource config. A ViewAction mounted without a table (the Edit-page header ViewAction of §3.2) gets no shortcuts at all. The Delete clone chains `->cancelParentActions(true)` — after a successful footer/header delete the parent view modal closes instead of lingering on the deleted record (native vendor lever; the other clones pass `null` to keep default behavior — `false` is an invalid operand there that spins the unmount loop).
2. **`ActionsRenderHook::MODAL_CUSTOM_CONTENT_BEFORE` render hook** — renders the visible footer actions again as icon-only buttons in a `.fi-modal-header-quick-actions` strip overlaid on the modal header (BMS-CM's dual-surface look: labeled buttons in the footer, icons at the top). Footer and header share one evaluation — `getExtraModalFooterActions()` is cached per action instance. `quickActionIcons()` REVERSES the action order in the DOM so the RTL header row reads **close, add, edit, delete** left-to-right (delete rightmost); the reversal must live in code, never in a `direction: ltr` on the strip — see adminStylesPattern.md §4.5 for the logical-offset trap. `quickActionIcons(?Action $action)` ignores non-ViewAction modals via the `instanceof` guard (the hook fires for EditAction modals too); the strip div carries `wire:key="view-modal-quick-actions"` (morph-safety).

The row buttons stay the single source of truth — do NOT re-add shortcuts per-resource in `recordActions` or infolists; the default covers every surface. The modal's scrolled-down bug is fixed at the JS layer (`core/filament.js`, see `resources/js/scriptPattern.md`) — Livewire reuses the same `.fi-modal-window` element across opens (stable `wire:key`), so a closed modal's scroll position persisted into the next open; the listener resets it inside a `requestAnimationFrame` (the vendor event fires inside `$nextTick`, before the x-show display flush — an immediate reset lands on a still-hidden window and no-ops), scoped to infolist modals only. The Create shortcut is not gated in this trait — its visibility flows through the vendor authorization chain into `AuthorizesByPermission::getAuthorizationResponse()`, whose `'create'` arm honors each resource's own `canCreate()` (see the AuthorizesByPermission section); locked red by `FilamentViewActionDefaultsTest`'s hidden-on-no-create-resource pin.

---

### 4) Actions

Optionally use module actions only when a write operation is reusable or complex enough to deserve extraction.

An action should:

- contain a single public `execute` method
- receive needed form data or model instances
- avoid dispatching toasts, redirects, or tab changes unless treated explicitly as presentation logic

```php
class StoreUserAction
{
    public function execute(array $data): User
    {
        return User::create($data);
    }
}
```

---

### 5) Export class

Each resource that supports export has a dedicated exporter class.

```php
class UserExporter extends Exporter
{
    use ExportDefaults;

    public static function getColumns(): array
    {
        return [
            ExportColumn::make('id')->label('ID'),
            ExportColumn::make('name')->label('Name'),
        ];
    }
}
```

> Eager-load relationships accessed in per-row `ExportColumn` state closures via `modifyQuery(Builder $query): Builder` (e.g. `return $query->with(['user', 'department'])`). Do NOT override `getEloquentQuery` on an exporter — the `Exporter` base class has no such method (that hook belongs to the `Resource` class); calling `parent::getEloquentQuery()` from an exporter is a fatal `BadMethodCallException`.

---

### 6) Enums

Shared logic reused across form, table, and infolist that represents fixed domain states belongs in enums.

Use cases: statuses, sources, types, color mapping, icon mapping, tooltip mapping, computed labels.

```php
enum Status: string implements HasColor, HasLabel, HasIcon
{
    case Active   = 'active';
    case Inactive = 'inactive';

    public function getColor(): string  { ... }
    public function getIcon(): string   { ... }
    public function getLabel(): string  { ... }
}
```

Common enum responsibilities: color, icon, label, tooltip, computed state from record relationships.

---

### 7) Relation managers

Rules:

- One manager per relationship.
- **Reuse presenter classes** (`ProfileFormPresenter`, `ProfileInfolistPresenter`, `ProfileTablePresenter`) — never define new components inside a relation manager.
- **No filters** unless the relationship has many records where filtering provides real UX value.
- **No group actions** unless explicitly needed.
- **No edit/delete row actions** unless the workflow requires it.
- Eager-load all relationships in the table.
- If the relationship has only one record: disable search (`->searchable(false)`).
- Always set `->emptyStateIcon('heroicon-o-bookmark')`.
- `->headerActions([CreateAction::make()->icon('heroicon-o-sparkles')->label(...)])` — always use the sparkles icon for create.

```php
class ProfileRelationManager extends RelationManager
{
    use FilamentActions;

    protected static string $relationship = 'profile';
    protected static ?string $title = 'پروفایل';

    public function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make(__('resources/profile/strings.form.section_identity'))
                ->schema([
                    ProfileFormPresenter::personnelId(),
                    ProfileFormPresenter::gender(),
                    // ...
                ])
                ->columns(2),
            // more sections reusing ProfileFormPresenter...
        ]);
    }

    public function infolist(Schema $schema): Schema
    {
        return $schema->components([
            Section::make(__('resources/profile/strings.infolist.section_identity'))
                ->schema([
                    ProfileInfolistPresenter::personnelId(),
                    ProfileInfolistPresenter::gender(),
                    // ...
                ])
                ->columns(2),
            // more sections reusing ProfileInfolistPresenter...
        ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                ProfileTablePresenter::id(),
                ProfileTablePresenter::position(),
                ProfileTablePresenter::employmentStatus(),
                ProfileTablePresenter::department(),
                ProfileTablePresenter::gender(),
                ProfileTablePresenter::cellphone(),
                ProfileTablePresenter::startDate(),
            ])
            ->headerActions([
                CreateAction::make()
                    ->icon('heroicon-o-sparkles')
                    ->label(__('resources/profile/strings.navigation.singular')),
            ])
            ->searchable(false)
            ->emptyStateIcon('heroicon-o-bookmark')
            ->recordActions([
                self::viewAction(),
                self::editAction(),
                self::deleteAction(),
            ], RecordActionsPosition::AfterCells);
    }
}
```

#### Aggregated relation managers (one row per parent-side entity)

When a relation manager must show **one row per a grouping of the child records** (e.g. `PollsRelationManager` shows one row per *voter* with their concatenated choices, not one row per vote), the table query needs `GROUP BY` + aggregates (`GROUP_CONCAT`, `COUNT(*)`, `MIN(created_at)`). Two gotchas that break this under MySQL `ONLY_FULL_GROUP_BY`:

- Filament appends a stable-pagination tiebreaker `order by <table>.<pk> asc`. With `GROUP BY user_id` the raw `polls.id` is neither grouped nor aggregated → `SQLSTATE 1055`.
- A `HAVING`-based filter (`HAVING COUNT(*) = 1`) only works on the *aggregating* query; once you move aggregation into a subquery the outer query has no `GROUP BY`, so the filter must become `WHERE` on the derived column.

The robust shape is to aggregate inside a **subquery** via `fromSub`, so the outer query Filament sorts/filters/paginates only ever sees derived columns (no `ONLY_FULL_GROUP_BY` violation), and to filter with `whereRaw` on the derived aggregate alias:

```php
->query(
    Poll::query()
        ->fromSub(function ($query) use ($ownerId) {
            $query->from('polls')
                ->where('feed_id', $ownerId)
                ->selectRaw('user_id, MIN(id) as id, GROUP_CONCAT(option_index ORDER BY option_index SEPARATOR ",") as option_indexes, COUNT(*) as votes_count, MIN(created_at) as created_at')
                ->groupBy('user_id');
        }, 'polls')
        ->with('user')
)
->defaultSort('created_at', 'desc')   // orders by the derived created_at, valid
```

Conventions for this kind of manager:

- `MIN(id) as id` keeps Filament record keys unique per grouped row, so selection/view still work.
- Per-row value columns (e.g. concatenated choices) use `getStateUsing(fn (Poll $record) => $this->resolveChoices($record))` backed by a single helper that parses the `GROUP_CONCAT` CSV through the owner record's choice list — keep the parse in one protected method reused by both the table column and the infolist.
- `->sortable()` is dropped on every column (per-column sorting is meaningless over an aggregate set); order only via `defaultSort` on a derived column.
- Delete semantics change: the row no longer maps to one child record, so the default delete action (which deletes by model key) is wrong. Provide a custom `DeleteAction`/`BulkAction` that removes *all* of the grouped entity's rows (`where('feed_id', $ownerId)->where('user_id', $record->user_id)`) with confirmation.

---

## Page structure

Pages must always use both `FilamentHeaderActions` and `FilamentPageBehavior` traits:

```php
class CreateUser extends CreateRecord
{
    use FilamentHeaderActions;
    use FilamentPageBehavior;

    protected static string $resource = UserResource::class;
}

class EditUser extends EditRecord
{
    use FilamentEditHeading;
    use FilamentHeaderActions;
    use FilamentPageBehavior;

    protected static string $resource = UserResource::class;
}

class ListUsers extends ListRecords
{
    use FilamentHeaderActions;

    protected static string $resource = UserResource::class;
}
```

Available page types: `Manage`, `Create`, `Edit`, `List`, `View`.

**Base-page imports (since 2026-09-21):** resource pages import `CreateRecord`/`EditRecord`/`ListRecords`/`ViewRecord` from **`App\Filament\Pages\`** — never from `Filament\Resources\Pages\`. Those four base pages wrap every save (`handleRecordCreation`/`handleRecordUpdate`) and action (`callMountedAction`) with the exception traits in `app/Traits/Filament/`: a crash surfaces a precise Persian notification (title + body + `ERR-…` reference from `App\Services\ExceptionPresenter`) instead of a generic error — and the record save rolls back (`Halt->rollBackDatabaseTransaction()`). ValidationException/Halt/Cancel are always re-thrown, never presented.

**`save()`/`create()` are ALSO wrapped directly, not just `handleRecordUpdate`/`handleRecordCreation` (since 2026-10-05).** Vendor `EditRecord::save()`/`CreateRecord::create()` wrap their ENTIRE body — including `$this->form->getState()` (validation) — in one try/catch, and only `handleRecordUpdate`/`handleRecordCreation` sit inside OUR override's own try/catch. A crash during validation itself (not the DB write) — e.g. Filament's file-upload mimetype-check closure throwing `League\Flysystem\UnableToRetrieveMetadata` when a Livewire temp upload's file vanished mid-transfer — used to escape both layers uncaught, reaching `bootstrap/app.php`'s render closure, which deliberately returns `null` (defers to Filament) for any `admin*` Livewire request — so the admin saw nothing useful. Fix: `App\Filament\Pages\EditRecord::save()` / `CreateRecord::create()` now wrap `parent::save()`/`parent::create()` directly too, calling the trait's new `notifySaveException()` (same notification, no `Halt` thrown — vendor's own catch already rolled back and rethrew by the time control reaches here, so there's nothing left to roll back). **Gotcha that bit the first draft of this fix:** the wrapper's catch-all MUST exclude `ValidationException`/`Cancel` alongside `Halt` (`catch (ValidationException|Halt|Cancel $e) { throw $e; }`), exactly like `HandlesActionExceptions::callMountedAction()` already does — `getState()` throwing a plain "this field is required" `ValidationException` is NORMAL, and without the exclusion every ordinary field-validation failure across all 31 admin resources would get swallowed into a generic "system error" toast instead of Filament's native inline field errors.

**Relation managers (same rule):** every RelationManager class imports `RelationManager` from **`App\Filament\RelationManagers\`**, not `Filament\Resources\RelationManagers\`. This is NOT redundant with the page bases: vendor `RelationManager` is its own Livewire component carrying its own `InteractsWithActions` — its table/header/modal actions (including the create/edit modal writes) run on the RelationManager component, never on the hosting record page, so only the base-class trait covers them.

Example page registration:

```php
public static function getPages(): array
{
    return [
        'index'  => ListUsers::route('/'),
        'create' => CreateUser::route('/create'),
        'edit'   => EditUser::route('/{record}/edit'),
        'view'   => ViewUser::route('/{record}'),
    ];
}
```

---

## Layout pattern

- Resource defines sections and order (tabs, sections, columns).
- Schema classes define each field, column, and entry.
- Table schema defines columns, filters, and groups.
- Infolist schema defines read-only items.

The resource never defines field-level logic directly.

---

## Colors

Apply colors purposefully across tables, infolists, and forms. Avoid decorative use. Available palette:

```php
'danger'  => Color::Red,
'gray'    => Color::Zinc,
'info'    => Color::Blue,
'primary' => Color::Amber,
'success' => Color::Green,
'warning' => Color::Amber,

'slate'   => Color::Slate,
'zinc'    => Color::Zinc,
'neutral' => Color::Neutral,
'stone'   => Color::Stone,
'mauve'   => Color::Mauve,
'olive'   => Color::Olive,
'mist'    => Color::Mist,
'taupe'   => Color::Taupe,

'red'     => Color::Red,     'orange'  => Color::Orange,
'amber'   => Color::Amber,   'yellow'  => Color::Yellow,
'lime'    => Color::Lime,    'green'   => Color::Green,
'emerald' => Color::Emerald, 'teal'    => Color::Teal,
'cyan'    => Color::Cyan,    'sky'     => Color::Sky,
'blue'    => Color::Blue,    'indigo'  => Color::Indigo,
'violet'  => Color::Violet,  'purple'  => Color::Purple,
'fuchsia' => Color::Fuchsia, 'pink'    => Color::Pink,
'rose'    => Color::Rose,
```

---

## Naming conventions

### Schema methods
`name()`, `email()`, `status()`, `createdAt()`, `updatedAt()`

### Schema classes
`UserFormPresenter`, `UserTablePresenter`, `UserInfolistPresenter`

### Grouping classes
`UserCountGroup`, `StatusGroup` — stored in `Schemas/Grouping/`

### Enum methods
`getColor()`, `getIcon()`, `getLabel()`, `getTooltip()`, `getFromRecord()`, `getAllFromRecord()`

---

## Design rules

1. **Unified Schemas folder** — all form, table, infolist schema logic lives in `Schemas/`.
2. **Grouping classes in `Schemas/Grouping/`** — any non-trivial grouping with raw SQL, buckets, or computed expressions gets its own class.
3. **No Validators folder** — validation lives inside each form method.
4. **Filters belong to Table schema** — no separate Filters folder.
5. **Module-qualified naming** — `UserFormPresenter.php`, not `Form.php`.
6. **Resource is the orchestrator** — composes schema and page structure only; no field/column logic.
7. **One method = one component** — each field, column, and display entry is isolated.
8. **Pages use both traits** — `FilamentHeaderActions` and `FilamentPageBehavior` on all Create/Edit/List pages. Edit pages additionally `use FilamentEditHeading;` for the record-aware heading (see §6 below).
9. **FilamentActions trait is mandatory** — no inline action definitions in resources or relation managers.
10. **Pages are flexible** — Manage, Create, Edit, View, List depending on workflow.
11. **Actions are optional** — `Actions/` only for reusable/complex write operations.
12. **Shared logic belongs in Enums** — states, labels, icons, colors.
13. **RelationManagers reuse presenter classes** — never define new components inside a manager.
14. **RelationManagers are minimal** — no filters unless genuinely needed; no edit/delete unless workflow requires it.
14a. **`$relationship` must name the exact relation method** — when a model carries both a singular and a plural variant of the same relation, a manager bound to the singular one silently shows wrong/empty rows (a `hasOneThrough` with default keys joins the wrong columns). A manager listing many rows always binds the plural method. Incident: `UsersRelationManager` was bound to `Department::user()` (broken-key HasOneThrough) instead of `Department::users()` (HasManyThrough via Profile) — fixed 2026-09-13 and the dead singular relation deleted.
15. **Exports are isolated** — `Exports/` folder, dedicated class.
16. **Localization is mandatory** — all labels, messages, tooltips, placeholders, and validation text use translation keys.
17. **Table defaults are sparse** — only ID, name, status, and essential operational fields visible by default; everything else toggleable and hidden.
18. **Eager-load everywhere** — `getEloquentQuery`, table, form, and relation manager tables.
19. **`emptyStateIcon`** — always set to `heroicon-o-bookmark` on every table and relation manager.
20. **`defaultSort`** — always set a sensible default on every table.

---

## Example workflow — Adding a new field

1. Add method to form presenter class.
2. Add method to infolist presenter class if read-only display is needed.
3. Add method to table presenter class if it should appear in listing (hidden by default unless essential).
4. Reference from the resource layout.

```php
// UserFormPresenter
public static function code(): TextInput
{
    return TextInput::make('code')
        ->label(__('resources/user/strings.form.code'))
        ->required()
        ->maxLength(50);
}

// UserResource
Section::make()->schema([
    UserFormPresenter::code(),
]);
```

---

## Final rules

- The resource file is the main presenter for the module. Actual form, table, infolist, action, export, enum, and relationship logic lives in dedicated classes and is only composed in the resource.
- All eager-loaded relationships must be present wherever relevant to reduce system load.
- The design must be **100% technically optimized**, not just conventionally uniform.
- Table views stay intentionally sparse. The infolist is the primary place for complete record inspection.
- **The primary language of the entire app — including all Filament admin panel inputs, labels, messages, notifications, and validation messages — is Farsi (Persian). Direction is RTL.**

---

## Shared Traits — Additional (Undocumented above)

### 4) `FilamentFilters` trait

Located at `app/Traits/Filament/FilamentFilters.php`. Applied on every resource alongside `FilamentActions`.

```php
use FilamentActions, FilamentFilters, AuthorizesByPermission;
```

Provides `createdAtFilter()` plus the generalized `jalaliDateRangeFilter(string $name, string $column, string $label, string $fromLabel, string $untilLabel): Filter` builder every module-specific date-range filter now routes through — never hand-roll a second `Grid::make(2)->schema([DatePicker::make('from'), DatePicker::make('until')])` block for a different column.

```php
public static function createdAtFilter(): Filter
{
    return self::jalaliDateRangeFilter(
        'created_at', 'created_at',
        __('resources/general/strings.filters.date_range'),
        __('resources/general/strings.filters.date_from'),
        __('resources/general/strings.filters.date_until'),
    );
}

public static function jalaliDateRangeFilter(string $name, string $column, string $label, string $fromLabel, string $untilLabel): Filter
{
    $persian = Auth::user()?->getPreference('persian_dates', true) ?? true;

    return Filter::make($name)
        ->label($label)
        ->schema([
            Grid::make(2)->schema([
                DatePicker::make('from')
                    ->when($persian, fn (DatePicker $p) => $p->jalali(), fn (DatePicker $p) => $p->native(false))
                    ->label($fromLabel),
                DatePicker::make('until')
                    ->when($persian, fn (DatePicker $p) => $p->jalali(), fn (DatePicker $p) => $p->native(false))
                    ->label($untilLabel),
            ])
        ])
        ->query(fn (Builder $query, array $data) => $query
            ->when($data['from'] ?? null, fn ($q) => $q->whereDate($column, '>=', $data['from']))
            ->when($data['until'] ?? null, fn ($q) => $q->whereDate($column, '<=', $data['until'])))
        ->indicateUsing(function (array $data) use ($persian, $fromLabel, $untilLabel): array {
            $indicators = [];
            if ($from = $data['from'] ?? null) $indicators[] = $fromLabel . ': ' . ($persian ? jdateOnly($from) : $from);
            if ($until = $data['until'] ?? null) $indicators[] = $untilLabel . ': ' . ($persian ? jdateOnly($until) : $until);
            return $indicators;
        });
}
```

**Rules:**
- Always the last filter in the list.
- `->native(false)` alone does **not** give a Jalali calendar — Filament's stock `DateTimePicker::getLocale()` falls back to `config('app.locale')` and there is no Jalali conversion anywhere in Filament core. `->locale('fa')` only translates flatpickr-style day/month *labels*; the grid underneath stays Gregorian. Real Jalali rendering requires the `mokhosh/filament-jalali` package (composer dependency, `^6.0`) and its `.jalali()` macro on `DatePicker` — it internally calls `->native(false)` itself, registers a dedicated Alpine component (`public/js/mokhosh/filament-jalali/...`, published via `php artisan filament:assets`), and swaps in a real Jalali calendar widget.
- The Gregorian/Jalali choice is a per-admin preference (`persian_dates`, default **on** — see the User preferences section below), not hardcoded. `->when($persian, fn ($p) => $p->jalali(), fn ($p) => $p->native(false))` is the toggle point; the `else` branch keeps `->native(false)` so the picker UI stays consistent either way.
- Module-specific date-range filters on a different column all delegate to `jalaliDateRangeFilter()` rather than duplicating the shape: `EnergyTestTablePresenter::dateRangeFilter()` (`completed_at`), `EventTablePresenter::dateRangeFilter()` (`date`), `ReportTablePresenter::reportDateRangeFilter()` (`report_date`), `GalleryTablePresenter::eventDateRangeFilter()` (`event_date`) — each is now a one-line wrapper, and each presenter class adds `use FilamentFilters;` to reach the shared method. Adding a new date-range filter anywhere in the admin panel should always call `self::jalaliDateRangeFilter(...)`, never rebuild the DatePicker pair by hand — otherwise it silently falls outside the `persian_dates` toggle.
- Guard every `$data['from']`/`$data['until']` read with `?? null` in both `query` and `indicateUsing` — a single-sided range (only `from` or only `until`) throws `Undefined array key` without it.
- `indicateUsing` must return human-readable active-filter chips so users can see the active range at a glance, formatted through `jdateOnly()` (not the raw ISO string) when `persian_dates` is on.

---

### 5) `AuthorizesByPermission` trait

Located at `app/Traits/Filament/AuthorizesByPermission.php`. Applied on every resource. This is the access control system for the admin panel — two layers: `canX()` for page entry/navigation, and `getAuthorizationResponse()` for in-table row/bulk/header actions.

```php
trait AuthorizesByPermission
{
    public static function canCreate(): bool          { return static::permits('create'); }
    public static function canEdit(Model $r): bool    { return static::permits('update'); }
    public static function canView(Model $r): bool    { return static::permits('view'); }
    public static function canDelete(Model $r): bool  { return static::permits('delete'); }
    public static function canViewAny(): bool          { return static::permits('view'); }
    // canForceDelete, canRestore follow the same pattern

    public static function getAuthorizationResponse(string|UnitEnum $action, ?Model $record = null): Response
    {
        $mapped = match ($ability) {   // $ability = enum value/name or the string itself
            'viewAny', 'view' => 'view',
            'create', 'replicate' => 'create',
            'update', 'reorder' => 'update',
            'delete', 'deleteAny', 'forceDelete', 'forceDeleteAny' => 'delete',
            'restore', 'restoreAny' => 'restore',
            default => null,
        };
        return match ($mapped) {
            'create' => static::canCreate(),
            default => $mapped && static::permits($mapped),
        } ? Response::allow() : Response::deny();
    }

    public static function moduleKey(): string
    {
        $base    = class_basename(static::class);
        $english = Str::endsWith($base, 'Resource') ? substr($base, 0, -strlen('Resource')) : $base;
        return Str::snake($english);
    }

    protected static function permits(string $action, ?Model $record = null): bool
    {
        $user = Auth::user();
        if (!$user) return false;

        return !LockPolicy::blocks(static::moduleKey())
            && !($record !== null && LockPolicy::blocksRecord(static::moduleKey(), $record))
            && $user->permits(static::moduleKey(), $action);
    }
}
```

The developer bypass (`isDeveloper()` → `true`, no `Permission` row) lives in `User::permits()`, which the trait delegates to — every `can*` passes (also relied on by `EnsureHasPermission` middleware and the test scaffold's `developer()` helper).

**Module key derivation (automatic):**
- `UserResource` → `'user'`
- `ThsResource` → `'ths'`
- `OnboardingResource` → `'onboarding'`

**Why `getAuthorizationResponse()` exists:** Filament v5 authorizes table row/bulk/header actions through `Resource::get*AuthorizationResponse()` -> `getAuthorizationResponse()`, which **allows when no policy exists** (the app has none). With `canX()` alone, in-table Delete/Edit/Replicate were never hidden or blocked; now an unauthorized action auto-hides and is denied server-side. Unknown abilities deny.

**`canCreate()` is now consulted by it (2026-10-28):** the `'create'`/`'replicate'` arm returns `static::canCreate()` instead of raw `permits('create')` — resource-level hard-false overrides (`canCreate=false` on Contact/EnergyTest/ReservationPolicy) now also hide and deny every create-context action (List page, RM header create, the §3.5 view-modal Create shortcut) for otherwise-permitted users; before this, a permit holder could SILENTLY create on a hard-false resource (the vendor gate consults `getAuthorizationResponse()`, which had diverged from `canCreate()`). Resources that don't override `canCreate()` are unchanged (its default IS `permits('create')`). The same divergence exists for `canForceDelete=false` on Project (maps to `permits('delete')`) but is UNREACHABLE — no ForceDeleteAction exists in the UI, so nothing consults `canForceDelete()`; reviewed 2026-10-29 and deliberately left alone (if a force-delete action is ever added, extend the same match-arm then).

**Cost:** one request = 2 Redis GETs (`Permission::forUser`), not 2 per check — `User::permits()` memoizes the row on the guard-cached instance. Do not memoize with `once()` (see `adminPanelPermissionLogicPattern.md`).

**Hard override pattern:** When a resource needs special-case authorization (e.g., super-admin-only), override `canViewAny()` and `permits()` in the resource so every ability follows (as `PermissionResource` does — `permits()` = `canViewAny() && trait permits`, the trait's methods aliased via `use … { AuthorizesByPermission::permits as traitPermits; }`):

```php
// PermissionResource.php
protected static function permits(string $action): bool
{
    return static::canViewAny() && static::traitPermits($action);
}
```

Overriding `canViewAny()` alone only guards page entry; `permits()` is what the in-table actions and `getAuthorizationResponse()` read. Record-specific denials (nobody deletes their own permission row) override `getAuthorizationResponse()` and fall through to `traitAuthorizationResponse`; bulk delete adds `->authorizeIndividualRecords()` so each selected record is checked.

**`RelationManager` base** (`app/Filament/RelationManagers/RelationManager.php`, shared by every manager): `canViewForRecord()` and `getAuthorizationResponse()` follow the **related model's** Filament resource (`Filament::getModelResource()`: tab needs its `canAccess()`; row/header/bulk actions map to its view/create/update/delete…). Attach/Detach/Associate/Dissociate (+bulk) follow the **owner** resource's `update` (via `getDefaultActionAuthorizationResponse`). Related models with no resource keep vendor behaviour (allow). Managers that override `canViewForRecord()` must call `parent::` first (`SkillsRelationManager`, `EventSharesRelationManager`). Consequence: an admin lacking the related module loses that child tab on the owner's page.

---

### 6) `FilamentEditHeading` trait

Located at `app/Traits/Filament/FilamentEditHeading.php`. Applied on **every `EditRecord` page** (alongside `FilamentHeaderActions` + `FilamentPageBehavior`). Gives each Edit page a record-aware heading so the admin never edits the wrong record:

> **ویرایش {modelLabel}: {recordTitle}** — e.g. `ویرایش قوانین رزرو: میز کار`

Filament's default `EditRecord::getHeading()` resolves to `getTitle()` → `ویرایش :label` where `:label = getRecordTitle()` — and `getRecordTitle()` falls back to the generic model label when the resource sets no record title, so every Edit page reads identically. This trait overrides `getHeading()` to surface the record's own identity, resolved through `Resource::getRecordTitle($record)`, with a safe fallback to `$this->getTitle()` when the resource has no real title (no regression for unconfigured resources or null records).

```php
trait FilamentEditHeading
{
    public function getHeading(): string|Htmlable
    {
        $resource = static::getResource();
        $label = $resource::getModelLabel();
        $title = (string) $resource::getRecordTitle($this->getRecord());

        if (! filled($title) || $title === $label) {
            return $this->getTitle();
        }

        return __('resources/general/strings.edit_heading', ['label' => $label, 'title' => $title]);
    }
}
```

The heading format string lives once in `lang/fa/resources/general/strings.php` → `edit_heading` (`'ویرایش :label: :title'`).

**Each resource supplies its record title via exactly one of two levers** (this is the only resource-side config the trait needs):

1. **Column-based** — set `protected static ?string $recordTitleAttribute = '<column>';` when one column identifies the record (`UserResource` → `'name'`, `ThsResource` → `'request_subject'`, …). Filament reads it natively; no method needed.
2. **Composite / enum / accessor** — override `getRecordTitle(?Model $record): ?string` when the identity is a combination, a non-column value, or an HTML-stored column (`ReservationPolicyResource` → `ResourceType::tryFrom($record->resource_type)?->getLabel()`, `ProfileResource` → `$record->user?->name ?? '#'.$record->personnel_id`, `ResourceResource` → `$record->labeled_name`, `ContactResource` → `Str::limit($record->body, 60)` (Textarea, plain), `FeedResource` → `Str::limit(strip_tags($record->content), 60)` and `PostResource` → `strip_tags($record->title)` and `FAQResource` → `strip_tags($record->question)` — those three columns are `RichEditor` storing HTML, so bare `recordTitleAttribute` / un-stripped `Str::limit` would surface raw `<p>/<strong>` tags in the View/Edit heading + breadcrumb). Always guard `if (! $record) return null;` first — the `?Model` signature permits null (Filament may call before a record is loaded).

**Rules:**
- Every `EditRecord` page must `use FilamentEditHeading;`. Create/List/View pages do **not** use it — `$this->record` is null there and the trait is Edit-only.
- **Never use the column lever (`$recordTitleAttribute`) when the column is a `RichEditor`** — Filament returns the raw HTML and the heading/breadcrumb render literal `<p>/<strong>` tags. Use the method lever and `strip_tags()`; mirror `getGlobalSearchResultTitle()`, which already strips for the same reason. Any `getRecordTitle` returning `RichEditor` content must `strip_tags()` *before* `Str::limit()`/display (stripping first also prevents `Str::limit` from cutting mid-tag and emitting broken markup).
- Relations accessed inside a composite `getRecordTitle` must already be eager-loaded by the resource's `getEloquentQuery()` (e.g. `ReservationResource` withs `resource`, `ProfileResource` withs `user`) — the trait runs on the Edit page where the record is already loaded, but keep it lazy-load-safe by relying on those withs.
- Do not duplicate this heading logic per-Edit-page — the trait is the single source. Add only the per-resource title lever (one line) above.

---

## Enums (all flat in `app/Enums`)

Every enum lives flat in `app/Enums/` (`App\Enums`); there are no per-resource `Enums/` folders (moved 2026-11-10). Examples:

```
app/Enums/UserRole.php
app/Enums/UserStatus.php
app/Enums/UserType.php
app/Enums/FeedCategory.php
app/Enums/TicketStatus.php
app/Enums/TicketPriority.php
app/Enums/RequestType.php
app/Enums/TaskStatus.php
app/Enums/TaskState.php
app/Enums/DocumentStatus.php
app/Enums/LinkType.php
...
```

Layout and merge rules: `app/Models/modelPattern.md` "Enums".

**An enum's backing string values are the single source of truth wherever that domain concept has an ordinal rank.** `app/Enums/Position.php` backs `HasProfileHierarchy::RANKS` (`app/Models/Concerns/HasProfileHierarchy.php`) — every enum case's value is a `RANKS` key (lower number = higher rank). Adding a case means updating both the enum's match arms (label/color/icon) and `RANKS` in lockstep; every consumer (admin form/table/infolist/export, `rank()`, `isDeptHead()`, `highestRankingInDepartments()`, and the user-panel Status board's `ORDER BY FIELD(...)` sort) reads from one of these two places, so nothing else needs touching. Never hard-code the position list a third time elsewhere.

**Every presentational enum implements `HasColor`, `HasIcon`, `HasLabel`:**

```php
enum UserRole: string implements HasColor, HasIcon, HasLabel
{
    case User      = 'user';
    case Admin     = 'admin';
    case Developer = 'developer';

    public function getLabel(): string
    {
        return match ($this) {
            self::User      => 'کاربر',
            self::Admin     => 'مدیر',
            self::Developer => 'توسعه‌دهنده',
        };
    }

    public function getColor(): string|array
    {
        return match ($this) {
            self::User      => 'gray',
            self::Admin     => 'warning',
            self::Developer => 'info',
        };
    }

    public function getIcon(): ?string
    {
        return match ($this) {
            self::User      => 'heroicon-o-user',
            self::Admin     => 'heroicon-o-shield-check',
            self::Developer => 'heroicon-o-code-bracket',
        };
    }
}
```

**Usage pattern in table column:**

```php
TextColumn::make('role')
    ->badge()
    ->color(fn($state) => UserRole::tryFrom($state)?->getColor() ?? 'gray')
    ->icon(fn($state)  => UserRole::tryFrom($state)?->getIcon()  ?? '')
    ->formatStateUsing(fn($state) => UserRole::tryFrom($state)?->getLabel() ?? $state)
```

---

## Navigation Badges

Resources with actionable unread/pending counts expose a live badge on the sidebar navigation item:

```php
// ContactResource.php
public static function getNavigationBadge(): ?string
{
    return (string) static::getModel()::query()->where('is_read', false)->count() ?: null;
}

public static function getNavigationBadgeTooltip(): ?string
{
    return __('resources/contact/strings.nav_badge_tooltip');
}
```

**Rules:**
- Return `null` (not `'0'`) when the count is zero — an empty badge should not appear.
- Tooltip is always localized.
- Only add badges to resources where an unread/pending state has operational significance (contacts, tickets, etc.).

---

## Admin notifications — `Notification::make()` (ephemeral toast vs persistent bell)

Filament ships its own notification primitive; the admin panel uses it directly, the user panel does
**not** (it has a separate lightweight toast — see the contrast at the end of this section).

- **Ephemeral admin toast** — `Notification::make()->title(…)->success()/danger()/warning()/info()->send()`
  renders Filament's auto-dismissing toast at the top of the panel. No DB row, gone in seconds. The
  canonical in-resource shape is `FilamentActions`' assign/unassign/bulk-unassign actions
  (`Notification::make()->success()->send()` inside the `->action(…)` closure, after the handler runs).
  Use this for "the write succeeded / failed" feedback inside an admin page.
- **Persistent bell entry** — `->sendToDatabase($user)` writes a row to Filament's `notifications`
  table (stays until read); `->persistent()` marks it non-auto-dismiss. `->actions([Action::make(…)
  ->dispatch(event, data)->close()])` attaches a button that dispatches a Livewire event on click.
  The former `InteractsWithNotifications` wrapper trait was deleted (2026-11-10, zero consumers); write
  `Notification::make()->success()->actions([Action::make('view')->button()->dispatch(…)->close()])
  ->sendToDatabase($user)` inline.
- **The user-panel bell** is the same `notifications` table rendered by
  `App\Livewire\Dashboard\UnreadNotifications` (extends Filament's `DatabaseNotifications`), which also
  folds >4-per-key rows into aggregate rows (`agg:` synthetic ids, DMS sign/read split). The rows it
  lists are written by `App\Services\Menu\NudgeService` (`->warning()->persistent()->actions([view,
  markAsRead])->getDatabaseMessage()`), the bell/nudge layer documented in `statePattern.md`.

**Contrast — user-panel ephemeral toast is NOT `Notification::make()`.** The non-Filament user panel
has a separate, hand-built auto-dismissing toast (`<x-ui.modals.toast/>`, no DB, `window` CustomEvent
driven), documented in full at `app/Services/Menu/statePattern.md` ("Ephemeral toast"). Do not call
`Notification::make()->send()` from user-panel Livewire components — it would render into a Filament
mount that does not exist there. Admin → `Notification::make()`; user-panel → `x-ui.modals.toast`.

---

## User-panel badge/nudge legend (cross-reference, not this doc's mechanism)

The Filament nav badges above are admin-panel-only. The **user panel** has a separate, unrelated
notification system — `App\Services\Menu` (dot/badge = live status, bell/nudge = one-time dismissible
alert), documented in full at `app/Services/Menu/statePattern.md`. Do not conflate the two.

That system's user-facing explainer — `<x-dashboard.modal.badge-legend>` (documented at
`resources/views/viewPattern.md` §8.5) — is backed by a **single source of truth**,
`App\Services\Menu\BadgeLegendCatalog`, keyed by each indicator's `getKey()`. There is exactly one
master catalog (all 27 badges, grouped into themed tabs) in the actual Profile module
(`resources/views/livewire/dashboard/profile.blade.php`), and per-module micro-legends in modules that
have their own dedicated badge (currently the badge-bearing user-panel modules). **Rule: never hand-write a badge row's copy
in more than one place.** A module's micro-legend must call `BadgeLegendCatalog::get('its-own-key')`;
the master catalog must call `BadgeLegendCatalog::grouped()`. Both read the same row, so they cannot
drift out of sync. If you add a badge to a new module, add its row to `BadgeLegendCatalog::all()` first,
then wire both the module's own legend (if it gets one) and confirm it appears in the master catalog —
never write the `tone`/`icon`/`label`/`lights`/`clears` text a second time anywhere else.

---

## `ProjectResource` (cross-reference, not a new mechanism)

`ProjectResource` follows this doc's standard shape verbatim (Schema classes, `FilamentAdminGuide`/`FilamentActions`/`FilamentFilters`/`AuthorizesByPermission` traits, a `TasksRelationManager`) — nothing resource-specific to add here. Its **domain-specific** conventions (the `member_ids`/`departments` audience-JSON UI, `scopeVisibleTo()`, the shared `ReportingService` reused verbatim by its table/infolist, the `channel_id` provisioning link) are documented in full at `app/Livewire/Dashboard/Project/projectPattern.md`, since that module owns the domain model this resource administers. Read that file for anything beyond generic Filament wiring.

---

## Widgets

All widgets live in `app/Filament/Widgets/` and are auto-discovered by the panel provider.

### AccountWidget

Sorts at `-3` (renders topmost, above all others). Spans full width. Passes structured data to its blade view via `getViewData()`.

```php
protected int|string|array $columnSpan = 'full';
protected static int $sort = -3;

protected function getViewData(): array
{
    $user = Auth::user();
    return [
        'user'        => $user,
        'greeting'    => shortGreeting($user->name),
        'roleLabel'   => ...,
        'department'  => $user->profile?->department?->name,
        'jalaliDate'  => convertToPersian(Jalalian::now()->format('l | d F')),
    ];
}
```

### Dashboard

Overrides `getHeading()` to return a blade view instead of a string — the heading area becomes a full rendered component:

```php
class Dashboard extends BaseDashboard
{
    public function getHeading(): string|Htmlable
    {
        return view('filament.widgets.dashboard');
    }
}
```

### ModulesGuideWidget

Driven entirely by `config('modules', [])`. Merges module config with two internal maps (`moduleMeta()`, `moduleFilamentIcons()`) and groups by `major_category`. Categories are sorted by a predefined Persian order array.

```php
protected int|string|array $columnSpan = 'full';

public function getGroupedModules(): Collection
{
    return collect(config('modules', []))
        ->map(fn($module) => array_merge($module, $meta[$id] ?? [], $icons[$id] ?? []))
        ->groupBy(fn($module) => $module['major_category'] ?? 'محتوا و ارتباطات')
        ->sortBy(fn($_, $key) => array_search($key, $categoriesOrder, true))
        ->mapWithKeys(fn($modules, $category) => [md5($category) => [
            'name'    => $category,
            'modules' => $modules,
        ]]);
}
```

Four major categories (in order): `محتوا و ارتباطات` / `عملیات و منابع` / `سیستم‌ها و ابزارها` / `کاربران و سازمان`.

### ModuleAnalyticsWidget

A heavy analytics widget. Key patterns:

```php
protected static bool $isLazy = true;          // deferred loading
protected string $view = 'livewire.admin.widgets.filament-analytics';

public string $activeTab = 'users';             // tab state tracked in Livewire
```

Every data-fetching method is cached:

```php
#[Computed(seconds: 300, cache: true)]
public function usersData(): array { ... }
```

`#[Computed(seconds: 300, cache: true)]` caches each analytics method for 5 minutes under `lw_computed.{component}.{prop}` — **and this only works because every method is consumed as a bare no-argument property** (`$this->usersData`, `$this->adsData`, … in `getActiveStatsCount` / `statsSchema`), which routes through `BaseComputed::handleMagicGet`. A method *called directly* (`$this->getModuleAData($dept)`) bypasses that path so the attribute is inert there — see rule 25 and the `OperationalChart` / `StructuralChart` / `HrAnalyticsService` `rememberGlobal` pattern.

**MANDATORY — every new admin Resource extends this widget.** Full checklist (data method + `getAllTabs()`/`getActiveStatsCount()`/`statsSchema()` registration + magic-property-only consumption + test coverage) lives in `app/Filament/Widgets/widgetsPattern.md` under "`ModuleAnalyticsWidget` — tabbed stats" — treat it as the same never-skip fan-out as `FilamentAdminGuide`/legend (§3.4).

### OperationalChart / StructuralChart

Extends `ChartWidget` with `HasFiltersSchema` and deferred filter loading:

```php
use HasFiltersSchema;

protected bool $hasDeferredFilters = true;
protected static bool $isLazy = true;
protected int|string|array $columnSpan = ['sm' => 'full', 'md' => 1]; // responsive
```

Farsi filter action labels:

```php
protected function filtersApplyAction(Action $action): Action
{
    return $action->label('اعمال');
}

protected function filtersResetAction(Action $action): Action
{
    return $action->label('بازنشانی');
}
```

`filtersSchema()` returns a `Schema` with a Radio component for module selection.

### HR analytics chart widgets (HrDemographicsChart / HrQualificationChart / HrUnitHealthChart / HrEngagementChart)

Four `ChartWidget`s extending the same `HasFiltersSchema` + deferred-filter shape as `OperationalChart`/`StructuralChart` (added 2026-08-03). Each carries a Radio `module` filter whose options dispatch `getData()` via `match` to one `getHr{X}Data()` method per module (17 modules total, hr_a..hr_q). Every data method is annotated `#[Computed(seconds: 300, cache: true)]` and is called directly from `getData()` (the `#[Computed]` cache engages on property access; calling the method directly is consistent with the sibling widgets).

**Scope is org-wide** (no `getScopeCondition`/self-department filter), intentionally diverging from the self-scoped `OperationalChart`/`StructuralChart` — these are managerial/HR views, not personal ones.

**Null/invalid bucketing convention.** Enum-or-bucket columns never silently drop rows: null/invalid values land in a trailing `__other__` / `سایر` / `نامشخص` dataset appended only when such rows actually exist (`$rows->contains(fn($r) => !in_array($r->{$column}, $known, true))` guard, or `array_sum($unknown) > 0` for the inline-array variants). The position axis is built by a private `positionAxis($rows)` helper (in `HrQualificationChart`) returning `[$keys, $labels, $index]` that appends `__other__` only when a null/invalid position is present; `positionMap()` is the matching `array_flip` validity map. Department-axis widgets share `topDepartments()` (top-10 by profile count, deterministic `orderByDesc('cnt')->orderBy('department_id')` tie-breaker, label = `COALESCE(NULLIF(description,''), name, code)`) via the `App\Filament\Widgets\Concerns\DepartmentAxis` trait (used by `HrUnitHealthChart` + `HrEngagementChart`). `HrUnitHealthChart` also has a private `bucketSeries($rows, $idx, $column, $known, $rest, $size)` that folds rows into known datasets plus one trailing rest dataset (catches everything NOT in `$known` — null + invalid).

**59. PHP array COW trap — do not alias-then-write.** `$target = $male; $target[$i] += $v;` does NOT update `$male`: PHP arrays are value types with copy-on-write, so the write separates a detached copy and the named array stays unchanged (chart renders blank). Mutate the named arrays directly — branch inside the inner loop: `if ($r->gender === 'male') $male[$i] += $v; elseif ($r->gender === 'female') $female[$i] += $v; else $unknown[$i] += $v;`. A `$data = array_fill(...)` that is the sole owner and is never aliased to another named array IS safe to mutate (e.g. the per-band loop in `getHrKData`).

**60. Nullsafe on grouped-row lookup, not `??`.** `$rows->firstWhere('department_id', $code)` can return null under a cache race (`topDepartments()` and the data method are cached independently); `$row->total ?? 0` throws on null `$row` in PHP 8 — property access on null errors before `??` evaluates. Use `$row?->total ?? 0` (nullsafe operator). Array-key access (`$totals[$code] ?? 0`) is also null-safe and was the older idiom.

**61a. Cardinal rule — admin panel icons are Heroicons, user panel icons are Material Symbols, and a value picked in one system is NEVER reused raw in the other.** This project enforces (the admin-vs-user icon convention): Filament admin UI (`->icon()` on table columns, infolist entries, actions, `<x-icon>`) uses Heroicon identifiers (`heroicon-o-*`); the user panel renders icons as literal ligature text inside `<span class="material-symbols-rounded">{value}</span>`. **Any field where an admin picks ONE icon that must be shown in both places needs an explicit closed-enum translation step — never a shared raw string.** Reference implementation: `App\Enums\ResourceTypeIcon` carries both a Heroicon `value` (admin) and a `getMaterialIcon()` match (user panel); `ResourceResource`'s `TypeProvisioner` derives and stores `display_material_icon => ResourceTypeIcon::from($data['display_icon'])->getMaterialIcon()` at write time — the two representations never drift because one is mechanically derived from the other via a `match()` with no `default` arm (a new case added to the enum without a corresponding `getMaterialIcon()` arm throws `UnhandledMatchError` immediately, not silently — fail loud, not silently garbled). **The bug this rule exists to prevent, found live in production:** `Department`'s `ticket_options.icon` repeater field used this exact `ResourceTypeIcon` picker correctly for the admin-side Heroicon path (`HasTicketOptions::getCustomHeroiconForArea()`), but its Material Symbols read path (`getCustomMaterialIconForArea()`) reused the *same raw stored Heroicon string* directly, printing literal text like `heroicon-o-computer-desktop` inside a `material-symbols-rounded` span in the live user-panel ticket UI (`ths/create.blade.php`, `ths/ticket-table.blade.php`). Fixed by routing the material-icon read through `ResourceTypeIcon::tryFrom($stored)?->getMaterialIcon()` before falling back to the area's default lookup — never trust that a stored "icon" column is already in the right icon system for wherever you're about to render it. Same principle applies to any hand-written array pairing an icon string with an enum-backed status/type WITHOUT deriving it from that enum's own method (see `DocumentStatus::getMaterialIcon()`, added specifically so `DMS::getStatusIcon()` derives its glyph from the enum instead of maintaining a second parallel array that could silently drift when a new `DocumentStatus` case is added). When building a NEW field where an admin picks an icon for user-panel-only rendering (no admin-side Heroicon use at all), skip the dual-system translation entirely and use a **Material-Symbols-native closed enum** instead (see `App\Enums\LinkIcon`, `App\Enums\SkillIcon`) — don't force a Heroicon roundtrip where nothing ever consumes the Heroicon half.

Single-query aggregation preferred: `SUM(CASE WHEN ... THEN 1 ELSE 0 END)` in one `groupBy` query beats two separate total/probational queries (`getHrMData`, `getHrKData`, `getHrOData`). MySQL `TIMESTAMPDIFF`/`NOW()`/`DATE_SUB` are intentional (MySQL-only project, matches siblings). No user input reaches SQL (Radio option list is fixed → `match` → fixed method); raw `field` values surface as Chart.js text labels (no HTML → no XSS).

### ManagePreferencesWidget

Implements `HasActions` and `HasSchemas`, uses `InteractsWithActions`, `InteractsWithSchemas`, and the `FilamentPreferences` trait. Renders as a custom Livewire view.

```php
public function getPreferencesColumns(): int { return 4; }
```

### Approval-queue resource pattern + ghost-promote widget (Skills / Talent Pool)

`SkillRequestResource` is a read/transition-only resource (no create/edit page — a `ListSkillRequests` page only) with inline one-click `approve`/`reject` `Action`s AND `groupedBulkActions` mirroring them, both gated by `self::canEdit($record)`/`self::canEdit(new Model())` in `->visible()` PLUS `abort_unless(...)` inside the `->action()` closure (defense in depth — `visible()` alone only hides the button, it doesn't stop a crafted request). Every transition (row or bulk) is guarded server-side to only act on the current `status`, so a stale/duplicate click no-ops instead of double-processing. `UnmetSkillDemandTable` is a "ghost-promote" widget shape: lists `Skill::ghost()`-scoped rows ordered by demand signal, with a single `promote` row action that opens a completion form (reusing `SkillFormPresenter::category()`/`::icon()` — the same `Select` fields the real `SkillResource` form uses, not duplicated `TextInput`s) then calls the model's own `activate()`. Ghosts are also directly browsable in `ListSkills` via a dedicated "ghosts" tab (see rule 58 below for the `getTableQuery()` override this required). See `app/Livewire/Dashboard/Profile/skillsPattern.md` for the full data-model/lifecycle this resource pair drives.

**Trap avoided — a raw ad-hoc `Action::make()` echoed directly in a custom Blade loop (`{{ $this->someAction($row) }}` inside `@foreach`) never actually works**, even with `HasActions`/`InteractsWithActions` on the component. Filament only auto-registers (`cacheAction()`) actions through specific "action-holder" contexts — Table row/header actions, Form/page header actions — never a bare per-loop-item action rendered by hand. `UnmetSkillDemandTable` originally did exactly this (dynamically-named `promote_{$skill->id}` actions in a hand-rolled `getGhosts()`/`@forelse` view); the button rendered but clicking it threw `ActionNotResolvableException` in both tests AND real usage. Fix: extend `Filament\Widgets\TableWidget` (not plain `Widget`) and define the promote button as a genuine `->recordActions([...])` entry on a `table()` method — Table's own action resolution (`resolveTableAction()`) handles registration correctly, and you get real pagination (`->defaultPaginationPageOption()`/`->paginated([...])`) for free instead of a hardcoded `->limit(10)`.

**58. A List page `Tab` cannot un-apply a `where()` the Resource's `getEloquentQuery()` already baked in — override `getTableQuery()` on the page to remove that base restriction, and push it back into each tab's `modifyQueryUsing()` instead.** `Tab::modifyQueryUsing()` chains an ADDITIONAL `where()` onto whatever `ListRecords::getTableQuery()` returns (which defaults to `static::getResource()::getEloquentQuery()`); if the resource's base query already excludes a subset of rows (e.g. `SkillResource::getEloquentQuery()` hard-filters `->where('is_ghost', false)` so ghosts never leak into ordinary browsing/edit/global-search), no tab can ever show that subset — the exclusion ANDs with every tab's own filter, always yielding zero rows for the "show the excluded rows" tab. Fix: override `protected function getTableQuery(): Builder` on the List page to build the query WITHOUT the resource's restrictive clause (replicate only what should apply unconditionally, e.g. `withCount(...)`), then give EVERY tab (including the "normal" one) an explicit `modifyQueryUsing()` so the previously-implicit exclusion is now spelled out per-tab. Reference: `ListSkills::getTableQuery()` returns `Skill::query()->withCount('skillUsers')` (no `is_ghost` clause), and `getTabs()` has `catalog` (`->where('is_ghost', false)`, default/first tab — preserves the original hide-ghosts-by-default behavior) + `ghosts` (`->where('is_ghost', true)`, badged with `Skill::ghost()->count() ?: null`, mirroring `ListUsers`' `?: null` badge idiom).

**Trap this creates — a page-navigation row action can still 404 on a row the table now shows but the Resource's `getEloquentQuery()` still excludes.** Row actions resolved from the table's own loaded record (a modal `ViewAction` with no dedicated view page, `DeleteAction`) are safe — they never re-query. But `EditAction` (or any action navigating to a registered Resource page) triggers `EditRecord::resolveRecord()` → `static::getResource()::resolveRecordRouteBinding()`, which DOES use the resource's still-restrictive `getEloquentQuery()` — so editing a ghost row surfaced by the new tab 404s. Guard the action itself, not the tab: `self::editAction()->hidden(fn(Skill $record): bool => $record->is_ghost)` in `SkillResource::table()`. Do this for every row action that navigates to a page-based (non-modal) Resource route whenever a List page tab widens visibility past the Resource's own `getEloquentQuery()`.

### Widget sorting convention

`$sort` determines widget order on the dashboard. Lower = higher on the page. `AccountWidget` at `-3` ensures it always appears first regardless of any other widget registered later.

Dashboard sort block (2026-08-03): utility widgets `AccountWidget` `-3`, `ManagePreferencesWidget` `-2`, `ModulesGuideWidget` `-1`; HR analytics block `HrDemographicsChart` `1`, `HrQualificationChart` `2`, `HrUnitHealthChart` `3`, `HrEngagementChart` `4`; existing analytics `UnmetSkillDemandTable` `5`, `ModuleAnalyticsWidget` `6`, `OperationalChart` `7`, `StructuralChart` `8`. The HR block was inserted at the top (sort 1-4) and the four existing analytics widgets renumbered down by sort-integer only — no logic/query/schema change to the existing widgets.

**Revised 2026-08-26**: `ModuleAnalyticsWidget` moved from `6` to `-1` (right under the `ManagePreferencesWidget` settings accordion, above the module guide) so the stats are visible near the top of the dashboard instead of below the HR/operations chart blocks; `ModulesGuideWidget` shifted from `-1` to `0` to keep it directly after. Current block: `AccountWidget` `-3`, `ManagePreferencesWidget` `-2`, `ModuleAnalyticsWidget` `-1`, `ModulesGuideWidget` `0`, HR block `1`–`4`, `UnmetSkillDemandTable` `5`, `OperationalChart` `7`, `StructuralChart` `8` (gap at `6` is harmless).

### Responsive columnSpan

Chart widgets use responsive arrays:

```php
protected int|string|array $columnSpan = ['sm' => 'full', 'md' => 1];
```

Full-width widgets use:

```php
protected int|string|array $columnSpan = 'full';
```

---

## AdminPanelProvider configuration

All panel-level behavior is centralized in `app/Providers/Filament/AdminPanelProvider.php`. Key patterns:

### Colors

Colors are never hardcoded in the provider — they come from a dedicated config:

```php
->colors(config('colors'))
```

### Font

Locale-conditional Yekan font via local provider:

```php
->font(
    (app()->getLocale() == 'fa') ? 'Yekan' : 'IranYekan',
    url: asset('build/assets/fonts/Yekan.woff'),
    provider: LocalFontProvider::class
)
```

### Brand logo (light/dark, per-tenant reversible)

Brand logo, favicon, preferences, and the login-page tenant background are all applied by `App\Providers\Filament\FilamentPanelCustomizer::apply(Panel)` (called from `AdminPanelProvider`), not inline in the provider. The logo pair routes through one `logoHtml(bool $dark)` builder that resolves the actual file via the shared `tenantLogo($dark, 'admin', $auth)` helper (`app/Helpers/index.php`):

```php
->brandLogo(fn() => self::logoHtml(false))
->darkModeBrandLogo(fn() => self::logoHtml(true))

private static function logoHtml(bool $dark): HtmlString
{
    $auth = request()->routeIs('filament.admin.auth.login');

    return new HtmlString(sprintf(
        '<img src="%s" alt="%s" title="%s" style="height:2rem;width:auto;margin:auto" />',
        e(asset(tenantLogo($dark, 'admin', $auth))), e(config('app.name_en')), e(config('app.name_en'))
    ));
}
```

`darkModeBrandLogo()` renders both images; Filament's CSS (`fi-logo-light`/`fi-logo-dark`, plain `dark:` Tailwind variants) toggles visibility off the `.dark` class on `<html>` — no JS needed beyond what's already wired by the app's own theme sync. Works even with `->darkMode(false)` since that flag doesn't gate the CSS. The per-tenant reverse-logo behavior (`admin_reverse_logo` in `config/tenants.php`), its auth-page-only counterpart `admin_auth_reverse_logo`, and the `admin_use_company_logo` short-circuit are all resolved inside `tenantLogo()` itself — `$auth` picks which of the two flags governs the swap, fully independent of each other. Logo paths never hardcoded — see `config/tenantPattern.md` for the full `tenantLogo()` contract.

### Global search

```php
->globalSearch(FaultTolerantGlobalSearchProvider::class, position: GlobalSearchPosition::Topbar)
->globalSearchFieldSuffix(fn(): ?string => match (Platform::detect()) {
    Platform::Windows, Platform::Linux => 'Ctrl+K',
    Platform::Mac => '⌘K',
    default => null
})
->globalSearchKeyBindings(['command+k', 'ctrl+k'])
->globalSearchDebounce('1000ms')
```

The custom `App\Services\Search\FaultTolerantGlobalSearchProvider` (not Filament's stock `true`) wraps each per-resource search step in a try/catch so one throwing resource can't take down the whole bar — see Rule 65 for the full rationale. Platform-aware keyboard shortcut suffix is shown next to the search field in the topbar.

**Coverage (2026-11-15):** a resource opts in with `getGloballySearchableAttributes()` (dotted names must be real relations: `user.name`, `skill.name`) and a record title (`$recordTitleAttribute`, or `getRecordTitle()` for composite titles). Covered now: AiReport, Correspondence (number, subject, user only — never letter body), Letterhead, NotifyRule, ReleaseRequest, Reminder, SkillRequest, Skill (+ the older ones). Deliberately NOT searchable: ReservationPolicy (no text column worth searching). SkillRequest has only an index page, so its `getGlobalSearchResultUrl()` opens the list pre-filtered with `tableSearch` instead of Filament's non-existent view action — any index-only resource must do the same. `FaultTolerantGlobalSearchProviderTest` guards that each declared attribute exists on its model (Correspondence is excluded there because `number` is generated, not fillable).

**Panel-wide table/form defaults (`FilamentServiceProvider`):** table search waits `searchDebounce('800ms')` (not search-on-blur: Enter would not fire it); every `Textarea` is `autosize()` globally; row tints use `->recordClasses()` with MD3 tokens only — Task and Ticket tint open overdue rows with `[&>td]:bg-[color-mix(in_srgb,var(--md-sys-color-error)_8%,transparent)]`, User dims inactive rows with `opacity-60`.

### User preferences

Nine panel behaviors are controlled at runtime by the authenticated user's stored preferences, applied by `FilamentPanelCustomizer::apply()` (the same customizer that handles the brand logo above):

```php
->sidebarCollapsibleOnDesktop(fn() => self::pref('sidebar_collapsible', false))
->sidebarFullyCollapsibleOnDesktop(fn() => self::pref('sidebar_fully_collapsible', false))
->breadcrumbs(fn() => self::pref('breadcrumbs', true))
->collapsibleNavigationGroups(fn() => self::pref('collapsible_groups', true))
->topNavigation(fn() => self::pref('top_nav', false))
->unsavedChangesAlerts(fn() => self::pref('unsaved_changes_alerts', true))
->topbar(fn() => self::pref('topbar', true))
->spa(fn() => self::pref('spa_enabled', true))
->userMenu(position: fn() => self::pref('user_menu_topbar', false)
    ? UserMenuPosition::Topbar
    : UserMenuPosition::Sidebar)
```

Preferences are read from `Auth::user()->extra['preferences']` (a JSON column):

```php
private static function pref(string $key, mixed $default = false): mixed
{
    $preferences = Auth::check() ? (Auth::user()->extra['preferences'] ?? []) : [];
    return $preferences[$key] ?? $default;
}
```

**Not every preference is a Panel fluent method.** Four newer toggles live in the same `getPreferenceFields()` array and `user.extra['preferences']` JSON but are consumed by other mechanisms, since Filament's `Panel` has no native fluent method for them:

- `persian_dates` (default **on**) — read directly by `FilamentFilters::jalaliDateRangeFilter()` (see that section above), not by `FilamentPanelCustomizer`.
- `records_per_page` (Slider, index-mapped to `FilamentPreferences::RECORDS_PER_PAGE_OPTIONS = [10, 25, 50, 100]`, default index `0` = 10) — consumed by a single global `Table::configureUsing()` hook registered in `App\Providers\FilamentServiceProvider::registerTableDefaults()`, which applies to **every** Filament table/widget app-wide: `$table->paginationPageOptions([10, 25, 50, 100])->defaultPaginationPageOption(fn () => Auth::user()?->getPreference('records_per_page', 25) ?? 25)`. A table that calls its own `->defaultPaginationPageOption()`/`->paginated([...])` explicitly (e.g. `UnmetSkillDemandTable`, fixed at `10`) still wins — `configureUsing` only sets the base default, per-table calls made afterward override it. **Trap:** never reference a trait constant via the trait's own name from another class (`FilamentPreferences::RECORDS_PER_PAGE_OPTIONS` from `FilamentServiceProvider`) — PHP 8.2 trait constants are only accessible through a class that actually `use`s the trait; doing it from outside throws `Error: Cannot access trait constant ... directly` on every table mount (confirmed live, 2026-08-22). Keep the options list as a plain literal in `FilamentServiceProvider` instead of cross-referencing the trait.
- **Deferred tables (2026-11-02):** the same global `Table::configureUsing()` hook also calls an unconditional `->deferLoading()` — every table shows its skeleton first and loads rows in a second request; there is no option or opt-out (all tables, by decision). `Tests\TestCase::setUp()` turns it off for the test run only, so a new resource test that asserts rows needs nothing extra; one that tests the deferred flow re-registers `Table::configureUsing(fn ($t) => $t->deferLoading())` and calls `->loadTable()` (see `LinkResourceTest`). Full note in `app/Providers/providersPattern.md`.
- **Docked bottom bar collapses to one corner button (2026-11-02, ported from BMS-CM's peek mode, simplified to a flag):** when `nav_dock` is on (desktop ≥1024px), a small `.dock-min` button (`resources/views/filament/partials/dock-min.blade.php`, rendered by `FilamentServiceProvider` on `PanelsRenderHook::SIDEBAR_FOOTER` — a direct child of `.fi-sidebar` AFTER the scrolling `<nav>`, so it is a fixed handle at the bar's end that never overlaps scrolled items (the first version sat inside the nav on `SIDEBAR_NAV_END` and covered the first item; it is a fixed 2.75rem square, the same as the docked items — stretching the button to the bar was wrong because the bar also contains the scrollbar strip, so if the item size changes, change this one number to match). **Docked bar look (glass dock, 2026-11-02, replaces the solid-primary item squares):** the bar is a centered (`inset: auto 0 .75rem 0; margin-inline: auto`), 94%-opaque `surface-container` with a CSS-only frosted look — NO `backdrop-filter` (removed 2026-11-02 for scroll performance): a top-down on-primary sheen gradient plus a faint diagonal primary tint plus the inset top highlight in the shadow — a 1.25rem radius and a PRIMARY-tinted layered shadow (admin style rule: radiant shadows tinted with primary, never gray/black); it enters with the shared `slideUpFade` keyframe from `animation.css` (never a new keyframe in `filament.css`); items are 2.75rem transparent squares with a 1.5rem icon, tinted with primary on hover, a SOLID `--md-sys-color-primary` fill + `on-primary` icon + soft glow when active, and a `--header-border-color` dot under the active one; a hairline divider separates groups; the horizontal scrollbar is hidden, and instead a start and an end arrow button (`resources/views/filament/partials/dock-arrow.blade.php`, rendered on `SIDEBAR_START` and, before `.dock-min`, on `SIDEBAR_FOOTER`; heroicon chevrons mirrored under `html[dir="rtl"]`, 2rem × 2.75rem, primary-tinted hover) sit INSIDE the bar and are shown only on the side that has more items — `nav-dock.js` toggles their `hidden` attribute from the nav's `scroll`, window `resize`, init and `livewire:navigated`, and a click scrolls the nav by 60% of its visible width in the reading direction (RTL-aware, `behavior: 'auto'` under reduced motion). They are hidden when the bar is collapsed. Sideways scrolling also works without them: trackpad/touch swipe (native `overflow-x: auto`; `overscroll-behavior-x: contain` stops an edge swipe from triggering the browser's back gesture), Tab focus (scrolls the item into view), and the wheel mapping below; below 1024px the dock is not used at all (the normal Filament sidebar applies). Because the scrollbar is hidden, `nav-dock.js` maps a vertical mouse wheel over the bar to sideways scrolling (the non-passive `wheel` listener is bound on the bar itself inside `bindArrows()`, never on `document`, so page scrolling stays passive for users without the dock; direction-aware for RTL, only when the bar overflows, never when collapsed) and re-centers the active item after init and every `livewire:navigated`. All colors are MD3 tokens / `color-mix()` — no hex, `rgb()` or `bg-white`; a Filament `heroicon-o-arrows-pointing-in` via `<x-filament::icon>`, styled by the plain-CSS `.dock-min-btn` class in `filament.css` — a rounded square with NO border — a `--header-border-color` tint plus a soft same-colour shadow (stronger on hover, where it also fills solid), icon at the stock `fi-icon` 1.25rem so it centers, separated from the nav items by a hairline divider) sits at the end of the floating bar; clicking it adds `html.nav-dock-min`, which `resources/css/core/filament.css` turns into a single square button at the bottom-right (`right: 1rem`, background `var(--header-border-color)`, white grid icon via `mask` using `--md-sys-color-on-primary`) — the nav is hidden. Clicking that button removes the class. State lives in `localStorage` `nav-dock-min` (handled in `resources/js/core/nav-dock.js`, re-applied on every `livewire:navigated` because Livewire resets `<html>` classes) and the HEAD_START bootstrap script in `registerThemeBootstrap()` re-adds it before first paint so there is no flash of the full bar. It never applies outside `nav-dock-bottom` (all rules are scoped to that class).
- **Two table-behaviour preferences (2026-11-02, ported from BMS-CM's row-click / table-state toggles but saved like every other option):** `FilamentPreferences` gained `row_click_edit` (Toggle, default **false** = today's behaviour: a row opens the view/infolist modal) and `persist_table_state` (Toggle, default false), stored in `users.extra.preferences` and edited on the admin-UI settings page; `FilamentPreferences::mount()` merges every Toggle's `default()` UNDER the user's saved values (Filament's `fill()` of a partial array does NOT apply defaults to missing keys, so a default-on toggle the user never saved used to render OFF and a first save wrote OFF — fixed for all toggles). (1) `App\Filament\Pages\ListRecords::makeBaseTable()` (the base class every resource list page extends; hooked there so the resource's own `table()` runs first) sets `recordUrl()` through `rowClickUrl()` UNLESS the resource already set its own `recordUrl()` (`hasCustomRecordUrl()`, e.g. `ReservationPolicyResource`, which keys its edit link by `resource_type`) — a custom link always wins and Filament's default is skipped too: the resource's edit page when `row_click_edit` is on AND `hasPage('edit') && canEdit($record)`; otherwise the destination of the table's `view` row action — `null` for the infolist modal (so the modal takes the click) or its URL for a resource with a view PAGE (e.g. Energy tests); a resource with no view action at all keeps the edit page when editable. Filament's row click uses the URL first and the record action second (`tables/index.blade.php`), and its OWN default URL points at the edit page for any table with a URL-bearing edit action — so merely skipping the override when the toggle was off left BOTH states on the edit page, and copying BMS-CM's plain `null` broke view-page resources (no row click at all). Result: off = view modal/page, on = edit page, non-editable = view, no view action = edit page (never a dead row). The first version of this preference switched row clicks OFF entirely (`recordAction(null)->recordUrl(null)`) — wrong, the choice is the DESTINATION (modal vs edit page), never "nothing"; BMS-CM's inverted default (rows inert until switched on, kept in the session) was also deliberately NOT copied. (2) The global `Table::configureUsing()` hook in `FilamentServiceProvider::registerTableDefaults()` sets `persistFiltersInSession`, `persistSearchInSession` and `persistSortInSession` from `persist_table_state` (Filament here has no single `persistInSession`), so filters/search/sort survive navigation within the session. Tests: `FilamentPreferencesTest` (defaults + save), `LinkResourceTest` (row-click and persistence reach the real table).
- **Top-bar order (2026-11-02, after BMS-CM):** everything settings-like now lives in ONE group, the utilities row (`filament/resources/dashboard/utilities.blade.php`, `GLOBAL_SEARCH_START`): share, print, fullscreen, density, quick-create, recents, then — split across `actions-start.blade.php` (quick-create, recents) and `actions-end.blade.php` (a notifications bell and the palette). The bell is a plain button that dispatches `open-modal {id: 'database-notifications'}` (the modal still belongs to Filament's own `UnreadNotifications` component, same trick as the user panel's `navbars/top/notification.blade.php`), with a red dot from `unreadNotifications()->exists()` kept live by the `bell-unread` window event; Filament's own bell trigger is hidden by `.fi-topbar-end .fi-topbar-database-notifications-btn { display:none }`. The palette moved out of the old `GLOBAL_SEARCH_AFTER` hook (removed) into the row as a teleported fixed popover (the row is `overflow-y-hidden`). Result in the DOM (RTL, right to left): logo, utilities group, wide search box, user menu — search sits beside the account. On desktop (`md+`) the group is `w-max max-w-none min-w-0` so it grows with its content and only scrolls when the viewport is too narrow; below `md` it stays a 172px swipeable strip (four buttons visible; arbitrary Tailwind widths only apply after `npm run build`).
- **Top-bar work buttons (2026-11-02, ported from BMS-CM, all in `filament/resources/dashboard/utilities.blade.php`'s scroll row):** (1) **Table density toggle** — `resources/js/core/table-density.js` (`Alpine.store('tableDensityCompact')`, `window.setTableDensity()`, `localStorage table_density`, `html.table-density-compact`, re-applied on `livewire:navigated`, pre-paint class set by the HEAD_START bootstrap) + compact-row CSS in `filament.css`; (2) **Quick-create** and (3) **Recent records** — `filament/resources/dashboard/actions-start.blade.php` (included by `utilities.blade.php`, so Tailwind scans it; the bell and palette live in `actions-end.blade.php`): popovers are `x-teleport="body"` + `fixed` (the row is `overflow-y-hidden`, so an absolute menu would be clipped); quick-create lists `Filament::getResources()` that `hasPage('create')`, `shouldRegisterNavigation()`, `canCreate()` AND `canViewAny()`, grouped by navigation group, cached per user for 5 min via `ModelCacheVersion::remember(Permission::class, …)` (a permission save bumps it); recents are captured by `resources/js/core/recents.js` from `/{panel-path}/{slug}/{id}[/edit]` pages of resources in `window.__adminRecents.map` (slug → label/group, cached 1 h), title = the page `.fi-header-heading`, stored in `localStorage recent_records_admin` (max 20, deduped by url, every entry re-validated against the panel path on read) and announced with `recents-updated`; links use `wire:navigate`. Tests: `table-density.test.js`, `recents.test.js`, `LinkResourceTest` (menu gating + config).
- **Filter/column-manager panels close on Apply (2026-11-02, ported from BMS-CM):** `resources/js/core/auto-close.js` (registered in `FilamentServiceProvider::registerCoreScripts()` and `vite.config.mjs`) hooks Livewire's `commit` and, after a commit that called `applyTableFilters` or `applyTableColumnManager`, calls `close()` on every `[x-data="filamentDropdown"]` — the popover no longer needs a click elsewhere. Tests: `resources/js/core/__tests__/auto-close.test.js`.
- `nav_dock` (default **off**) and `topbar_pinned` (default **on**) — pure CSS/JS layout toggles with no Filament Panel equivalent at all. Applied via a class added to `<html>` at `PanelsRenderHook::HEAD_START` in `FilamentServiceProvider::registerThemeBootstrap()` (`nav-dock-bottom`, `topbar-pinned`), styled in `resources/css/core/filament.css` under `@media (min-width: 1024px)` blocks (desktop-only):
  - `nav_dock` CSS-repositions Filament's *existing* `.fi-sidebar` into a floating bottom dock (fixed, centered, row-flex, labels/header/footer hidden) rather than building a separate component — ported from the sibling `BMS-CM` project's `fi-custom.css`. Because Fateh's own `.fi-sidebar-item > a` carries vertical-sidebar sizing (`w-[70%]`, `px-4 py-3`), the dock block must also reset `width: auto` + a smaller `padding` on that selector, or icons render lost inside oversized, still-padded buttons — a gap BMS-CM's own CSS never needed since it doesn't have Fateh's custom item sizing.
  - Dock items get hoverable titles the same way BMS-CM's does: Filament's own sidebar-item Blade (`vendor/filament/filament/resources/views/components/sidebar/item.blade.php`) already ships an `x-tooltip` binding driven by `$store.sidebar.isOpen`, but only renders it when `isSidebarCollapsibleOnDesktop()` is true — so `FilamentPanelCustomizer::apply()` sets `->sidebarCollapsibleOnDesktop(fn() => self::pref('sidebar_collapsible', false) || self::pref('nav_dock', false))`, making dock mode always collapsible-on-desktop regardless of the (mutually-exclusive, disabled-in-UI) `sidebar_collapsible` toggle's own saved value. `resources/js/core/nav-dock.js` then closes `Alpine.store('sidebar')` whenever `.nav-dock-bottom` is present (activating Filament's built-in tooltip) and overrides the resulting tippy instances' `placement` to `'top'` on `.fi-sidebar-item-btn`/`.fi-sidebar-group-dropdown-trigger-btn` (Filament's own effect always computes `right`/`left`, which is wrong once the sidebar is a horizontal strip pinned to the bottom edge). It binds on `alpine:initialized` (not `alpine:init`) because Filament registers `Alpine.store('sidebar')` inside its own `alpine:init` listener — reading the store from a sibling `alpine:init` listener race-depends on script-tag order, `alpine:initialized` fires only once every listener, including Filament's, has already run. Deliberately does **not** call `.open()` when dock is off, unlike BMS-CM's version — an unconditional `open()` would fight a real `sidebar_collapsible` user's own persisted collapse state on every non-dock page load, which BMS-CM never has to worry about since it hardcodes `sidebarCollapsibleOnDesktop()` unconditionally true instead of gating it by preference. **Known residual edge case:** `Alpine.store('sidebar').isOpen` is `Alpine.$persist`-backed (localStorage), so a user who has both `nav_dock` and `sidebar_collapsible` enabled at once can find the classic sidebar still collapsed for one page load after switching dock off (dock's `.close()` set `isOpen=false`; nothing restores it since we never call `.open()`) — self-corrects on the next manual toggle, not worth code for.
  - `topbar_pinned` off makes `.fi-topbar-ctn` a fixed, mostly-offscreen strip that slides fully into view on `:hover`/`:focus-within` (pure CSS transform + transition, no JS for the show/hide itself). One JS file, `resources/js/core/topbar-autohide.js` (registered as both a Vite `input` entry in `vite.config.mjs` and a `SCRIPTS_BEFORE` render hook in `registerCoreScripts()`), briefly adds `topbar-force-hidden` after `livewire:navigated` so the topbar doesn't flash open during an SPA page transition. That handler must bail out early when `.topbar-pinned` is present — the `html.topbar-force-hidden .fi-topbar-ctn` CSS rule isn't scoped to `:not(.topbar-pinned)` (matching BMS-CM's own unscoped rule, which is only safe there because its JS carries the same guard), so unconditionally adding `topbar-force-hidden` on every SPA nav made the *pinned* (always-visible) topbar visibly slide up and back down on every page transition even though auto-hide was off — the reported "glitchy, needs toggling a few times" symptom. **Label trap (fixed 2026-09-11):** the toggle's own label used to read "اتو هاید نوار بالا" (auto-hide the topbar) while `true`/on is actually the *pinned* (always-visible, auto-hide OFF) state — turning the toggle "on" did the opposite of what its label promised. Relabeled to "ثابت نگه‌داشتن نوار بالا" (keep the topbar pinned) with distinct on/off icons; the underlying field name, default (`true`), and stored semantics are unchanged, only the label/icon now match reality.
  - Because `nav_dock` replaces the sidebar and `top_nav` moves the sidebar's contents to the top, the two are mutually exclusive **in both directions**: `nav_dock` carries `->disabled(fn (Get $get) => (bool) $get('top_nav'))` and `top_nav` carries `->disabled(fn (Get $get) => (bool) $get('nav_dock'))` (fixed 2026-09-11 — previously only the `nav_dock`→`top_nav` direction was guarded, so a user could turn `top_nav` on first and then also turn `nav_dock` on, leaving both true with `nav_dock`'s CSS silently targeting a `.fi-sidebar` that top-navigation mode no longer renders). `sidebar_collapsible` also carries `->disabled(fn (Get $get) => (bool) $get('nav_dock'))`. `sidebar_fully_collapsible` is disabled by **either** `nav_dock` **or** `sidebar_collapsible` (`->disabled(fn (Get $get) => (bool) $get('nav_dock') || (bool) $get('sidebar_collapsible'))`, fixed 2026-09-11) — Filament's own `components/layout/index.blade.php` uses an `@if($isSidebarCollapsibleOnDesktop) … @elseif($isSidebarFullyCollapsibleOnDesktop) …` chain, so when both are on, `sidebar_collapsible` silently wins and `sidebar_fully_collapsible` has zero visible effect; leaving it enabled let a user toggle a setting that visibly did nothing. Likewise `topbar_pinned` and `user_menu_topbar` only make sense when the topbar is actually shown: both carry `->disabled(fn (Get $get) => !$get('topbar'))` (the `user_menu_topbar` guard added 2026-09-11 — without it, a user could force `UserMenuPosition::Topbar` into a panel with no topbar at all, per `FilamentPanelCustomizer::apply()` below, stranding themselves with no visible profile/logout menu anywhere; `FilamentPanelCustomizer::apply()` also carries a defense-in-depth fallback — `(self::pref('user_menu_topbar', false) && self::pref('topbar', true)) ? UserMenuPosition::Topbar : UserMenuPosition::Sidebar` — so even a pre-existing stale/conflicting stored combo self-corrects at render time, not just in the form UI). Every toggle a `disabled()` closure reads (`nav_dock`, `top_nav`, `sidebar_collapsible`, `topbar`) must itself be `->reactive()` for the dependent field's `disabled()` state to update live while the Preferences form is open, without a page reload.
  - **Persistence trap (fixed 2026-09-11):** `FilamentPreferences::save()` used to do `$extra['preferences'] = $this->form->getState();` — a full overwrite. Filament's `->disabled()` also makes a field non-dehydrated (it is silently absent from `getState()`, not merely read-only), so saving the form *while* a dependent toggle was disabled (e.g. `topbar_pinned` while `topbar` was off) silently deleted that toggle's stored value — it would revert to its field default the next time its parent toggle was switched back, with no edit to that toggle itself. `save()` now merges instead of overwriting: `$extra['preferences'] = array_merge($extra['preferences'] ?? [], $this->form->getState())` — an actively-toggled field (even set to `false`) always appears in `getState()` and correctly overrides the merge, so only genuinely-disabled/hidden fields fall back to their previously-stored value instead of vanishing.

### `extra` two-bucket protection (User model)

`users.extra` is a JSON bag holding **two distinct top-level buckets**, enforced at the model level by a custom `extra()` Attribute (no `array` cast — mirrors the `booking()` / Feed `content()` set-mutator pattern):

- `extra['preferences']` — purely admin-panel **app** settings (the toggles above, written by `ManagePreferences` and `setExtraValue('preferences.x', …)`). This bucket is never wiped or polluted by any write.
- `extra['admin']` — a distinct bucket for **flat key/value pairs an admin adds via the User edit form's `KeyValue` field**. Its single-word key records the origin (admin panel). Loose flat keys never sit at the top of `extra` and never enter `preferences`.

The setter discriminates by intent: a write that carries an **array** `preferences` key is "preferences-aware" (deep-merge `preferences`, preserve/replace `admin`, route any stray top-level keys into `admin`); a write **without** an array `preferences` is a KeyValue save (replace `admin` wholesale so add/delete/clear work, preserve `preferences`). The reserved names `preferences` and `admin` are dropped from KeyValue input, so an admin cannot pollute `preferences` by typing one of those names as a key.

Because the form's `KeyValue` only edits the `admin` bucket, the flattening lives in ONE place, `User::adminBucketOf()` / `User::editableExtraOf()` (the `admin` bucket minus `User::PROTECTED_ADMIN_KEYS`; legacy rows that pre-date the split have their loose top-level scalar keys gathered into it so they survive the next save rather than being dropped). Both `EditUser::mutateFormDataBeforeFill` and the `extra()` field's `afterStateHydrated` call the model methods, so the Departments > Users relation manager (which has no `mutateFormDataBeforeFill`) hydrates the same flat state instead of the nested `{preferences, admin}` shape that its `KeyValue` cannot hold. **Gotcha (2026-11-10): inside an `afterStateHydrated` closure, the injected `$state` is the StateCast-`get()` output, not the raw record attribute — on the nested `{preferences, admin}` fill, `KeyValueStateCast` plucks `key`/`value` rows and yields `[]` before the hook runs. Read the record instead: `function (KeyValue $component, ?User $record) { $component->state(User::editableExtraOf($record?->extra)); }` (typed `$record` injection works — same precedent as the booking `Repeater`).** `UserInfolistPresenter::extra()` displays `$record->editableExtra()` only — never the nested `preferences`. `PROTECTED_ADMIN_KEYS` (signature, sign_code_hash, correspondence_registry) are never shown, posted or wiped through this field: the dehydrate step drops them from the posted state and re-attaches the stored values.

`users.focus_until` (nullable timestamp, user-panel Focus Mode — see `app/Livewire/Dashboard/Profile/profilePattern.md`) is a real, separate column, deliberately never routed through `extra` — any value written there outside the `preferences`/`admin` buckets above would be silently dropped or folded into `admin` and wiped by the next KeyValue save. `UserTablePresenter`/`UserInfolistPresenter`'s `presence()` render a read-only clock badge when it's set and in the future; there is no form field for it — it can only be set/cleared from the user panel.

### Other panel config

```php
->databaseTransactions()                        // all writes wrapped in transactions
->databaseNotifications()
->databaseNotificationsPolling('60s')
->darkMode(false)                               // suppresses Filament's own switcher; the app's custom ThemeManager/mode-manager.js already toggles `.dark` on <html> independently, so dark-mode-reactive CSS (e.g. darkModeBrandLogo) still works
->maxContentWidth(Width::Full)
->subNavigationPosition(SubNavigationPosition::End)
->viteTheme('resources/css/core/filament.css')
->navigationGroups([...])                       // 4 groups registered, all via i18n keys
->authMiddleware([Authenticate::class, EnsureHasPermission::class])
->userMenuItems(FilamentMenuService::getActions())
```

`EnsureHasPermission` is a **custom middleware** that runs after `Authenticate` and enforces module-level access before any resource is served.

`FilamentMenuService::getActions()` builds the user menu action list from a centralized service class — no menu items are defined inline in the provider.

---

## Helper functions used in Filament

Global helpers are autoloaded from `app/Helpers/index.php`; the `divider()` UI helper lives on the `App\Traits\Filament\FilamentFormDivider` trait (`app/Traits/Filament/FilamentFormDivider.php`), consumed by presenter classes. The most relevant ones in Filament context:

### `FilamentFormDivider::divider()`

This is used in a presenter class and returns a `TextEntry` that renders as a full-width gradient divider line inside infolists:

```php
function divider(): TextEntry
{
    return TextEntry::make('divider')
        ->hiddenLabel()
        ->columnSpanFull()
        ->state(new HtmlString(
            '<div class="w-2/3 h-px bg-gradient-to-r from-transparent via-gray-300 dark:via-gray-700 to-transparent opacity-80 mx-auto"></div>'
        ));
}
```

Use it between logical sections in an infolist to add visual separation without wrapping in another `Section`.

### `toJalali($date, $format = 'Y/m/d H:i')`

Converts a Gregorian date to Jalali. Detects already-Jalali years (1300–1500 range) and returns as-is to avoid double conversion.

### `toJalaliSmart($date)`

Same as `toJalali` but omits the time portion when it is `00:00` — avoids showing meaningless midnight times on date-only fields.

### Admin date-display standard — `HasJalaliAdminLabels` trait

The admin-panel uniform date format is `toJalaliSmart` (`Y/m/d H:i`, auto-drops time when `00:00`). Apply the `App\Models\Concerns\HasJalaliAdminLabels` trait to the model and call its labels from Filament presenters instead of raw `toJalali($state, '<format>')`:

- `createdLabel()` / `updatedLabel()` / `deletedLabel()` — wrap `created_at` / `updated_at` / `deleted_at`.
- `adminDateLabel(string $column, ?string $fallback = '—')` — any other genuine datetime column where a non-midnight time is meaningful.
- In a presenter: `->formatStateUsing(fn($state, $record) => $record->createdLabel())`.

Do NOT mutate existing date accessors/getters (e.g. `created_formatted`) — they may be used by the user panel or other code; add the trait label alongside and call it from admin presenters (backward compatible). Apply the trait + presenter swap only to models whose display accessor uses a non-smart format (e.g. Task `j F Y`); models already on `toJalaliSmart` or settled `toJalaliRelative` (presence/last-seen) need no change. Keep `toJalaliRelative` for presence/last-seen columns — intentional, not part of this absolute-date rule. A column with a fixed non-midnight default (e.g. Task `deadline`, always noon) must use plain `toJalali($date, 'Y/m/d')` instead — the smart formatter only hides time when it's exactly midnight, so it would surface that default time as if it were meaningful.

### `convertToPersian(?string $string)`

Replaces ASCII digits 0–9 with their Persian equivalents ۰–۹. Used on any displayed number that should appear fully Persian (dates, counts, etc.).

### `superClean(?string $text, int $limit = 100, bool $nl2br = false)`

Strips HTML tags, html-decodes entities, trims, and truncates to `$limit` characters. Used for safe short previews in table columns.

### `stripHtml(?string $text): string`

Strips HTML tags, html-decodes entities (incl. `&nbsp;` → space), normalizes U+00A0/U+200B/U+FEFF to spaces, collapses whitespace, trims. No truncation. Use for full-length title surfaces — `getRecordTitle()` / `getGlobalSearchResultTitle()` — instead of bare `strip_tags()`, which leaves `&nbsp;` and other entities as literal text. Both `stripHtml` and `superClean` preserve emoji (incl. ZWJ sequences — U+200D is not in the normalize list); none of strip_tags / html_entity_decode / `\s` / the U+00A0 replace touch emoji bytes.

### Infolist `TextEntry` for multiline free-text → `white-space: pre-wrap`

Any Infolist `TextEntry` that displays a **full** free-text column (description, notes, body, comments, actions, response, about-me, accessibility, address, interests, revision, etc. — anything a user/admin types with possible newlines/paragraphs) MUST carry `->extraAttributes(['style' => 'white-space: pre-wrap;'])`. Filament's `TextEntry` renders the value with default `white-space: normal`, so `\n` collapses to a space and a multi-paragraph value shows as one run-on line — the admin sees a flattened blob of what the user typed with real line breaks. If the entry already has `->extraAttributes(['style' => '…'])` (e.g. `EventInfolistPresenter::description()` had `margin-bottom:15px`), MERGE `white-space: pre-wrap;` into the SAME style string (`'white-space: pre-wrap; margin-bottom:15px'`) — never add a second `->extraAttributes()` call, the second silently overwrites the first. For a RichEditor-HTML column shown as prose, keep `->prose()` AND add the pre-wrap `extraAttributes` (prose alone doesn't pre-wrap plain-text-authored rows of a dual-authored column — `SuggestionInfolistPresenter::description()` is dual-authored: admin RichEditor OR user plain textarea, so it needs both). For a plain-text column that needs `<br>` rather than CSS pre-wrap, the reference pattern is `ReleaseRequestInfolistPresenter::body()`: `->html()->formatStateUsing(fn(?string $state) => $state === null ? '' : nl2br(e($state)))` (escape + nl2br, XSS-safe). Table `TextColumn` list views truncate (`->limit()`) so pre-wrap is unnecessary there — the rule is for the Infolist VIEW page only. Audit (2026-08-27) added pre-wrap to: Task (description, actionSource, actionSourceDomain, activity reply body), Profile (about_me value, detail display_value, accessibility, address, interests), Resource notes, Event description (merged), Gallery description, Skill description, Department description, Credential note, Link (url_description, image_description), Suggestion (comments, description, referralActions), ReviewsRelationManager (comments, actions), ReleaseRequest response, Dms revision, Contact body, Channel description, Ad (certificate/experience/skill), Ths (actionResult, additionalNotes, description). User-panel mirror of the same rule (blade `whitespace-pre-wrap` + `renderComment()`) is in `livewirePattern.md` "Rendering text/HTML in Blade".

### `shortGreeting(?string $name)`

Returns a time-aware Persian greeting suitable for the dashboard header (delegates to `GreetingService`).

### Other helpers available

| Helper | Purpose |
|---|---|
| `jdate($date)` | `Jalalian::fromCarbon(Carbon::parse($date))` |
| `jdateOnly($date)` | Jalali date as `d/m/Y` string |
| `isPast(string $time)` | `Carbon::parse($time)->isPast()` |
| `presence(mixed $p)` | Cast to `PresenceStatus` enum (unknown value falls back to `PresenceStatus::default()` — Onsite) |
| `presenceCases()` | All `PresenceStatus` cases |
| `greeting($name)` | Full greeting string |
| `formatJalaliDate($date, $format, $fromFormat)` | Formatted Jalali with try/catch |
| `isVideo($path)` | Checks for mp4/webm/ogg extension |
| `getFileExtension($path)` | `strtolower(pathinfo(..., PATHINFO_EXTENSION))` |

---

## Active / audience visibility — `FilamentVisibility` (2026-10-16)

`FeedResource`, `PostResource`, `GalleryResource` and `ReportResource` share `App\Traits\Filament\FilamentVisibility` (admin half of the `HasActive`/`HasAudience` model concerns — `app/Traits/traitPattern.md`). Wire it by `use`-ing the trait in the Resource, its `List*` page and its `*Exporter`, then call the static builders:

- **Form / infolist / table:** `self::activeToggle()` (default on), `activeEntry()`, `activeColumn()` (`ToggleColumn`, `disabled` unless `static::canEditAny()`), `activeGroup()`, `activeFilter()`; Feed/Post additionally `departmentsSelect()` (empty = public), `audienceEntry()`, `audienceColumn()` (hidden by default; reads the cached `audience_departments` accessor, no per-row query), `audienceFilter()`, `visibilityFilter()` (public/restricted). Gallery keeps its own department fields (only the `active*` builders are shared); Report predates the trait and shares only `activeColumn()` and the bulk actions — its own toggle, tabs, filters and `departments` form stay. The Feed/Post/Gallery exporters add `activeExportColumn()` (+ `audienceExportColumn()` on Feed/Post); `ReportExporter` is untouched.
- **List page tabs:** spread `...self::activeTabs(fn() => $this->getStats())` into `getTabs()`; the page's single stats query must also select `active_count` / `inactive_count` (`SUM(CASE WHEN active = 1 …)`), otherwise the badges silently read null.
- **Bulk Activate / Deactivate:** `...self::bulkVisibilityActions()` next to `self::bulkActions(Exporter::class)` in `groupedBulkActions([...])`. Both are `visible(canEditAny())`, confirm, and run `$records->each->update(['active' => $active])` — per model, never a query-level `update()`, so `saved` fires the model-cache bump and the nudge triggers. Do NOT turn it into a bulk `UPDATE`. Since 2026-11-25 the loop runs inside `DB::transaction` and a model `ValidationException` (a save hook refusing, e.g. Media activating a fileless item) rolls the whole batch back and shows its first message as a danger notification, so a bulk activate is all-or-nothing. A resource whose model can refuse activation also validates the row toggle with `->rules()` on its `activeColumn()` (`MediaResource::mediaActiveColumn()`), because `updateTableColumnState` returns a rule failure to the cell as a clean error while a model exception would surface as a page error; the name avoids the trait's own `activeToggle()` form-field builder.
- **Delete stays.** Deactivation is the non-destructive alternative, not a replacement; row and bulk delete actions are unchanged.
- **Scope of effect:** `active = false` hides the record from the user panel only. Admin tables, infolists and global search never filter on it, and the Resource must not add a `forViewer()`/`active()` scope to its Eloquent query.

## Hidden relation-tab clue — `ExplainsHiddenRelationTabs` (2026-10-16)

Edit/View record pages show a Filament `Callout` (info, lock icon) at the top of the content naming each relation-manager tab hidden **by the admin's permissions** and the module that unlocks it (`«تیکت‌ها» (ماژول ths)`), plus a pointer to the Permission guide tab «قوانین دسترسی در عمل» (the guide is a modal, so it is named, not deep-linked). Nothing renders when no tab is permission-hidden.

- **Mechanism:** `App\Filament\Traits\ExplainsHiddenRelationTabs` is used by the shared `App\Filament\Pages\EditRecord` and `ViewRecord`; it overrides `content()` to prepend the callout. It walks `getAllRelationManagers()` (flattens `RelationGroup`, unwraps `RelationManagerConfiguration`) and asks each manager `RelationManager::deniedByPermission($record)` (shared base: the related model's resource exists and `canAccess()` is false -> its `moduleKey()`; never `permission`, which can't be granted). Copy lives in `resources/general/strings.hidden_tabs.*`.
- **Adding a page:** extend `App\Filament\Pages\EditRecord`/`ViewRecord` and give every relation manager the shared base `App\Filament\RelationManagers\RelationManager` — nothing else. A manager that is also hidden for a non-permission reason (e.g. `SkillsRelationManager`/`EventSharesRelationManager`: no rows) overrides `deniedByPermission()` to return `null` for that case so the clue never lies.
- **Cost:** one `canAccess()` per manager (cached `Permission::forUser`), no queries except the two row-existence overrides, and only when permission already denies.

## Additional design rules

_(Extending the 20 rules listed above)_

**21. Every `Section` has an icon** — `->icon('heroicon-o-...')` is always set. Description is optional but used when the section's purpose needs context.

**22. Asymmetric grid layouts are intentional** — `Grid::make(['default' => 1, 'lg' => 4])` is used for sidebar-like form layouts where one column is a narrow control panel and the others are content. Not every form uses uniform `->columns(2)`.

**23. Export columns use `formatStateUsing` for enum humanization** — raw enum string values are never written to the export file. Each enum column converts via `tryFrom($state)?->getLabel() ?? $state`.

**24. `getCompletedNotificationBody` is always Farsi** — the export completion notification body is localized. Pattern: `"خروجی {$count} {$itemLabel} با موفقیت آماده شد."`.

**25. Heavy widget analytics must cache — but `#[Computed(cache: true)]` only caches magic-get properties, not direct calls.** `#[Computed(seconds: 300, cache: true)]` engages ONLY through magic-property access (`$this->usersData` → `BaseComputed::handleMagicGet` → `Cache::remember` under `lw_computed.{component}.{prop}`); a method called directly as `$this->getModuleAData($dept)` bypasses that path entirely, so the attribute is dead decoration and the body re-runs on every render. Two correct shapes: (a) the `ModuleAnalyticsWidget` pattern — no-arg `{domain}Data()` methods consumed as bare `$this->usersData` properties, where `#[Computed(seconds: 300, cache: true)]` genuinely caches; (b) the `StructuralChart` / `OperationalChart` / `HrAnalyticsService` pattern — `ModelCacheVersion::rememberGlobal("{$ns}:{$key}", fn () => […])` with the argument baked into the key (300s, config-driven via `app.cache_ttl`). Never put `#[Computed(cache: true)]` on a method called directly with an argument — see `app/Models/modelPattern.md` (V/T/L tiers) and the local guard test.

**26. `$isLazy = true` on analytics widgets** — all analytics and chart widgets defer their load so the initial dashboard render is fast and widgets load independently after page paint.

**27. Responsive `columnSpan` on chart widgets** — chart widgets always declare `['sm' => 'full', 'md' => 1]` so they stack on mobile and sit side-by-side on desktop.

**28. `canViewAny()` hard override for super-admin-only resources** — when a resource must be strictly invisible to non-super-admins (e.g., PermissionResource), override `canViewAny()` (developer or super-admin row) **and** `permits()` (`canViewAny() && trait permits`) so in-table actions follow too — see §5.

**29. Navigation badges return `null` not `'0'`** — `getNavigationBadge()` must cast the count to null when zero: `return (string) $count ?: null;`. An empty badge clutters the sidebar.

**30. `FilamentMenuService` owns the user menu** — no menu items are ever defined inline in `AdminPanelProvider`. The service class is the single source of truth for all user menu actions.

**31. Embed a `HasOne` companion table via `->relationship()`, never a new resource/relation manager** — when a model has a 1:1 companion table that's purely supplementary (e.g. `Task` → `TaskDetail`, mirroring the existing `User` → `Profile`/`ProfileDetail` pattern), do **not** create a separate Resource or RelationManager for it. Instead, add a new `Tab` to the parent resource's existing `Tabs::make()` and bind a `Section` directly to the relation:

```php
Tab::make('اطلاعات تکمیلی (BI)')
    ->icon('heroicon-o-chart-bar-square')
    ->schema([
        Section::make('طبقه‌بندی و گزارش‌گیری')
            ->icon('heroicon-o-chart-bar-square')
            ->relationship('detail')   // HasOne on the parent model
            ->schema([
                TaskFormPresenter::departmentId(),
                TaskFormPresenter::unit(),
                // ...
            ])
            ->columns(2),
    ]),
```

`->relationship($name)` on `Section`/`Group`/`Fieldset` (confirmed in `vendor/filament/schemas/src/Components/Concerns/EntanglesStateWithSingularRelationship.php`) works for `HasOne`, `BelongsTo`, and `MorphOne` and auto-creates/fills/saves the related row with zero custom page hooks — every parent record gets its companion row the moment it's created, even if every field in the tab is left blank. New fields on the companion model are added as more methods on the **same** `*FormPresenter`/`*InfolistPresenter` classes (no new Schemas classes), and `getEloquentQuery()` just needs the relation added to `->with([...])`. The same applies to the matching `infolist()` — use a second `Tab` there too, with a plain (non-bound) `Section` of `TextEntry`s pointed at the dot-path (`detail.department.name`, `detail.unit`, etc.).

Field-level convention for the companion table itself: when an FK-like column stores another model's natural key (not its surrogate `id`) — e.g. `task_details.department_id` storing `departments.code` — name the column `*_id` anyway for uniformity with the rest of the codebase, and declare the relation with an explicit owner key: `belongsTo(Department::class, 'department_id', 'code')`.

> **Eloquent gotcha:** never declare a column in both `casts()` (e.g. `'units' => 'array'`) **and** an `Attribute::make()` accessor/mutator for that same key. `HasAttributes::setAttribute()` checks for an attribute-mutator first and short-circuits — it never reaches the cast's JSON-encode step, so a `set` callback returning a plain array gets merged into `$this->attributes` using the array's own keys as column names (`Unknown column '0'`). If you need custom set/get logic (e.g. dedupe-on-write) for a JSON column, drop it from `casts()` and do the `json_encode`/`json_decode` by hand inside the `Attribute::make(get: ..., set: ...)` pair instead — don't combine the two mechanisms for the same key.

**32. Date/time display must read from the model's own accessor, never re-derive the format inline in a Schema** — when a model already exposes a formatted-date accessor consumed by the Livewire side (e.g. `Task::createdFormatted`/`Task::deadlineFormatted`, appended via `$appends`), the matching Filament `TextColumn`/`TextEntry` must call that **same** accessor (`fn($state, $record) => $record->created_formatted`) instead of independently calling `toJalali($state, '...')` with its own format string. Two independently-typed format strings for the same conceptual field is exactly how the admin table (`Y/m/d`) and the Livewire Kanban card (`j F Y`) silently drifted apart for `created_at`/`deadline` on `TaskResource` — found during a full cross-panel consistency audit, fixed by pointing both `TaskTablePresenter`/`TaskInfolistPresenter` at the model accessor. The underlying column still binds to the real DB field (`TextColumn::make('created_at')`) so `->sortable()` keeps working — only the **display closure** changes. For date fields that have no Livewire-facing equivalent and thus no model accessor (e.g. `deleted_at`, `updated_at`), there's nothing to bind to — at minimum reuse the exact same `toJalali(...)` format string already used elsewhere in the same resource's other date columns, so the resource is internally consistent even without a cross-panel counterpart to check against.

**33. Department labels go through the `HasDepartmentLabel` trait — never read `name`/`description`/`code` directly as a display label.** The `Department` model carries the `App\Models\Concerns\HasDepartmentLabel` trait as the single source of truth for department labeling: `displayLabel()` = `description ?: name ?: code` (Farsi-first primary label, empty-string-safe `?:` not `??`), `tooltipLabel()` = `name ?: code ?: description` (English-first vice-versa tooltip). Everywhere a department is *referenced* — FK `TextColumn`/`TextEntry`, exporters, global-search titles, SQL chart axes, `Group` headings (`->getTitleFromRecordUsing(fn(?Model $record) => $record?->department?->displayLabel())`), filter buttons, Blade chips — the visible label is `displayLabel()` and the `->tooltip()` / `title=""` is `tooltipLabel()`. SQL projections use `COALESCE(NULLIF(description,''), name, code)` (add `description` to the matching `groupBy`). `Department::getCachedOptions()` / `getCachedOptionsExcludingEmptyTickets()` stay **keyed by `code`** with label = `displayLabel()` — the keys (codes) are what gets saved, so this is a purely cosmetic label change with **no save-logic/schema change**. The **exception** is `DepartmentResource` itself (table/infolist/form/exporter): as the master edit surface its own `name`/`description`/`code` columns show the **raw** field values so an admin toggling a column sees the actual data to fix — no `displayLabel`/`tooltipLabel` mixing there (global-search title stays `$record->description ?? $record->name`). The multi-department DMS layer uses the `HasDepartmentHelpers` trait (`getDepartmentDisplayLabels()` / `getDepartmentTooltipLabels()`, joined with ` ┆ `, `'ALL'` placeholder short-circuit). Code-columns storing department codes (e.g. `Review::referral`, `Suggestion::departments`) must `pluck('code')` for any `in_array` code-matching and map codes→`displayLabel()` for display — `pluck('description')` is a bug (codes never match descriptions). A standalone `code` badge next to a label is allowed for brevity; raw `description ?? name` used *as* the label is not.

**34. Kill per-row correlated subqueries under `wire:poll` with non-correlated `UNION ALL` derived tables + covering indexes — never `addSelect([subquery])` against the outer row.** `FetchContactsAction` was `User::active()->addSelect(['last_message_id' => MAX(id) subquery, 'unread_count' => COUNT(*) subquery])` with each subquery `whereColumn`'ing `users.id` → MySQL `DEPENDENT SUBQUERY`, re-running per outer row; under `wire:poll.10s` that's `O(N·k)` per viewer per poll (5K users / 500K msgs: 1103 ms → 8.8 ms, ≈125×). Fix: pre-aggregate into non-correlated derived tables and `leftJoinSub` once — `$sent = MAX(id) GROUP BY recipient_id WHERE sender_id=viewer`, `$received = MAX(id) GROUP BY sender_id WHERE recipient_id=viewer`, `$lastMsgSub = fromSub($sent->unionAll($received))->selectRaw('contact_id, MAX(max_id)')->groupBy('contact_id')`, `$unreadSub = COUNT(id) GROUP BY sender_id WHERE recipient_id=viewer AND read_at IS NULL`; `User::active()->select('users.*','lm.last_message_id', DB::raw('COALESCE(uc.unread_count,0) as unread_count'))->leftJoinSub($lastMsgSub,'lm',...)->leftJoinSub($unreadSub,'uc',...)`. `HAVING unread_count > 0` → `WHERE uc.unread_count > 0`; no-message users keep `null`/`0` via `leftJoinSub` + `COALESCE`. **`OR`-defeats-index:** old `WHERE (sender_id=V AND recipient_id=u.id) OR (sender_id=u.id AND recipient_id=V)` made the optimizer ignore both directional composites → `idx_deleted_at` + `filesort`; same OR in the 1-on-1 thread view (`->latest()->take()`, `ORDER BY created_at`) defeats the composite there — so `idx_sender_recipient_created`/`idx_recipient_sender_created` were load-bearing for no query (EXPLAIN-verified) and dropped. **Covering replacements:** `idx_sent_covering(sender_id, deleted_at, recipient_id, id)` + `idx_received_covering(recipient_id, deleted_at, read_at, sender_id, id)` — `deleted_at` mid-prefix (after equality prefix) for in-index `whereNull('deleted_at')` prune, explicit `id` (InnoDB PK) so `MAX(id)`/`COUNT(id)` resolve `Using index` with no row lookup; `(recipient_id, deleted_at, read_at, sender_id, id)` covers both received-MAX and unread-COUNT legs. Drop `idx_recipient_read_at` (strict subset). **FK migration ordering:** if an index backs `messages_sender_id_foreign`/`_recipient_id_foreign`, InnoDB refuses `DROP INDEX` — add covering indexes first (they lead with the FK col), drop old composites in a separate `Schema::table`. `DB::table()` bypasses `SoftDeletes`, so `whereNull('deleted_at')` is mandatory in every derived leg. Validate on isolated `perf_benchmark` DB (5K/500K): seed at scale and measure — `EXPLAIN ANALYZE` on MySQL 8/MariaDB, `EXPLAIN` + timed runs on 5.7 — never trust theory for index choices. Migration: `database/migrations/migrated/2026_09_19_000026_create_messages_table.php` (covering indexes live in this create-table migration; no separate optimize migration).

**35. Presenter `->tooltip()` / `formatStateUsing()` closures read a model accessor or eager relation — never issue a per-row query inside a Schema closure.** A `->tooltip(fn($record) => SomeModel::where(...)->...)` (or any query inside `formatStateUsing`) is an N+1. Move data-shaping into a **model accessor** consuming a relation already eager-loaded in `getEloquentQuery()` (Rule 18); the closure only reads `$record->accessor`. Confirm the relation is eager-loaded with the columns the accessor reads and is **not** scope-constrained to a different row (a `hasMany` by the right FK, unconstrained, is the safe shape). Reference: `DMS::readerNamesTooltip` reads the eager `reads` collection (`DmsResource::getEloquentQuery()->with(['reads.user'])`), dedupes `user_id` → `User::getCachedAllOptions()` joined with ` ┆`, replacing the per-row `Read::getReaderNamesTooltipForDocument($record->id)` static query in `DmsTablePresenter::readCount()`. Same principle as Rule 32 (display reads the model accessor, not an inline re-derivation) and Rule 33 (labels via trait) — the Schema stays pure UI composition, the model stays the single source of truth.

**36. `use Closure;` is mandatory when a Presenter method declares `: Closure` (or a `Closure` parameter).** Inside a namespaced Filament Presenter class, an unimported `Closure` resolves to `<namespace>\Closure` (nonexistent) — PHP throws a TypeError at call time and the entire admin page 500s. Reference: `LinkFormPresenter` declared a `: Closure` return type without the import and took down the whole Link admin page; siblings `DmsFormPresenter`/`DetailsFormPresenter` already had it. Always add `use Closure;` at the top of any Presenter that references `Closure` in a signature.

**37. Cross-field closure validation rule — attach the SAME closure to both fields and branch on `$attribute`.** To enforce a dependency (e.g. extra IPs require `internal_url`), return `fn(Get $get) => function(string $attribute, mixed $value, Closure $fail) use($get){…}` from a private static helper and attach to **both** fields via `->rule(self::extraRequiresInternalUrl())`. Filament's `getValidationRules()` calls `$this->evaluate($rule)` (injects `Get`); the returned inner closure is the Laravel closure-rule called with `($attribute, $value, $fail)`. Branch on `$attribute` so the failure surfaces under the edited field; filter empty tags before the cross-field check. Reference: `LinkFormPresenter::extraRequiresInternalUrl()`. Distinct from the `ValidationRule` object pattern in §2.1 (`UniqueLiveDocument`/`uniqueLiveRule()`) — this is the closure-rule form for dependencies that don't warrant a dedicated Rule class.

**38. TagsInput `->dehydrateStateUsing` must strip empty/whitespace tags before save.** TagsInput's default dehydrate only TRIMS tags; it does NOT filter empty ones, so `['']` persists to the DB. When storing arrays (IPs, tags), add `->dehydrateStateUsing(fn($state) => is_array($state) ? array_values(array_filter(array_map('trim', $state), fn($v) => $v !== '')) : $state)`. The Link model's read-time `array_filter` in `resolvedIsInternal()` is defense-in-depth, but the form should not persist junk in the first place.

**39. A RelationManager (or Resource) calling `self::createdAtFilter()` (or any `FilamentFilters` helper) must `use App\Traits\Filament\FilamentFilters;` AND `use FilamentFilters;` — `FilamentActions` alone does NOT provide filters.** `createdAtFilter()` lives in `App\Traits\Filament\FilamentFilters` (one of the trait's two methods, alongside the shared `jalaliDateRangeFilter()`); module-specific filters like `typeFilter()` live on each resource's own `*TablePresenter`, not the trait. `viewAction`/`editAction`/`deleteAction`/`bulkActions` live in `App\Traits\Filament\FilamentActions`. A class importing only `FilamentActions` and calling `self::createdAtFilter()` fatalles `Call to undefined method ...::createdAtFilter()` on filter-row render. Mirror `ChannelResource`: `use App\Traits\Filament\FilamentActions; use App\Traits\Filament\FilamentFilters;` + `use FilamentActions, FilamentFilters, AuthorizesByPermission;`. Reference: `ChannelMessagesRelationManager` shipped with only `FilamentActions` and fatalled until `FilamentFilters` was added.

**40. Attachment JSON has ONE canonical shape project-wide — `{path, name, mime, size}` — built at write time, never `{file: path}`.** Every model with a JSON/array attachment column (`Message.attachments`, `ChannelMessage.attachments`, `TaskDetail.attachments`) stores each item as: `path` = stored relative path on the public disk (`$file->store(...)`/`storeAs(...)`), `name` = `$file->getClientOriginalName()` (display only), `mime` = `$file->getMimeType()` (server-side `finfo`), `size` = `$file->getSize()`. Build it in the write Action's `storeAttachments()` — mirror `SendMessageAction`/`SendChannelMessageAction` verbatim; `Task`'s `CreateTaskAction`/`UpdateTaskAction` do too. Never store a bare path under a `file` key (the `Task` inconsistency that broke cross-module parity). Display reads `name` (always via Blade `{{ }}` — `name` is client-controlled; never `{!! !!}`) and links to `path`; the model's `forceDeleting`/`forceDeleted` hook deletes by `path`. `name` is display metadata — never feed it into a storage path or `Content-Disposition`.

**The relationship-Repeater metadata trap:** when an attachments `Repeater` lives inside a `Section::relationship('detail')` (Rule 31), Filament saves the Repeater items straight into the related model's column, bypassing the page's `mutateFormDataBeforeCreate/Save` (those only see the parent record's fields). A bare `FileUpload::make('path')` stores `{path}` only and **truncates** `name`/`mime`/`size` on every admin save (the Repeater hydrates only declared schema fields from the model, so undeclared keys are dropped). The fix is to declare the metadata as `Hidden` siblings inside the Repeater and populate them from the real uploaded file inside `saveUploadedFileUsing` — NOT `afterStateUpdated`:

```php
Repeater::make('attachments')->schema([
    FileUpload::make('path')
        ->disk('public')->directory('task/attachments')
        ->saveUploadedFileUsing(function (TemporaryUploadedFile $file, callable $set) {
            $path = $file->storeAs('task/attachments', self::fileName($file), 'public');
            $set('name', $file->getClientOriginalName());
            $set('mime', $file->getMimeType());
            $set('size', $file->getSize());
            return $path;
        }),
    Hidden::make('name'),
    Hidden::make('mime'),
    Hidden::make('size'),
])->maxItems(5),
```

Why `saveUploadedFileUsing` and NOT `afterStateUpdated`: `BaseFileUpload::saveUploadedFiles()` (vendor) passes **existing stored-path strings through unchanged** and calls `callAfterStateUpdated()` **unconditionally on every save** — so an `afterStateUpdated` closure re-runs for untouched existing items too. Deriving `name = basename($path)` there would **overwrite** a user-panel `getClientOriginalName()` whenever an admin later edits the task without touching attachments (an admin↔user sync violation), and a `!filled($get('name'))` guard to prevent that then breaks the **replace-file-in-place** case (stale hydrated metadata for the new file). `saveUploadedFileUsing` fires **only** for genuine new `TemporaryUploadedFile` uploads (passthrough strings skip it), hands you the real file object — so `name` is the true original client name (matching the Livewire Actions exactly, no `basename` fallback), and `mime`/`size` come from the file with **no disk read and no `Storage::mimeType()` throw risk** — so admin and user panels now produce the identical shape AND identical `name` value. `$set('name', ...)` resolves the sibling within the same Repeater item (Filament injects the `Set` utility by parameter name via `Component::resolveDefaultClosureDependencyForEvaluationByName`). `Hidden extends Field` and does not call `dehydrated(false)`, so the siblings hydrate from the model on edit and dehydrate back on save — that's what stops the truncation. Reference: `TaskFormPresenter::attachments()` + `TaskInfolistPresenter::attachments()` (`TextEntry::make('path')`) + `detail-fields.blade.php` + `Task::forceDeleting`.

**41. Prune-state admin UI is ONE surface, rendered identically on every prune-capable resource — `prunableWarning()` column + `pruningSoonFilter()` filter + `prunableWarning()` infolist entry, all driven by the `HasPrunableStatus` trait.** Models using `Prunable` + `App\Models\Concerns\HasPrunableStatus` (currently `Message`/`Channel`/`ChannelMessage`/`Task`, `getPruneDays()=30`) get the same three-part UI. The trait is the single source: `pruneStatusText()` ("در آستانه حذف" / "تا حذف خودکار: {interval}" / "وضعیت ایمن تا: {interval}", or `null` when not soft-deleted) + `pruneStatusColor()` (`danger`/`warning`/`info`). Canonical column (`*TablePresenter::prunableWarning()`): `TextColumn::make('prune_status')->label(fields.prune_status)->getStateUsing(fn($r) => $r->pruneStatusText())->color(fn($r) => $r->pruneStatusColor())->badge()->placeholder('—')->toggleable(isToggledHiddenByDefault: true)`. Canonical filter (`*TablePresenter::pruningSoonFilter()`): `Filter::make('pruning_soon')->label(filters.pruning_soon)->query(fn(Builder $q) => $q->whereNotNull('deleted_at')->where('deleted_at', '<=', now()->subDays(30)))->toggle()` (off by default). Canonical infolist entry (`*InfolistPresenter::prunableWarning()`): `TextEntry::make('prune_info')->label(fields.prune_status)->getStateUsing(pruneStatusText)->color(pruneStatusColor)->badge()->hidden(fn($r) => !$r->deleted_at)`. Each resource owns its own in its **TablePresenter/InfolistPresenter** with its own `resources/<r>/strings` keys (`fields.prune_status`="وضعیت حذف خودکار", `filters.pruning_soon`="در آستانه حذف خودکار"); do **not** put a model-specific prune filter in `FilamentFilters` (stays generic: `createdAtFilter()` + `jalaliDateRangeFilter()`); a Presenter-less RM inlines the same definitions in `table()`. Reference: `ContactResource` (Message) original; `ChannelResource`, `TaskResource`, `ChannelMessagesRelationManager` mirror it.

**The RM soft-delete-scope gotcha:** a prune column/filter is meaningless on a query that hides soft-deleted rows — `deleted_at` is always `null` so the badge is always `—` and the filter returns zero rows. A Resource solves this at `getEloquentQuery()->withoutGlobalScopes([SoftDeletingScope::class])` (Contact/Channel/Task already do); a RelationManager that adds the prune surface must do the **same** in its own `getEloquentQuery()` — and once trashed rows are visible, pair it with `self::restoreAction()` plus `self::deleteAction()->visible(fn($r) => !$r->trashed())` for parity with the Resource (trashed rows restorable, delete only on live rows). When the RM's base query may carry a join/alias, prefix the filter column with the real table name (`channel_messages.deleted_at`) to match the RM's own `defaultSort('channel_messages.created_at')` convention and avoid ambiguity. Reference: `ChannelMessagesRelationManager` (query drops `SoftDeletingScope`, `deleted_at` + `prune_status` columns, `pruning_soon` filter, restore/delete gated). Verdict on the inline-vs-trait question for the RM filter: inline in `table()` is correct here — the RM already inlines all its columns and has no Presenter; extracting to `FilamentFilters` would diverge from the Presenter-based reference and pollute a model-agnostic trait.

**42. `$get('field')` on a Select bound to a backed enum returns the ENUM CASE, not the scalar value — never `(string)`-cast it.** A `Select` using `->options(SomeBackedEnum::class)` (a Filament `HasLabel` backed enum) hydrates field state to the **enum case instance** during the form lifecycle; it only dehydrates to the scalar on save. `$get('status')` yields a `DocumentStatus` object, not `'live'`. PHP does not auto-cast a backed enum via `(string)` — `(string)($get('status') ?? '')` throws `Error: Object of class … could not be converted to string` mid-validation and 500s the form (surfaces as "cannot upload file" because file-drop validation round-trips the whole form). Normalize: `$s = $get('status'); $s instanceof DocumentStatus ? $s->value : (string)($s ?? '')`. Applies to any rule/closure/`ValidationRule` constructor reading a sibling enum-backed Select via `Get` — feed it `->value`, never a cast. Reference: `DmsFormPresenter::uniqueLiveRule()` → `UniqueLiveDocument(string $status)`; the cast threw at `DmsFormPresenter::uniqueLiveRule()` and broke DMS upload + create. Same family as Rule 23 (export columns humanize enums via `tryFrom($state)?->getLabel()`) and Rule 36 (a missing import silently fatalles a Presenter) — Filament hands you enum objects in more places than it advertises.

**43. `FileUpload->downloadable()` on the `public` disk renders as a plain `<a href>` to `Storage::url()` (→ `/storage/...`, served statically off the symlink) — it does NOT route through the admin panel and does NOT run `EnsureHasPermission`.** A click is a client-side anchor (`vendor/filament/forms/.../file-upload.js::getDownloadLink`), not a Livewire roundtrip. Don't assume panel auth gates a public-disk download — it bypasses `EnsureHasPermission` entirely; use a private disk + a streamed/signed route if access must be enforced. The infolist `asset('storage/'.$path)` link is the same static URL. **Upload flag baseline (2026-11-15):** every admin `FileUpload` carries `downloadable()` + `openable()` + `previewable()` (the private-disk User signature has download + open + preview too); image-capable fields add `imageEditor()`; browser-side `imageResizeMode/TargetWidth/TargetHeight/Upscale(false)` is on Profile (512) and Resource (1280) only — deliberately NOT on Post/Feed/Gallery/Link (they accept animated GIF/SVG, and canvas resize can flatten an animation to one frame) or Letterhead (print quality + width rule). Add it to a field only if it is restricted to JPEG/PNG/WebP.

**44. `FileUpload->maxSize()` is in KB and must stay ≤ PHP `upload_max_filesize`/`post_max_size` AND ≤ Livewire's `temporary_file_upload.rules` `max:` (KB).** A larger value fails silently (PHP rejects before Filament's rule runs). Binding ceilings: PHP `upload_max_filesize=100M`/`post_max_size=105M`, `config/livewire.php` `temporary_file_upload.rules = ['max:102400']` (100MB — Livewire's multipart temp-upload endpoint, distinct from `payload.max_size` which only guards JSON snapshots). Cap in code or raise php.ini/livewire config. Reference: `OnboardingFormPresenter::videos()` was `maxSize(204800)` (200MB) vs 100M PHP → rejected real videos; raised to `97280` KB (95MB), under `FeedFormPresenter` video (`102400` KB/100MB) and both ceilings. For "no practical limit" infrequent large uploads, still cap just under the lowest binding ceiling.

**45. A column the app treats as nullable must be `->nullable()` in the migration — the form's `->nullable()` is not enough.** Saving the null case otherwise throws `1048 Column 'x' cannot be null`. Reference: `onboardings.user_id` is the "global audience" key (null = global), but the migration omitted `->nullable()` so creating a global onboarding 500'd until the column was made nullable.

**46. Single-active-per-scope invariants belong on the model (`saved`/`updated` boot hook), NOT page `afterCreate`/`afterSave`.** A list-table `ToggleColumn` (or bulk action) UPDATEs the column directly and bypasses page hooks, so it can leave 0 or 2+ active rows per scope. Enforce at the model level so every write path is covered. Reference: `Onboarding` single-active-per-audience is only in `EditOnboarding::afterSave`/`CreateOnboarding::afterCreate`, so the list `ToggleColumn` (`OnboardingTablePresenter::isActive()`) breaks it.

**47. A required field on a non-active Filament `Tab` blocks save with its error hidden on that tab.** The admin sees "fix the errors" with nothing visible on the current tab. Make non-first-tab critical fields optional, or surface the error. Reference: `OnboardingFormPresenter::welcome()` is the only `required` RichEditor; saving from another tab fails silently.

**48. Form `->default()` overrides the DB column default on Create.** Filament dehydrates the field default into the insert payload, so `default(false)` beats a migration `default(1)` — the saved value surprises. Align the two. Reference: `OnboardingFormPresenter::isActive()` was `default(false)` vs migration `default(1)`, so new onboardings saved inactive.

**49. `TextInput->url()` uses Laravel's `url` rule = `filter_var(FILTER_VALIDATE_URL)`, which REQUIRES `scheme://host` — it rejects schemeless IPs/hosts (`127.0.0.1`, `192.168.1.1`, `example.com`).** To allow internal IPs / schemeless URLs, drop `->url()` and use `->rules(['string', 'regex:'.self::URL_HOST_REGEX])` with a three-branch regex: `(?:mailto|tel):…` | `scheme://…` | `[host][(:port)]?[(/?#)…]`. Strict `mailto|tel` keeps `javascript:` rejected. Caveat: `javascript://x` passes BOTH old `url` and this regex (pre-existing surface, not a regression) — block `javascript`/`data` explicitly if hardening is required. Reference: `LinkFormPresenter::URL_HOST_REGEX` on `internal_url` + `url`.

**50. A locked/audit submitter field is a non-submittable `Placeholder`, NEVER a `disabled()->dehydrated(true)` relationship `Select` — and an admin "quick submit" modal is a header `Action::schema([...])` that persists via inline `Model::create`, gated by `canCreate()`.** `Select::make('user_id')->relationship('user','name')->disabled()->dehydrated(true)` is wrong on two axes: it runs an **unbounded** query loading the entire `users` table for a dropdown the user can't change (data leakage + scaling), and `dehydrated(true)` on a disabled field still ships `user_id` in the Livewire payload with no server re-assertion — a crafted request can reassign the record. Correct display: `Placeholder::make('user_id')->content(fn(?Model $record) => $record?->user?->name ?? ($record === null ? auth()->user()?->name : null) ?? __('...deleted_user'))` — the `??` chain MUST gate the auth fallback on `$record === null`, else a record whose author was deleted (`$record->user` null, `$record` non-null) falls through to `auth()->user()->name` and mis-attributes the row to the current viewer. `Placeholder` submits nothing, so `user_id` is enforced server-side: on Create via `mutateFormDataBeforeCreate(array $data): array { $data['user_id'] = Auth::id(); return $data; }` (see `CreateReleaseRequest::mutateFormDataBeforeCreate`), and on Edit it's simply not in the form data so it's preserved untouched. **Rule: a display-only field is a `Placeholder` with a `$record === null`-gated auth fallback; the value is injected server-side or kept out of the form — never a `disabled()->dehydrated(true)` Select that leaks the table and trusts the payload.**

The admin "quick submit" modal (the user panel has its own Livewire modal; admin needs one too — a Resource + Create page is a full page, not a modal) is a header `Action::make('submitRequest')->schema([Presenter::type(), Presenter::title(), Presenter::body()])->action(fn(array $data) => ReleaseRequest::create(['user_id'=>(int)Auth::id(), 'type'=>$data['type'], 'title'=>$data['title'], 'body'=>$data['body'], 'status'=>ReleaseRequestStatus::Open->value]))` on `ListReleaseRequests::getHeaderActions()`, alongside the standard `CreateAction`. Two gates the custom Action does NOT get for free (unlike `CreateAction`, which auto-enforces the create policy): `->visible(fn() => $this->getResource()::canCreate())` hides it from users without create permission, and `->authorize('create', Model::class)` re-checks at submit time. Persistence goes straight to `Model::create([...])` with `user_id` and `status` forced **server-side** (never read from `$data`) — the schema validates user-editable fields (type/title/body via Presenter rules), `$fillable` is scoped to safe columns, so no mass-assignment risk and **no separate Service class is needed** (same convention as `CreateTaskAction` etc. — Action owns persistence; do not introduce a `*Service`). **Rule: a custom header Action that creates rows needs explicit `canCreate()` visibility + `authorize('create')` (CreateAction gets these implicitly) and must force immutable columns server-side — but it does NOT need a Service; inline `Model::create` with a `$fillable`-scoped model + server-forced fields is the pattern.** Reference: `ReleaseRequestResource` + `ListReleaseRequests` (header `submitRequest` → `ReleaseRequest::create` with server-forced `user_id`/`status`) + `CreateReleaseRequest::mutateFormDataBeforeCreate`.

**51. A new admin module gets a top-navbar shortcut button alongside the cache/utilities strip — a `canCreate()`-gated `<a>` to `Resource::getUrl('create')`, rendered via the `GLOBAL_SEARCH_START` → `filament.resources.dashboard.utilities` render hook.** The utilities strip (`utilities.blade.php`, registered in `FilamentServiceProvider::registerComponentHooks()` at `PanelsRenderHook::GLOBAL_SEARCH_START`) is a horizontal scroll of `w-10 h-10` icon buttons. A deep-link to a Resource create page is a plain `<a href="{{ Resource::getUrl('create') }}">` styled identically (same `group relative shrink-0 flex w-10 h-10 … rounded-xl … text-[var(--md-sys-color-primary-container)]` + `<x-ui.modals.tooltip position="bottom"/>`), NOT a `<button @click>` — it's navigation, not an Alpine action. Gate it `@if(Resource::canCreate())` so only permitted admins see it (the create page enforces the policy, but hiding the entry avoids a 403 click). Icon is a Material Symbols name matching the resource (`auto_awesome` for `ReleaseRequestResource`). **Rule: a top-navbar deep-link to a Resource page is a `canCreate()`-gated `<a>` using `Resource::getUrl('create')`, styled like the existing icon buttons — never a `<button @click>` and never ungated.** Reference: `utilities.blade.php` (release-request create shortcut) + `ReleaseRequestResource::canCreate()`/`getUrl('create')`.

**52. Release-note sync — every new admin module/feature gets a `config/releases.php` checkpoint AFTER its pattern doc (this file) is updated.** `config/releases.php` is an array of checkpoints rendered by `components/dashboard/modal/release.blade.php` as `collect(config('releases', []))->reverse()` — the **last** entry is newest. Doc-sync order when a module ships: (1) add the reusable pattern here in `filamentPattern.md` (and the user-panel side in `livewirePattern.md`) FIRST; (2) THEN append a checkpoint at the **end of the array** so it becomes newest. Checkpoint shape: `id` (kebab), `version` (next β.N), `badge` => `'جدیدترین'`, `period` (Jalali month), `icon`+`theme_icon` (Material Symbols), `color` (token key; newest forced `primary`), `theme_title` (Farsi), `items` = `['title'=>…,'desc'=>…]` Farsi pairs. **Demotion: re-badge the previously-newest entry from `'جدیدترین'` to a real category badge before appending, so only ONE `'جدیدترین'` ever exists.** Never edit an old checkpoint in place. Reference: the `release-request` β.9 checkpoint + the re-badged `channels-launch` (was `'جدیدترین'` → `'ارتباطات'`).

**53. A mixed-media `FileUpload` (image + video) MUST drop `->image()` — `->image()` forces image-only server validation and rejects every non-image mime regardless of `acceptedFileTypes`.** `acceptedFileTypes` alone is NOT enough: `->image()` adds Laravel's `image` rule (`jpg,jpeg,png,bmp,gif,webp,avif`) on top, so `video/mp4` in `acceptedFileTypes` while keeping `->image()` still 422's a `.mp4`. Gate: drop `->image()` entirely, enumerate both image AND video mimes in `acceptedFileTypes`, bump `maxSize()` to the video ceiling (Rule 44). Filament's FileUpload grid does NOT render video thumbnails natively (only image previews) — accepted trade-off; the user-panel render supplies the cover frame (see `livewirePattern.md` "Gallery mixed-media render"). Reference: `GalleryFormPresenter::path()` — was `->image()` + 4 image mimes + `maxSize(5120)`; now no `->image()`, mimes include `video/mp4|video/webm|video/quicktime`, `maxSize(51200)`. The stored `path` JSON array shape is unchanged — video support needs NO migration and NO model edit, only the form gate + a render-time extension branch.

**54. A relationship `Repeater` (`->relationship()`) that allows optional/empty rows must use `->defaultItems(0)` + conditional `->required(fn(Get $get) => filled($get('key')))` on the key/value fields + return `null` from the `mutateRelationshipDataBefore*Using` helper to skip empty items — NOT a repeater-level `dehydrateStateUsing` filter.** Filament's relationship-save loop (`vendor/filament/forms/src/Components/Repeater.php` `saveRelationshipsUsing`) iterates `getItems()` (child components), **not** the dehydrated state array, and does `if ($itemData === null) continue;` — so returning `null` from `mutateRelationshipDataBeforeCreateUsing`/`mutateRelationshipDataBeforeSaveUsing` is the only way to drop an empty row. The deletion check keys state by `"record-{modelID}"` via `array_key_exists("record-{$id}", $state)` (key lookup, not positional). **Never wrap a relationship repeater's `dehydrateStateUsing` in `array_values()`** — it strips those `"record-{id}"` keys and makes every Edit save delete-all + re-create every child (PK churn, lost timestamps, cascade risk); `array_values(array_filter(...))` is only safe on a JSON-column repeater with no reconciliation (Rule 40 `attachments()`). Symptom prevented: an empty default repeater row with a `required` key blocks Create with `"فیلد … الزامی است"` even when other rows are filled — the error is on the unnoticed empty row. Reference: `ProfileFormPresenter::details()` — `->defaultItems(0)`, `key`/`value_*` conditional `->required`, `dehydrateDetailValue()` returns `null` for a blank key; `key` `->required($rowHasValue)` fires when any value field is filled (catches "value entered, key forgotten"), each `value_*` `->required(fn(Get $get) => filled($get('key')))` fires when a key is chosen (catches "key chosen, value forgotten") — an entirely empty row passes both and is skipped at save.

**55. `disabledOn('edit')` stops a field from being *saved* — it does NOT stop Filament from *validating* it against a live-recomputed `options()` list; add `->validatedWhenNotDehydrated(false)` whenever the field's options depend on mutable data.** `disabled()` makes `isSaved()`/`isDehydrated()` false on that operation, but `isValidatedWhenNotDehydrated()` defaults to `true` and is never implied false by `disabled()` — so a `Select` whose `options()` closure is scoped to admin-editable data (e.g. a department's `ticket_options`) still runs Filament's auto-derived `in:` rule against the *current* options set on every save, even though the field can't be changed. If that data narrows after the record was created (a department gets/loses a custom type), the stored value falls outside the new options list, and editing ANY other field on that record throws a spurious "selected X is invalid" error from the untouched disabled field. Verified against installed Filament source (`CanBeValidated`/`Select::getInValidationRuleValues()`). **Rule: any `disabledOn('edit')` field whose `options()` is computed from data that can change after the record exists needs `->validatedWhenNotDehydrated(false)` — a relationship-bound Select (label resolved from the relationship, not a static options array) and a static-enum-backed Select are NOT at risk.** Reference: `TicketFormPresenter::requestType()`/`requestArea()`/`targetDepartment()`.

**56. An interactive widget shared between the admin panel and a user-panel Livewire module is ONE embeddable Livewire component, mounted via `Filament\Schemas\Components\Livewire::make($componentClass, fn(?Model $record) => [...])` on the admin side — not a second, parallel implementation of the same UI.** Gate with `->visible(fn(?Model $record) => $record !== null)` (no record yet on Create). The embedded component's blade must render **one stable root element unconditionally** — never wrap the whole template in a top-level `@if`; Livewire's nested-component tracker extracts the child's tag name from rendered HTML on mount and reuses it on the next partial re-render (e.g. from a `->live()` sibling), and zero/malformed output on any render pass poisons that stored tag, throwing `Invalid Livewire child tag name` on the *next* interaction — move the `@if` inside the root div, not around it. Full pattern (shared policy class + one embedded widget + reply-thread trait + effectiveness/notification wiring) in `livewirePattern.md` "Shared access policy + one embeddable widget". Reference: `ThsResource::form()` embedding `Ths\Workspace`.

**57. A `Repeater` with a custom `saveRelationshipsUsing()`/`afterStateHydrated()`/`dehydrateStateUsing()` that flattens a list-of-pairs into a scalar map (or vice versa) is a reshape BOUNDARY — normalize defensively on both sides, and if a `RichEditor` shares the same column with a user-facing plain-text form, sanitize before rendering unescaped, never just un-escape.** Two hazards: (1) shape mismatch (nested array where a scalar is expected) crashes a typed Livewire `Form` property or hard-typed helper — coerce non-scalars to a joined string at the read boundary rather than trusting every writer (`Profile.about_me`, `Feed.poll_options`); (2) if the same column is also writable as plain text via a user-facing Livewire form (dual-authored, not admin-only), rendering it as unescaped HTML once a `RichEditor` is added is a stored-XSS hole — a user typing `<script>` gets it rendered unescaped to every viewer. Full decision table (shape-normalize guard vs. `Str::sanitizeHtml()` vs. `superClean()` for excerpts) in `livewirePattern.md` "Rendering text/HTML in Blade" — read it before adding a `RichEditor` to any column with (or might get) a plain-text writer, or before adding a custom reshape closure to any `Repeater`. Reference: `ProfileFormPresenter::aboutMe()`, `FeedFormPresenter::pollOptions()`, `SuggestionFormPresenter::description()` (dual-authored with `SuggestionForm::$descriptionSelf`), `CommentsRelationManager`'s `RichEditor` (dual-authored with the front-end comment composer).

**61b. Gating an enum case behind a dedicated Action (not a free `Select` option) needs a `selectableOptions()` enum helper that drops the case + `disabled()`/`->validatedWhenNotDehydrated(false)` on the Select for records already in that state (Rule 55) + the Action's own explicit permission gate — a bare `Action::make()` is NOT a `RecordAction` subclass and does not auto-enforce `canEdit()`/`canDelete()` the way `EditAction`/`DeleteAction` do.** A custom table Action gated only on record state (`->visible(fn($record) => $record->status !== Rejected)`) is reachable by any admin who can view the table, regardless of their `update` permission on that module — `->visible()` must ALSO check `Resource::canEdit($record)`, and the `->action()` closure should re-check with `abort_unless(Resource::canEdit($record), 403)` as defense-in-depth against a replayed/crafted action call bypassing a stale `visible` state. This was a real gap caught by `claude-reviewer` on `ReleaseRequestTablePresenter::reject()` (visibility checked only `status`, not permission) — fixed by adding `&& ReleaseRequestResource::canEdit($record)` to `visible()` and `abort_unless(ReleaseRequestResource::canEdit($record), 403)` inside `action()`, mirroring the pre-existing `SkillRequestResource`'s `RequestActions::rejectAction()` (which already does both checks via `self::canEdit()` since it's a trait mixed into the Resource itself, not a standalone class needing an explicit Resource reference). `ReleaseRequestStatus::selectableOptions()` mirrors `options()` but `->reject()`s `Rejected`, so `ReleaseRequestFormPresenter::status()` can never free-select it — the ONLY path to `Rejected` is `ReleaseRequestTablePresenter::reject()`'s dedicated Action. Without the `disabled()`+`validatedWhenNotDehydrated(false)` pair on the Select, re-saving ANY field on an already-rejected record would 422 with a spurious "selected value invalid" error (exactly Rule 55's mechanism — `selectableOptions()` narrows the `in:` validation list, and a stored `'rejected'` falls outside it). **Rule: "reject via a dedicated action, not a free Select option" is `selectableOptions()` (excludes the case) + `disabled()` on the record's own already-rejected state + `validatedWhenNotDehydrated(false)` + the Action's own `canEdit()` gate (`visible()` AND inside `action()`) — the mandatory-vs-optional question for any accompanying reason/response field is a separate, independent design decision (see the field-generalization note below), not part of the gating mechanism itself.**

`ReleaseRequest` also carries a general-purpose `response` text column (renamed from an earlier `rejection_reason` — the original design coupled the field to the `Rejected` status only; it was generalized because an admin resolving/approving a request should be able to leave the same kind of note, not just when rejecting) — `ReleaseRequestFormPresenter::response()` is a plain, always-optional, always-editable `Textarea` wired into the regular Edit form for ANY status, independent of `status()`'s own disabled-when-rejected behavior; `ReleaseRequestTablePresenter::reject()`'s own `response` field is likewise `->nullable()`, not `->required()` — a rejection can exist with no note attached, by design. `ReleaseRequestInfolistPresenter::response()`/the user-panel history-tab callout are BOTH gated purely on `filled($record->response)`, never on `status === Rejected` — the same field is shown to the requesting user whenever an admin has written into it, regardless of which status it was written under, with color/icon (`danger`/`cancel` vs `primary`/`forum`) chosen by status only for presentation, not for whether the entry renders at all. **Rule: an admin-response field attached to a status-driven workflow should default to "always optional, always visible-to-the-affected-user when filled" unless there's a specific reason to couple it to one status — coupling it to a single status (as the original `rejection_reason` did) is a premature narrowing that has to be undone the moment the field turns out to be useful for other outcomes too.** The attachments Repeater on `ReleaseRequest` reuses the Task pattern verbatim (Rule 40: `FileUpload::make('path')->saveUploadedFileUsing(...)->set('name'/'mime'/'size')` + `Hidden` siblings, directory `release_request/attachments`) even though it's a plain JSON column with no relationship — the technique doesn't require a relationship context, only the shape does. User-panel mirror in `livewirePattern.md` "Response + attachments on user-submitted requests". Reference: `ReleaseRequestFormPresenter::status()`/`response()`/`attachments()`, `ReleaseRequestTablePresenter::reject()`, `ReleaseRequestInfolistPresenter::response()`.

**62. Filament table row Actions never carry a visible text `->label()` — they are `->tooltip($label)->iconButton()`, the label surfacing only on hover.** This is the established convention for every row-level action in this codebase (`FilamentActions::viewAction()`/`editAction()`/`deleteAction()`/`restoreAction()` all use `tooltip()`+`iconButton()`, never `label()`); a custom table Action that skips `iconButton()` renders as a full labeled button inconsistent with its siblings in the same row. Header-level Actions (`CreateAction`, a custom "quick submit" modal trigger) are the opposite — they keep `->label()` since they're primary page-level CTAs, not row-icon-buttons; only ROW actions get the icon-only treatment. Reference: `ReleaseRequestTablePresenter::reject()` was originally built with `->label()` and no `iconButton()` — inconsistent with its `view`/`edit`/`delete` siblings on the same row — fixed to `->tooltip(...)->iconButton()`.

**63. A record editable from MORE THAN ONE admin surface (a Resource's own Create/Edit pages AND a RelationManager elsewhere) needs its write side-effect wired on EVERY surface individually — a page-level `afterCreate`/`afterSave` hook does NOT cover a RelationManager's table `EditAction`, which has its own independent lifecycle.** `TicketsRelationManager` (mounted on `UserResource` — a user's "Tickets" tab) reuses `TicketFormPresenter::assignedTo()` in its `EditAction`'s form, but that action is a plain table action with no `after()` hook — assigning a ticket from there updated `assigned_to` correctly (Filament's default `EditAction` handler) but never called `AssignTicketAction::syncForAdmin()`, so the mirrored TaskBoard `Task` silently never got created/updated, even though the identical field on `ThsResource`'s own `CreateTicket::afterCreate()`/`EditTicket::afterSave()` had already been wired (and tested) correctly. Fix is to attach the same side-effect directly on that surface's action: `self::editAction()->after(function (Ticket $record) { if ($record->wasChanged('assigned_to')) { app(AssignTicketAction::class)->syncForAdmin($record, $record->assigned_to); } })` — a table action's `after()` closure receives the same already-`update()`d record instance as a page's `afterSave()`, so `wasChanged()` behaves identically. Distinct from Rule 46 (which moves a cross-write-path invariant into a model boot hook): that works for a pure validity constraint, but spawning a `Task` needs request-scoped construction (title/description built from the ticket, `TaskDetail::create`) that doesn't belong in a model boot hook and would also misfire from factories/seeders — so the fix here is "audit every admin surface that can write this field and wire the same call," not "move it to the model." **Rule: whenever a field gets a dedicated sync/side-effect hook on one Resource page, grep for every OTHER place that field is form-editable (RelationManagers especially) and wire the identical hook there too — don't assume the page lifecycle is the only entry point.** Reference: `TicketsRelationManager` (`app/Filament/Resources/UserResource/RelationManagers/TicketsRelationManager.php`), covered by `UserResourceTest::test_tickets_relation_manager_assigning_a_ticket_syncs_linked_taskboard_task` / `test_tickets_relation_manager_reassigning_updates_existing_linked_task_not_duplicate`.

**64. A cascading `Select`'s `afterStateUpdated` must re-validate every DEPENDENT field's CURRENT value against its own newly-recomputed option set, not just clear the field one level below it in the chain.** `TicketFormPresenter::targetDepartment()` (department picker) feeds `requestType()`'s options (`Ticket::getCustomRequestTypeOptions($get('extra.target_department'))`, department-scoped via `HasTicketOptions`/`Department::ticket_options`), which in turn feeds `requestArea()`'s options. The department's `afterStateUpdated` only reset `request_area`/`assigned_to` (the two fields with no further options-dependency), leaving `request_type` holding whatever value it had before — if the new department's custom `ticket_options` no longer include that type, the Select renders blank/unselected while the underlying form state still carries the stale, now-invalid value. Fix mirrors the already-correct sibling implementation on the user-panel side (`Livewire\Dashboard\Ths\Main::updatedTicketTargetDepartment()`): explicitly recompute the dependent field's option set and reset it if the current value no longer exists in it, `$set` cascading down from there:
```php
->afterStateUpdated(function (Get $get, callable $set) {
    $typeOptions = Ticket::getCustomRequestTypeOptions($get('extra.target_department'));
    if (!array_key_exists($get('request_type'), $typeOptions)) {
        $set('request_type', array_key_first($typeOptions));
    }
    $set('request_area', null);
    $set('assigned_to', null);
});
```
`$set()` does NOT re-trigger the target field's own `afterStateUpdated` (Filament's `Set` utility defaults `$shouldCallUpdatedHooks` to `false`), so this doesn't double-fire `requestType()`'s own reset-`request_area` callback — the explicit `$set('request_area', null)` right after is what actually clears it. **Rule: when field C's options depend on field B which depends on field A, changing A must re-validate B against A's new scope (reset if invalid) AND unconditionally reset C — don't just reset the leaf.** Reference: `TicketFormPresenter::targetDepartment()`, covered by `ThsResourceTest::test_create_ticket_target_department_change_resets_stale_request_type` / `test_create_ticket_target_department_change_keeps_request_type_when_still_valid`.

**65. The admin panel's global search is wired through a custom `App\Services\Search\FaultTolerantGlobalSearchProvider` (via `AdminPanelProvider`'s `->globalSearch(FaultTolerantGlobalSearchProvider::class, ...)`), NOT Filament's default `true` provider — because Filament's stock `DefaultGlobalSearchProvider::getResults()` loops every globally-searchable resource with no per-resource try/catch, so a single resource throwing (e.g. a bad `getGloballySearchableAttributes()` dot-notation attribute, or any framework/driver-version SQL quirk) takes down the ENTIRE global search bar for every admin, on every keystroke, sitewide.** Prompted by a production incident (`PermissionResource`'s `['user.name', 'user.email']` global search threw `SQLSTATE[42S22]: Unknown column 'user'` a handful of times — root cause traced to a probable stale `vendor/` deploy, not a bug in current code, but the underlying availability gap — one resource can crash search for all — was real and worth closing regardless). The custom provider mirrors `DefaultGlobalSearchProvider`'s logic except the ENTIRE per-resource pipeline — `canGloballySearch()`, `getGlobalSearchResults($query)`, and `count()`/`category()` — is wrapped in one `try/catch (Throwable)` per resource (not just the results call, which alone would still leave `canGloballySearch()` free to fatal the whole bar). `getGlobalSearchSort()` is called before the loop (inside `usort()`'s comparator) so it's isolated behind its own `safeSort()` helper, which catches and defaults to sort-weight `0` — a throwing sort comparator can't fatal `usort()` before the loop even starts, and the resource's own results still render normally, only its ordering degrades. A caught exception anywhere is `report()`-ed (so it still surfaces in logs/monitoring) and that resource is skipped for that search, while every other resource's results still render normally. The resource-iteration source is factored into an overridable `protected function getResources(): array { return Filament::getResources(); }` specifically so tests can inject fake resources without touching the live panel's registered resource list. **Rule: any panel-level extension point that fans out across all resources/models in a loop (global search, a future cross-resource bulk-export, etc.) should assume any single item can throw at ANY call site in its per-item pipeline — not just the "obvious" one — and must not let one bad actor take down the whole feature for everyone else; wrap the whole per-item block, report the exception, continue the loop.** Reference: `app/Services/Search/FaultTolerantGlobalSearchProvider.php`, wired in `AdminPanelProvider::panel()`, covered by `tests/Feature/Support/FaultTolerantGlobalSearchProviderTest.php` (`test_admin_panel_uses_the_fault_tolerant_provider` — wiring; `test_it_skips_a_throwing_resource_and_still_returns_other_resources_results` — `getGlobalSearchResults()` throw; `test_it_skips_a_resource_that_throws_from_can_globally_search` — `canGloballySearch()` throw; `test_a_resource_that_throws_from_get_global_search_sort_still_returns_its_results` — `getGlobalSearchSort()` throw degrades ordering only, not availability — via fixture classes and the `getResources()` override seam).

**66. Cross-panel convention (not yet applicable in admin, noted for when it becomes so): when a page header carries BOTH a notification/badge-legend button and a workflow/guide button, the notification button goes FIRST in DOM source order, the guide button SECOND — under RTL flex with no `row-reverse`, this renders left-to-right as guide-then-notification, the required visual order.** The admin panel currently has only a single "guide" concept per page (no separate badge/nudge-legend button — the badge/nudge system is user-panel-only, see `app/Services/Menu/statePattern.md`), so this rule has no live admin call site today. Documented here so that if the admin panel ever grows a second, distinct header button alongside an existing guide button, the ordering matches the user panel's already-established, verified-consistent convention rather than being decided ad hoc. Full detail + the RTL-flex reasoning: `resources/views/viewPattern.md` §8.5 ("DOM order when both buttons exist").

**67. Physical-file cleanup on record deletion is centralized in `App\Traits\CleansAttachedFiles` — every model with a disk-stored attachment column uses it, never a bespoke `Storage::disk()->delete()` loop.** The trait exposes two protected statics: `deleteStoredFiles($value, array $pathKeys = ['path'])` (accepts a single path string, a flat array of path strings, or an array/`AsCollection`/`AsArrayObject` of associative items — pulls `$pathKeys` out of each associative item, e.g. `['file']` for `Ticket::requester_files`/`assignee_files`, `['url','thumbnail']` for `Onboarding::videos`) and `deleteStoredDirectory($directory)` (for whole-subtree deletes — `Channel`/`ChannelMessage`). Both are hard-wired to the `'public'` disk (protection grades 1/2) — every grade 1/2 attachment column uses it, so a disk parameter would be dead configurability; grade 3 (Correspondence, private `local` disk, `httpPattern.md` §7) keeps its own writers and deleters. Both filter every candidate path through an internal `isSafeStoredPath()` guard (rejects empty/absolute/`..`/scheme-prefixed strings, so a stray external URL or path-traversal value in a JSON column is never handed to the filesystem) and wrap the actual `Storage` call in try/catch → `Log::warning` rather than letting a disk failure abort the model's `deleting`/`forceDeleted` transaction. Wire it the same way every time: `use CleansAttachedFiles;` on the model, one line inside `booted()` on the correct event — SoftDeletes models hook `forceDeleted` (or `forceDeleting` if a *related* model's attachments must be read before cascade removes the row, e.g. `Task` reading `$task->detail->attachments`), non-SoftDeletes models hook `deleting`. Reference models: `Message`/`ChannelMessage`/`Channel`/`Task`/`ReleaseRequest` (already had bespoke cleanup, backfilled onto the trait for one source of truth), `Profile`/`DMS`/`Report`/`Ticket`/`Suggestion`/`Link`/`Post`/`Resource`/`Photo`/`Onboarding`/`Reply`/`Feed` (previously leaked orphaned files on delete — the record vanished but the file stayed on disk forever; fixed by adding the same one-line hook). **Rule: a new attachment/image/document column on any model gets its `booted()` cleanup hook in the same change that adds the column — never ship a write path without the matching delete path.**

**68. The write-side counterpart is `App\Traits\StoresAttachedFiles` — one `storeAttachment($file, string $directory, ?callable $fileName = null): array` that returns the Rule-40 canonical `{path,name,mime,size}` shape, used ONLY at the sites that already produce exactly that shape.** `$fileName` is an optional per-call-site closure (`fn($file) => …`) — the trait does not impose one naming scheme; the standard for business-document and media uploads is `fn($f) => FileNamer::stored('<module>', $f)` (`supportPattern.md` §5; used by `HasReplies`, `CreateTaskAction`/`UpdateTaskAction`, `SubmitReleaseRequestAction`, `SubmitTicketAction`, `CreateSuggestionAction`, and `TaskFormPresenter`/`ReleaseRequestFormPresenter` through their `self::fileName()` wrappers); only the private chat/contact uploads (`Contact\SendMessageAction`, `SendChannelMessageAction`) keep `time().'_'.Str::random(10).'.'.ext` — passing `null` uses plain `store()` instead of `storeAs()`. **Critical ordering, matched against a real production failure mode:** `$file->getClientOriginalName()`/`getMimeType()`/`getSize()` are read BEFORE `store()`/`storeAs()` runs, never after — reading file metadata off a `TemporaryUploadedFile` once it has already been moved to its final disk location is what caused production errors previously, which is why every hand-written call site already did it in that order; the trait preserves that ordering internally so no caller has to remember it. Sites that do NOT use this trait because their shape genuinely differs: `Ticket::requester_files`/`assignee_files` (`{file: path}` only, via Filament's `getUploadedFileNameForStorageUsing` — Filament handles the store itself, no metadata array needed), `Onboarding::videos`/`guides` (`{title,url,thumbnail/ext,size}` — extra sibling fields, not file metadata), `Profile::attachments` (`{key,category,path}` — no name/mime/size at all). Forcing those into the same 4-key shape would be a real schema/behavior change, not a refactor — don't. Reference: `app/Traits/StoresAttachedFiles.php`, wired into (Contact) `SendMessageAction`/`SendChannelMessageAction`/`CreateTaskAction`/`UpdateTaskAction`/`SubmitReleaseRequestAction`/`HasReplies`/`TaskFormPresenter`/`ReleaseRequestFormPresenter`. The two call sites that already rolled back partially-stored files on failure (`SendMessageAction`, `HasReplies::storeReplyFiles`) also now call `deleteStoredFiles()` from `CleansAttachedFiles` (Rule 67) for that rollback instead of a raw `foreach { Storage::delete() }` — same outcome on success, and no longer risks a `Storage` exception during rollback masking the original error being rethrown.

**69. Type-aware JSON metadata fields: fixed keys stay dedicated Filament form fields (never a locked Repeater), custom/cosmetic keys go in a namespaced `metadata.custom` `KeyValue`.** `ResourceResource` (seat/spot/meeting/car, plus any admin-added type — see `livewirePattern.md`'s "Dynamic resource types" section) is the reference: `floor`/`unit`/`extension`/`card`/`capacity` are each a dedicated `ResourceFormPresenter` method gated by `type` (legacy types only, never shown for a new admin-added type) — this is what makes the key "immutable in definition, mutable in value" for free, since there is no UI to rename what column of the JSON a hardcoded form field targets. Exception: `available_days`/`time_slots.{start,end}` are **not** type-gated — they back the generic, type-agnostic `Validators/ResourceSchedule` booking rule, so they're visible/dehydrated for every type including new ones, not just the historically meeting/car pair. Admin-appendable cosmetic attributes go in a **separate namespaced sub-key** `metadata.custom` via `KeyValue::make('metadata.custom')` (mirrors `UserFormPresenter::extra()`), never flattened into the top level — flat storage would let an admin type a custom key named e.g. `floor` and silently corrupt real data; namespacing rules that out structurally. `Resource::formattedMetadata()`'s generic per-key chip loop must explicitly `continue` past `custom` (flatten it separately) and past any field with its own prominent rendering (e.g. `notes`, rendered as a highlighted line above the chip strip in `image.blade.php`, not as a chip) — every other key falls through to the generic icon/label fallback automatically, so a new fixed field only needs a `$config[...]` entry to get a real icon, not new Blade.

**70. Extra logic that doesn't belong directly in a Presenter (multi-field orchestration, side-effecting writes, non-trivial derivations) goes in a dedicated static-method class under `Schemas/Helper/`, never inline in the Presenter method or the Page's `mutateFormDataBeforeCreate`/`Save`.** Reference: `OnboardingResource\Schemas\Helper\ExtrasTemplate` (`add`/`hint`/`options`/`sync`, consumed from `OnboardingFormPresenter` via `ExtrasTemplate::add($state, $set, $get)` etc.) and `ResourceResource\Schemas\Helper\TypeProvisioner` (`provision(array $data): string` — slugifies a new type's label, resolves same-label idempotent reuse vs. different-label collision suffixing, bulk-inserts the full `reservation_policies` row set, busts `ResourceType`'s cache; consumed from `ResourceFormPresenter::type()` via `->createOptionUsing(fn(array $data) => TypeProvisioner::provision($data))`). Namespace mirrors the owning resource: `App\Filament\Resources\{Resource}\Schemas\Helper\{HelperName}`. The dividing line: a Presenter method builds and returns ONE Filament component (`Select`/`TextInput`/etc.) — if the logic a closure needs is more than a few lines of the component's own visibility/formatting/validation, or it performs a write/side-effect (a DB insert, a cache bust, multi-step business logic), it's a Helper's job, referenced from the Presenter closure by a single static call, not written inline. Keeps the Presenter file readable as a flat list of "here's each field" and keeps the actual logic independently testable (a Helper's public statics are called directly in tests, no `ReflectionMethod` needed, unlike a Presenter's private methods).

**71. Icon `Select` fields render the actual glyph AND a Persian text label — never the icon's raw string name, never English — via `App\Traits\Filament\FilamentIconOptions` + `allowHtml()` + `getOptionLabelUsing()`.** Both icon-picker consumers (`ResourceFormPresenter::type()`'s `display_icon` field and `DepartmentFormPresenter::ticketOptions()`'s `icon` field) now share the exact same curated set — `App\Enums\ResourceTypeIcon`'s 14 cases, each with a real Persian `getLabel()` — via the trait's `curatedIconOptions(string $enum = ResourceTypeIcon::class)` (for `->options()`) and `curatedIconOptionLabel(string $value, string $enum = ResourceTypeIcon::class)` (for `->getOptionLabelUsing()`), both rendering `<div class="flex items-center gap-2">{svg}<span>{label}</span></div>`. This replaced Department's original design of scanning the entire `vendor/blade-ui-kit/blade-heroicons/resources/svg/*.svg` folder (hundreds of options, `Cache::remember` needed, English filename-derived labels only) — a real behavior change (fewer selectable icons), made deliberately for cross-module consistency once the user asked for "Farsi like resource" rather than mismatched English/Persian pickers. Backward compatibility for already-stored off-catalog icon values (departments that picked something outside the new curated 14 before this change) is preserved: `curatedIconOptionLabel()` falls back to rendering the raw heroicon file with a title-cased English label (the trait's `renderCuratedIconOption()` doesn't require the value to be in the curated enum) so an existing record's selected chip still displays correctly, it just isn't offered as a choice for *new* selections. **Gotcha:** `getAllIcons()`'s `Cache::remember('department_all_icons', 86400, ...)` result does NOT auto-invalidate on a code deploy — a stale 24h-cached value from before this kind of icon-rendering change will keep serving the old HTML shape until it expires or `Cache::forget('department_all_icons')` is run manually. Since the curated approach no longer needs that cache at all (14 static cases, cheap to compute inline), this class of staleness is now moot for the icon fields specifically, but the same gotcha applies to any other `Cache::remember`-wrapped computed-from-code (not from DB) value in this codebase. Wiring: `->options(fn() => ...)` returns `[value => renderedHtml]`, `->allowHtml()` lets Filament render that HTML in the dropdown, `->getOptionLabelUsing(fn(string $value) => ...)` re-renders the same HTML for the already-selected chip (Filament doesn't reuse the `options()` closure's output for that). **2026-11-21:** both methods take an optional enum-class argument and still default to `ResourceTypeIcon`, so the two existing callers are unchanged. `MediaIcon` is the second caller (`curatedIconOptions(MediaIcon::class)`); pass the same class to `curatedIconOptionLabel()`.

**72. Self-referential "parent" select on a string-code-keyed model (never a numeric-PK pattern): reactive `Select` excludes self via `Get $get('code')`, a shared `Model::wouldCreateCycle(?string $code, ?string $parent): bool` static rejects self-reference/cycles by walking the model's own `getCachedModels()` cache (zero extra query, always fresh — the cache is bumped on every save via `ModelCacheServiceProvider`), and the SAME cycle check is duplicated as a model-level `static::saving()` guard so it can't be bypassed by tinker/seeders/imports, not just the form.** Reference: `DepartmentFormPresenter::subordinateTo()` (`Department::getCachedOptions()->except($get('code'))`, `rules(fn (Get $get) => [new NoCyclicDepartmentHierarchy($get('code'))])`) + `Department::wouldCreateCycle()`/`booted()`. This differs from `Reservation`'s or `Comment`'s self-referential `parent_id` (numeric PK, no code-exclusion/cycle machinery needed at that scale) — do not reuse either as a template for a code-PK model. A sibling reactive field pair enforcing "if the parent is set, a dependent field can't hold its 'top-level' value" (here: `subordinate_to` set ⇒ `level` can't be `0`) follows the existing `Get`/`Set`-reactive pattern (rule 22/Task's department→unit→section cascade), with the invariant auto-corrected (not just rejected) both in the form (`Select::make('level')->options(fn (Get $get) => ...)` narrows the option list) and in the model's `saving()` hook (defense-in-depth for the same reason as the cycle guard).

**Before naming a new metadata JSON key, check the live data, not just the code.** Old/orphaned keys can exist in production rows that the current code never reads (this project once shipped `unit`/`card`/`availability` on `resources.metadata` with zero corresponding form fields) — inventing a plausible-sounding new key name (`card_number`) instead of matching what's already stored (`card`) silently splits one field into two: the new admin input reads/writes the new key while all the real historical data sits under the old one, invisible to the new field. Run a `SELECT`/raw SQL export of the actual table before adding a new JSON sub-field to an existing column.

**Gotcha, CONFIRMED IN REAL PRODUCTION BROWSER USE (not just tests) — never use `Get $get('...')` inside a `->visible()`/`->dehydrated()`/`->helperText()` closure on a component whose OWN statePath is itself a dot-notation JSON path (e.g. `TextInput::make('metadata.extension')`); use `fn ($livewire) => $livewire->data['type'] ?? null` instead.** On `ResourceResource`'s edit form, every `metadata.*` field gated by `Get $get('type')` (`floor`, `unit`, `extension`, `capacity`, `available_days`, `time_slots.*`) rendered as an inert, content-less `<div class="fi-hidden">` wrapper — no label, no input, nothing — for EVERY existing record, confirmed by the client viewing a real meeting resource's edit page (only the two ungated fields, `notes`/`custom`, ever appeared) and independently reproduced via `Livewire::test(EditResource::class, [...])->html()` (`wire:partial="schema-component::form.metadata.extension"` wrapper present, but the `x-data="filamentSchemaComponent(...)"` that actually renders the field's content was missing — `Component.php` only emits it `if ($isVisible)`). This is NOT the `->visible()` static-cache staleness that only appears across `Livewire::test()`'s chained `fillForm()` calls (disabling that cache via `Component::disableVisibilityCache()` did **not** fix it) — it is `Get`'s own relative-path resolution failing for `type` when called from inside a component nested under the unrelated `metadata.` prefix, on a completely fresh single-request page load, with `type` correctly set on the record from the start. Swapping every `Get $get('type')` for `$livewire->data['type'] ?? null` (Filament auto-injects `$livewire`, the underlying Livewire component instance, into any schema closure) fixed rendering immediately, confirmed both by the client's live browser and by the same `Livewire::test()->html()` check. Applies to **any** closure on a `metadata.*`/similarly-dot-nested field that needs to read a sibling top-level field — not just `->visible()`.

**Gotcha — Filament dehydrates a "blank" field as an explicit `null` (or `[]` for a `CheckboxList`/`KeyValue`), never as a fully absent key — this silently breaks any downstream code that distinguishes "key absent" from "key present but empty."** `ResourceFormPresenter::timeSlotStart()/timeSlotEnd()` left blank persist as `metadata.time_slots = {"start":null,"end":null}`, not an absent `time_slots` key; an unchecked `availableDays()` persists as `metadata.available_days = []`, not absent. `Resource::scopeAvailable()`'s narrowing (`whereNull('metadata->available_days')` / `whereNull('metadata->time_slots->start')`) only treats a **genuinely absent** key as "no restriction" — `JSON_EXTRACT` of an explicit JSON `null` is NOT SQL `NULL`, and `JSON_CONTAINS` on `[]` is always false — so saving a meeting/car resource through the admin form with the schedule fields left blank (the expected default) silently made it match **zero** days/hours, i.e. permanently unbookable, the moment it was first saved. Fixed via `ResourceFormPresenter::normalizeMetadata(array $data): array`, called from both `CreateResource::mutateFormDataBeforeCreate()` and `EditResource::mutateFormDataBeforeSave()` — strips `time_slots` to fully absent when either half is blank, strips `available_days` to fully absent when empty, restoring "doesn't define these keys ⇒ no restriction" as an actual invariant rather than an assumption. **Rule: any optional JSON sub-field that a query/validator treats as "absent ⇒ unrestricted" needs an explicit strip-when-blank step in a `mutateFormDataBefore{Create,Save}` hook — Filament will never do this for you.**

**73. Every exception message thrown from a model lifecycle hook or a write-path Action class must go through `__()` — never a raw string — because it can reach a real user via a Filament notification or a Livewire flash.** This is the same principle as rule 72's cycle-guard, generalized: a `static::creating()`/`static::saving()` invariant guard, or a validation-style `throw` inside an Action class's `execute()`, is not "developer-only" just because it lives outside a Form/Rule — Filament and Livewire both surface an uncaught exception's message directly to the acting admin/user. Confirmed bug instances (2026-08-26): `Profile`/`Permission`/`TaskDetail`'s new `static::creating()` duplicate-row guards (`app/Models/{Profile,Permission,TaskDetail}.php`) and `Department::wouldCreateCycle()`'s guard (`app/Models/Department.php`) were all first written with a hardcoded English `RuntimeException` message; `CreateTaskAction`/`UpdateTaskAction`'s Jalali-date guard (`app/Livewire/Dashboard/TaskBoard/Actions/*.php`) threw a raw English `InvalidArgumentException('Invalid Jalali date.')` reachable straight from the task deadline picker. Fix pattern: add (or reuse) a `validation.<key>` entry in that module's `lang/fa/resources/<module>/strings.php` and wrap the throw: `throw new RuntimeException(__('resources/<module>/strings.validation.<key>'));`. Reuse an existing key when one already covers the identical message rather than duplicating text — `Department`'s form-level `App\Rules\NoCyclicDepartmentHierarchy` already had `resources/department/strings.errors.cyclic_hierarchy`; the model hook was fixed to call the same key instead of inventing new text, so the form-rejection and the model-guard-rejection show the identical sentence.

**Gotcha found while fixing the above — a second top-level array key with the same name in a lang file silently overwrites the first, with no error.** Adding `'validation' => ['duplicate_detail' => '...']` as a new block at the bottom of `task/strings.php`, when a `'validation' => [...]` block already existed earlier in the same file (with `user_id`/`attachments.max_size`/etc., genuinely read by `CreateTaskAction`/`UpdateTaskAction`), silently discarded the entire first block — PHP array literals just let the later duplicate key win, no warning, no exception. Every key under the first `'validation'` array (including ones live-called elsewhere) went missing from `__()`'s perspective the moment the page/action rendered. **Rule: before adding a new top-level key to any `lang/fa/resources/*/strings.php` file, search the file for that exact key first — merge into the existing array, never append a second block with the same name.**

**Do not add `Livewire::test()` assertions on the exact persisted content of a `->visible()`-gated dot-notation field** (`assertDatabaseHas`/reading `$model->fresh()->metadata['key']` after `fillForm()->call('create'|'save')`) — the chained multi-step `fillForm()` flow has its own separate staleness behavior (see the static-cache gotcha this rule used to describe, still real, just not the cause of the bug above) and is not reliable for this specific assertion shape. Assert `->assertHasNoFormErrors()` + row existence for the admin-form layer, and cover the actual persisted-value business logic (accessors, scopes, validators) against directly-constructed/factory models instead (see `tests/Feature/Models/ResourceModelTest.php`). Reading existing data via `assertFormSet()` (hydration only) and reading rendered HTML via `->html()` (proved essential for catching the `Get`-resolution bug above) are both reliable.

**74. A validation rule on a root-level field can gate against a value living inside a `Section::relationship('detail')` companion tab — read it via `$get('detail.state')` from the root-level field's `->rule()` closure, and make the gate transition-aware with a `$record` guard so legacy rows that already satisfy the invariant aren't blocked on unrelated edits.** This is the cross-relationship-container form of Rule 37's cross-field closure: the gate is a root-level field (`status`), but the dependency (`detail.state`) lives under a `->relationship('detail')` `Section` (Rule 31), so Filament nests it at state path `detail.state` (same path-nesting as the `fillForm(['detail' => ['checklist' => …]])` test rule above). Return `fn(Get $get, $record) => function(string $attribute, mixed $value, Closure $fail) use($get, $record){…}` and attach to the root field via `->rule(self::doneRequiresState())`. Transition-awareness: the user-panel counterpart only blocks the *transition to* Done (a drag to the done column), not edits on an already-done row — mirror that server-side by short-circuiting when `$record && $record->status === TaskStatus::Done->value` (the record was already done before this edit, so an unrelated field change on a legacy done-without-state row must not fail), and when `$value !== TaskStatus::Done->value` (not transitioning to done) and when `!empty($get('detail.state'))` (state is being set alongside). Only the genuine create-or-edit-transition-to-done-without-state case calls `$fail(__('resources/task/strings.validation.done_requires_state'))`. On Create `$record` is null, so a new task saved as Done without `detail.state` is blocked — matching the user panel. **Rule: a cross-container dependency gate reads the nested state path, and a gate that mirrors a user-side "transition-only" guard carries a `$record` short-circuit so it doesn't retroactively fail pre-existing rows.** Reference: `TaskFormPresenter::status()` + `doneRequiresState()`; mirrors the user-panel drag-to-done guard in `taskboardPattern.md` §14 row 9.

**75. `ProjectResource`/`TaskResource` v2 parity — settings, approval, universal meta, deadline cap — and the centralized-updating-hook rule.** `ProjectResource::form()` carries a `ProjectFormPresenter::settings()` Section (Toggle `requires_approval`, TextInput `sla`, DatePicker `deadline`, Repeater `custom_schema` — same `^[a-z0-9_]+$` key regex as the user panel); `infolist()`/`table()` carry the matching `settingsSummary()` (table column toggleable, default hidden). `TaskResource::form()`'s `tab_bi` carries `TaskFormPresenter::meta()` (`KeyValue`, always shown, never gated on a linked project); `infolist()` carries `approval()` (badge: pending / تأیید date+approver / بدون نیاز), `meta()` (schema-label-or-raw-key fallback, mirrors the card's), and `lastTouchedBy()` (a per-record fallback query — admin's infolist is single-record, so it doesn't reuse the board's batched `LastTouchResolver`, it just queries once for that one record); a record-level `approve` action (first position, icon-button, `visible()` gated on `isPendingApproval() && TaskAccessPolicy::canApprove()`) writes through the same `ApproveTaskAction` the user panel uses. **Rule: approval routing on status-change to `done` lives in exactly one place — `Task::updating()` — never re-implemented in a Filament `mutateFormDataBeforeSave`/Page hook.** Admin and user both go through `$record->update([...])`/`Task::create`, so the model hook fires identically regardless of which panel wrote the row; this is why the admin `EditTask` page needs zero approval-specific code beyond the `approve` action itself. **Approval freeze (2026-10-22):** the same `Task::updating`/`deleting` hook refuses writes to an approved task for non-owners in `requires_approval` projects (`guardApprovedFreeze`); an admin-panel session is exempt (`ProjectAccessPolicy::canManageTasks`), so admin edits/bulk/delete keep working — see `taskboardPattern.md` §22. Full mechanism: `app/Livewire/Dashboard/TaskBoard/taskboardPattern.md` §19.

**76. First `openUrlInNewTab()` on a record `Action`, not a Table/Infolist column.** `TaskResource`/`ProjectResource`/`UserResource`'s `recordActions([...])` each carry `Action::make('tasksheet')->url(fn($record) => route('tasksheet', [...]))->openUrlInNewTab()->iconButton()`, opening that record's owner's Tasksheet performance-report page in a new tab; `UserResource` additionally has `Action::make('shareTasksheet')` triggering `App\Services\ProjectTask\TasksheetShareService` to send a share-with-manager notification on the admin's behalf. Every prior `openUrlInNewTab()` call site in this codebase is a `TextColumn`/`TextEntry` (`AdTablePresenter`, `AdInfolistPresenter`, `ProfileInfolistPresenter`, `DmsInfolistPresenter`, `ReleaseRequestInfolistPresenter`, `ContactInfolistPresenter`) — this is the first time it's chained onto a `Filament\Actions\Action` record button instead. Full Tasksheet feature writeup (report structure, scorecard, sharing flow) lives in `app/Livewire/Dashboard/Tasksheet/tasksheetPattern.md` — not duplicated here.

**77. A badge `TextColumn` that joins a variable-length list (multi-department audience/tags/etc.) truncates the DISPLAYED text at 2 items with a `+N مورد دیگر` suffix, but `->tooltip()` always shows the FULL untruncated list — never truncate both, and never truncate only the tooltip.** The table cell has fixed width and the badge can only grow so far before it wraps/overflows the row or pushes other columns; the tooltip has no such constraint, so it's the one place the complete list belongs. Shape: `getStateUsing()` builds the full `$labels` collection, then `$labels->count() > 2 ? $labels->take(2)->join('، ') . ' +' . convertToPersian($labels->count() - 2) . ' مورد دیگر' : $labels->join('، ')`; the sibling `->tooltip()` closure does the SAME lookup but always `$labels->join('، ')` with no truncation branch — it is not "the same string, just longer," it is built independently so a future edit to one doesn't silently also change the other. `count() > 2` (not `>= 2`) means exactly 2 items still shows both in full with no "+N" — the truncation only kicks in from the 3rd item on. Reference: `GalleryTablePresenter::department()` / `ReportTablePresenter::audience()` — both multi-department badge columns, fixed together 2026-09-11 (found via a user report that a many-department gallery/report row's badge became unreadably wide). **Rule: any future badge column joining an unbounded list (tags, recipients, shared-with lists) gets this same two-tier shape — short truncated badge text, full list only on hover — never a single un-truncated join left to overflow, and never a truncated tooltip that hides information the user specifically hovered to see.**

**78. Replacing or removing a stored file in a Filament `FileUpload` never deletes the old file by itself (Filament 5.5 only drops it from form state), so every Edit page with an upload declares `protected function trackedFileColumns(): array` (`column => pathKeys`: `[]` for a scalar path or list of strings, `['file']`/`['url','thumbnail']` for list-of-arrays, `relation.column` for a relationship section such as `detail.attachments`) and the shared `App\Filament\Traits\HandlesDroppedFiles` — composed once into `App\Filament\Pages\EditRecord` and `App\Filament\RelationManagers\RelationManager` — snapshots those paths at the START of `save()` (relationship sections write inside `getState()`, before `handleRecordUpdate`, so a later snapshot is already post-write), then after a successful save deletes `before − fresh-after` (one union across all tracked columns, re-read from the DB so a rolled-back/halted save deletes nothing; the cleanup runs after the save `try/catch` inside `rescue()` so a cleanup error can never be reported as a failed save). Never use `->deleteUploadedFileUsing()` (deletes on click, before Save) and never move the snapshot into `handleRecordUpdate`/`afterSave`. RelationManager edit modals have no `save()`: wire `self::editAction()->using(fn (Model $record, array $data): Model => $this->updateDeletingDroppedFiles($record, $data, [...]))`. Always hand `deleteStoredFiles()` a re-indexed list (`array_values(array_diff(...))`, `->values()->all()`): `extractStoredPaths` treats a non-list array (`[1 => 'x']` left by `array_diff`/`partition`) as ONE item and silently deletes nothing. Invariant relied on: one stored path ↔ one row (no feature shares a path between records). Stale Filament export files are pruned by the scheduled `exports:prune-old --days=30` (daily 03:35).

**79. Owner/author selects, locked keys and hook errors (2026-11-14).** (a) A user select on an admin form uses `User::...->visibleOnBoard()` through `visibleOnBoardOr($get('user_id'))` (the edited record's saved value stays selectable, so an edit never blanks a since-deactivated owner); `Profile`'s own `user_id` select is deliberately unfiltered and the NotifyRule picker offers active options plus the rule's saved ids. (b) A key that must not change after creation (`Department.code`, `Resource.type`) is `->disabledOn('edit')` (+ rule 55), the model hook is the real guard. (c) Hook/`Action` `ValidationException`s key their messages `data.<field>` (`data.status`, `data.employment_status`, `data.code`, `data.end_date`) so they land on the Filament form field; a hook that blocks a delete throws a `ValidationException` keyed `department` (the Department delete guard) so the admin sees the text. `HandlesActionExceptions` rethrows only Filament's own `mountedActions.*` validation errors (and, on a page that has `save()`, `data.*` page-form errors, e.g. Ths `closeAndSave`); any other `ValidationException` (thrown by a model hook) is shown as a danger notification through `reportActionException`. (d) A bulk action that writes through the model (UserResource bulk deactivate) wraps each record in `try/catch (ValidationException)`, skips it and lists the skipped names in one notification, never aborting the batch; the row toggle catches and notifies the same way. (e) Enum selects: a Select with `->options(SomeEnum::class)` dehydrates to the ENUM OBJECT, so any model attribute edited this way (`User.status`/`type`/`role`, `Profile.employment_status`/`position`, `Reservation.status`, `Feed.category`) needs a `set:` mutator that stores a `BackedEnum`'s `->value` (the `Task` shape), otherwise `=== 'string'` checks and `isDirty()` in hooks misfire on every admin save; form closures compare `$state instanceof BackedEnum ? $state->value : $state`.

---

## Admin panel feature-test convention — one `ResourceTest` per resource

Every admin resource has ONE feature-test file `tests/Feature/Filament/<Module>ResourceTest.php` (30 files, one per resource — no standalone filter/helper-text files; those were folded in). The load-bearing rules:

- **Trait-level cover-gap tests live in `tests/Feature/Traits/Filament/` (mirrors `app/Traits/Filament/`, NOT the `Filament/` ResourceTest folder):** the per-resource `*ResourceTest` files only exercise the shared traits through the developer super-admin bypass, so each shared trait gets its OWN dedicated `tests/Feature/Traits/<Trait>Test.php` (namespace `Tests\Feature\Traits`) for its real contract — 18 files in `tests/Feature/Traits/Filament/` (namespace `Tests\Feature\Traits\Filament`) covering the `App\Traits\Filament` traits; only `FilamentWorkflowPresenter`, `FilamentModelRuleNotice` and `PreparesAdminTaskCreate` are consumer-covered without their own file (shared-root and Livewire trait tests live in `tests/Feature/Traits/` and `tests/Feature/Traits/Livewire/`). The DB-backed ones reuse the verbatim `useMysql()` + transaction + `developer()`/`admin()` scaffolding (identical to the ResourceTest skeleton below) and add `setLocale('fa')` wherever a `__()` string is asserted; the two pure-static factories (`FilamentFormDividerTest`, `FilamentActionsTest`) drop `useMysql()`/transactions/auth entirely (no DB dependency — keeping them would be dead weight the reviewer blocks). Coverage map: `FilamentEditHeadingTest` (format branch "ویرایش {label}: {title}" via a column-based resource + a composite `getRecordTitle` override, plus the `title === label` fallback to `getTitle()`; mounts a real Edit page, reads `$component->instance()->getHeading()`), `AuthorizesByPermissionTest` (`moduleKey()` incl. the `ResourceResource → "resource"` edge case, developer bypass, non-developer `role='admin'` denial WITHOUT a Permission row, granted-actions via `abilities=[['module'=>'post','actions'=>['view','create']]]`, unauthenticated denial), `FilamentPageBehaviorTest` (`getRedirectUrl`→index + `getCreatedNotificationTitle`/`getSavedNotificationTitle` fa strings — protected methods invoked via `ReflectionMethod::setAccessible(true)`), `FilamentFiltersTest` (`createdAtFilter` date-range `from`/`until` scoping via `filterTable('created_at', ['from'=>…,'until'=>…])`), `FilamentHeaderActionsTest` (`getHeaderActions` returns `['create']` on a List page; on an Edit page `['create','view','delete']`, plus `'restore'` appended only on a soft-deletable model's page (Post vs Task) — reflection), `FilamentDateHandlerTest` (`mergeDeadline` joins `deadline_date`+`deadline_time`→`deadline` on Create, `mutateFormDataBeforeFill` splits on Edit, via the real `CreateTask`/`EditTask` consumers; assert on the RAW DB value, not the `datetime`-cast/Jalali accessor), `FilamentActionsTest` (every `public static` action factory — instance type + `getName()` + `isConfirmationRequired()`/`getExporter()`/`getLabel()`; do NOT invoke the `assign`/`unassign` action closures — they send Filament Notifications needing a Livewire session), `FilamentFormDividerTest` (`divider()` returns a `TextEntry` named `divider` with `getColumnSpan()['default'] === 'full'` — call via a consuming Presenter like `AdFormPresenter::divider()`, not the trait name), `FilamentPreferencesTest` (the `App\Livewire\Admin\ManagePreferences` page: `mount()` hydrates from `Auth::user()->extra['preferences']`, `save()` persists back, `getTogglesCount()` equals `count(getPreferenceFields())` — use `$component->set('data.field', …)` to mutate form state through Livewire's update lifecycle, not direct `instance()->data` writes), `FilamentAdminGuideTest` (pure-static, mirrors `FilamentActionsTest` — no DB/transaction, `setLocale('fa')`; `guideTabs()` empty-fallback via an anonymous `use FilamentAdminGuide` host with no `$guide` → `[]`, `PostResource::guideTabs()` shape with `label`/`icon`/`view` keys + `view()->exists()` on each tab view, `setupGuideAction()` builds an `Action` named `moduleGuide` with `getModalSubmitAction() === null`, the `modalContent` closure is pulled via `ReflectionObject` walk to the `modalContent` property and invoked → rendered HTML contains every tab label + `material-symbols-rounded` + `dir="rtl"`, and `guideEmptyStateActions()` returns only that one action), `FilamentViewActionDefaultsTest` (DB-backed: mounts the real List page via `Livewire::test` and calls `FilamentViewActionDefaults::viewModalShortcuts($instance->getTable())` — `['create','edit','delete']` on ListPosts (mirrors the row buttons), `['create','delete']` on ListEnergyTests, pinning the skip-edit-when-no-edit-page rule; plus a wiring pin — a fresh `ViewAction::make()` given livewire+table context yields the same shortcut names with no per-resource configuration, so a silent provider-wiring break goes red, plus the auth-gate pin — the create shortcut must stay `isVisible() === false` on `ListEnergyTests` (`canCreate(): false`) even for the developer super-admin, locking the `AuthorizesByPermission` create-arm convergence red, plus the mirror pins — an RM without header create (ChannelMembers) yields no create shortcut, one with (Tasks) does, and the two create-less List pages (`ListNotifyLogs`, `ListSkillRequests`) get none; `setLocale('fa')`), `FilamentResourceSwitchTest` (added 2026-10-28: the trait's contract through the real `ReservationResource` host — snake-case action names + `getUrl()` for every viewable group member in declared order, only the active resource `primary`+solid while the rest are `gray`+outlined, and a non-super-admin's group shrinking to only the resources they may view). Heading assertions are ALSO embedded into the relevant resource's own ResourceTest (column-based: `PostResourceTest`; composite: `ReservationPolicyResourceTest`) via `assertStringContainsString($record->title|$type, (string) $component->instance()->getHeading())` so a regression in either the trait OR the per-resource `recordTitleAttribute`/`getRecordTitle` config is caught at the resource level too. **RichEditor-title strip-lock:** for resources whose title column is a `RichEditor` (`PostResource`→`title`, `FAQResource`→`question`, `FeedResource`→`content`), the plain `assertStringContainsString($record->title, $heading)` assertion is NOT enough — raw HTML contains raw HTML, so it passes even when the bug is present (tags render literally in the heading). Add a dedicated `test_edit_heading_strips_html_tags_from_rich_<field>` that factory-creates a record with `<p><strong>☕️ …</strong></p>` in the title column, mounts the Edit page, and asserts the heading `assertStringContainsString` the inner text AND `assertStringNotContainsString('<p>')`/`('<strong>')`. **These heading assertions require `$this->app->setLocale('fa')`** — `edit_heading` (`'ویرایش :label: :title'`) exists only in `lang/fa/resources/general/strings.php`; under the default `en` testing locale `__()` returns the raw key `resources/general/strings.edit_heading` and the title never appears. `PostResourceTest` already sets `fa` in `setUp`; `FAQResourceTest`/`FeedResourceTest` do not, so their strip-tests set it per-method. **View-modal heading strip-lock (same fix, second surface):** the `ViewAction` modal heading is `__('filament-actions::view.single.modal.heading', ['label' => $this->getRecordTitle()])` = `نمایش :label` (fa, vendor `filament-actions::view.single.modal.heading`), and the action's `getRecordTitle()` resolves through `$this->getTable()->getRecordTitle($record)`. `Resource::configureTable()` wires BOTH `->recordTitleAttribute(static::getRecordTitleAttribute(...))` AND `->recordTitle(static::getRecordTitle(...))` onto the table, and `Table::getRecordTitle()` evaluates `recordTitle` FIRST (falling back to `recordTitleAttribute` only when blank) — so a single `getRecordTitle(?Model)` override covers the Edit page heading (via `FilamentEditHeading`), the View modal heading, AND the breadcrumb. Lock it with a sibling `test_view_modal_heading_strips_html_tags_from_rich_<field>`: `Livewire::test(List<Module>::class)->mountTableAction('view', $record)` → `$component->instance()->getMountedAction()->getModalHeading()` → assert `نمایش` + inner text present, `<p>`/`<strong>` absent. Same `setLocale('fa')` requirement (the `نمایش` string is fa-only). **Bug surfaced + fixed by `FilamentFiltersTest`:** `FilamentFilters::createdAtFilter()` read `$data['from']`/`$data['until']` unguarded in both the `query` and `indicateUsing` closures, so a single-sided date range (only `from` or only `until`) threw `Undefined array key` under Laravel's warning→exception handler — fixed with `$data['from'] ?? null` / `$data['until'] ?? null` guards; `test_created_at_from_only_filter_works_without_until_key` locks the fix by passing only the `from` key.

- **Skeleton (copied verbatim across all 31 files):** `setUp` calls `useMysql()` (copies `.env` MySQL creds at runtime, `DB::purge('mysql')`, sets `mysql` default — no `RefreshDatabase`, migrations are MySQL-only under `database/migrations/migrated/`), then `DB::beginTransaction()`; `tearDown` does `DB::rollBack()`. A private `developer()` helper creates a `role='developer'` User + an `is_super_admin` Permission row — the developer bypass in `AuthorizesByPermission::permits()` (and `EnsureHasPermission` middleware) makes every `canViewAny/canCreate/canEdit/canDelete` pass without per-module ability rows. Auto-increment IDs are NOT reset between tests; create fresh factory rows inside the transaction.
- **DeleteAction namespace:** this Filament v5 install has UNIFIED actions — `callTableAction(\Filament\Actions\DeleteAction::class, $record)`. `Filament\Tables\Actions\DeleteAction` does NOT exist here (throws `ActionNotResolvableException`). The string form `callTableAction('delete', $record)` also works (resources register delete via the `FilamentActions` trait under name `delete`).
- **`filterTable` second-arg shape** (`TestsFilters::filterTable` signature `$data = null` with auto-wrapping): bare scalar for `SelectFilter` (non-multiple) and `TernaryFilter` FALSE-case — `filterTable('gender','Male')`, `filterTable('active','0')` (string `'0'`, not `false` — `blank(false)` no-ops a TernaryFilter). BOOLEAN `true` for a `TernaryFilter` TRUE-case — `filterTable('has_users', true)`; string `'1'` lands in the else branch and silently fails to select the true query. ARRAY for multi-select — `filterTable('owners', ['departments'=>['MA']])`. NO second arg for a plain toggle `BaseFilter` — `filterTable('low_score')` sets `['isActive'=>true]`. Symptom of a wrong shape: `array_key_exists(): Argument #1 must be a valid array offset type` or a silent no-op — swap scalar↔array↔boolean↔none; the test run is the source of truth.
- **RichEditor (Tiptap) quirk:** `->required()` does NOT register the `required` rule key in Livewire's validator (closure-based `getRequiredValidationRule` calls `$fail('validation.required')->translate()`), so `assertHasFormErrors(['field'=>'required'])` cannot match — use key-only `assertHasFormErrors(['field'])` or the message-string form `['field'=>'validation.required']`. The empty-Tiptap-doc value `{type:doc,content:[{type:paragraph,content:[]}]}` is what trips required (plain `''`/`null` does NOT). RichEditor stores HTML — DB assertions use `assertStringContainsString`, not exact match.
- **Locale:** `.env.testing` forces `APP_LOCALE=en` but most `lang/en/...` option-translation files don't exist (only `lang/fa`). Any field whose options come from `__('resources/.../strings.*')` throws a `ViewException` ("Return value must be of type array, string returned") on mount under `en`. Add `$this->app->setLocale('fa')` in `setUp` (or per-test) when the FormPresenter/TablePresenter uses `__()` for option arrays — reach for it the moment you see that ViewException on mount.
- **Pagination flake on `assertCanSeeTableRecords`:** the dev DB has many seeded rows and tables with `defaultSort` paginate at 10/page — a factory row with a mid-alphabet name can sort beyond page 1. Give factory rows `0`-prefix names/titles so they land on page 1 (test-data choice, not a production change).
- **Read-only / List+Edit-only resources:** some resources hard-code `canCreate()=false` and register only `EditAction` + `ViewAction` (no delete, no filters, no dedicated `view` page — `ReservationPolicyResource`, added 2026-09-21: its `infolist()` reads the EAV key/value rows through `ValidationService::getPolicies()`, cached, so `Section` entries call `getStateUsing()` against that array rather than direct model attributes). Do NOT invent create/delete/filter tests; cover List + Edit mount + Edit save + 1-2 edit-form validation tests + a View-action-mounts-without-error smoke test (`mountTableAction('view', $groupedRow)` against the `groupedByResourceType()` row, not a raw `ReservationPolicy::find()`, since the table's records come from that grouped scope). A resource with only `index`+`view` pages (e.g. `EnergyTestResource`) gets List + View + filter tests only.
- **Embedded user-panel widgets on an admin Edit page can 403 the admin** (Rule 56, RESOLVED 2026-08-30): `ThsResource::form()` embeds `Ths\Workspace`, whose `mount()` enforces `TicketAccessPolicy::canView()` — which historically had no admin bypass (only requester/assignee/head-of-target-dept), so a non-involved admin/developer got a 403 mounting admin `EditTicket`. FIX: elevated-role bypass (`$user->hasElevatedRole()`) now leads `canView`/`canAssign`/`canSetEffectiveness` in `TicketAccessPolicy` (canReply/canClose inherit) — accepted side effect: elevated users see all tickets in the user panel too. The old test workaround (factory-creating the ticket with `requester_id => $admin->id`) is OBSOLETE and was removed from `ThsResourceTest` — create a proper `role => user` requester and let the linked-task owner assertion target the real requester (`AssignTicketAction::syncLinkedTask` deliberately sets `Task.user_id = ticket.requester_id`).
- **`fillForm` must nest fields that live under a `Section::relationship('detail')`:** `->relationship($name)` calls `$this->statePath($name)` (`EntanglesStateWithSingularRelationship.php`), so a child `Repeater::make('checklist')` has state path `detail.checklist`, NOT `checklist`. A test `fillForm(['checklist' => […]])` writes the wrong path and the field saves its default `[]`. Use `fillForm(['detail' => ['checklist' => […]]])`. Symptom: the relationship save round-trips `[]` despite `assertHasNoFormErrors`.
- **`TagsInput` has NO `maxItems()` in this Filament v5 install** — `maxItems` is on `CanLimitItemsLength` (`Repeater`/Builder/`Block` only). Calling `TagsInput::make('labels')->maxItems(10)` throws `BadMethodCallException` on render and breaks the whole form. To cap a `TagsInput`'s tag count, validate server-side: `->rules(['array', 'max:10', …])` (Laravel `max:N` on an array = element count). Per-tag constraints go in an invokable `App\Rules\*` (see `TaskLabelLength`). Symptom: every test mounting the form fails with `ViewException: Method …TagsInput::maxItems does not exist`. **Sibling gotcha — `TextInput` has NO `min()`/`max()` in this install** (same Macroable family); numeric bounds are `->numeric()->minValue(0)->maxValue(100)`, never `->min(0)->max(100)`, which throws `Method …TextInput::min does not exist` on render. Reference: `TaskFormPresenter::checklist()` weight field.
- **A JSON-column `Repeater` (e.g. `checklist`) round-trips with non-insertion-order sub-keys** (the `array` cast re-serializes, producing alphabetical key order). Don't `assertSame` the whole item array — key-order mismatch fails it. Assert each sub-key by its sequence index (`assertSame('step one', $c[0]['text']); assertSame(true, $c[0]['done']); …`) to keep strict `===` + item ORDER without coupling to the cast's intra-item key order. Do NOT reach for `assertEqualsCanonicalizing` — it drops strict type AND item order, masking a real scrambling/coercion regression in an ordered list.
- **Grouping/filter/sort coverage is complete and MUST stay folded per-resource — no standalone/cross-cutting test file, ever (2026-09-29).** Every resource's `->groups([...])`, `->filters([...])`, and `->sortable()` columns now have real functional coverage inside that resource's own `<Module>ResourceTest.php`: one `test_all_table_groups_render_without_error` per group option, one scoping test per filter (`filterTable(...) → assertCanSeeTableRecords/assertCanNotSeeTableRecords`), and one order-verifying test per sortable column (`sortTable(...)` + comparing `getTableRecords()->pluck('id')` against the fixtures' relative order — never assert an exact absolute list, the dev DB has pre-existing rows). Each resource's own file also carries a `test_group_and_query_closures_use_correct_param_names` static check scanning ONLY that resource's own `Schemas/*TablePresenter.php`/`Schemas/Grouping/*.php` for the closure-naming bug two paragraphs above (misnamed `$r`/`$q` params) — this used to be one centralized `tests/Feature/Filament/FilamentClosureConventionTest.php` scanning the whole `app/Filament` tree, and was deliberately split apart and deleted: a check that concerns one resource's own code belongs inside that resource's own test file, full stop, matching every other rule in this section. Three real bugs were caught and fixed by this sweep: `FeedTablePresenter::categoryGroup()`/`OnboardingTablePresenter::audienceGroup()` (crash), `JsonEnumGroup`/`ModuleGroup`/`TicketTablePresenter::overdueFilter()` (silent no-op), `SuggestionTablePresenter::hasReferralFilter()` (always-true filter), `ReservationTablePresenter::resource()` (sort on a non-DB accessor did nothing). Before adding a new `Group`/filter/sortable column to ANY resource, add its test to that resource's existing file the same turn — never defer it to a follow-up sweep, and never create a new file to hold it, no matter how tempting a "just this one cross-cutting check" file looks.
- **Mounted modal `Action::form(fn ($record) => ...)` receives `$record = null` — never read record properties there.** The form-closure on a record `Action` runs before the record is bound (`Attempt to read property "id" on null`). To shape fields per-record, either inline data eagerly in the array construction (`return [...fields built from $record?->...)`) or use per-field lazy closures (`fn (?Model $record) => ...`, `Get $get`, etc.) that resolve at modal state time. Reference: `UserTablePresenter::shareTasksheet()` (radio + conditional Select, `->modalWidth(Width::Small)`).
- **The reliable test route for state on a mounted table action is `mountTableAction` → `->set('mountedActions.0.data.FIELD', ...)` → `callMountedTableAction()`** — `callTableAction(name, record, data:)`/`fillForm()` does not write `mountedActions.0.data.*` in this install, so data arrives as null and required-field validation fails. Reference: `UserResourceTest::test_share_tasksheet_action_takes_recipient_and_invokes_service`. Related: never leave `config:cache` active in a dev/test environment — it bakes `app.env` so `app()->runningUnitTests()` returns false and every `fillForm` silently no-ops.
- **Re-parent wiring test (since 2026-09-21, every ResourceTest carries one):** `test_pages_are_reparented_and_wired_for_exception_presentation` asserts each page's `get_parent_class()` is its `App\Filament\Pages\*` base, Create/Edit pages mix in BOTH `HandlesActionExceptions` + `HandlesSaveExceptions` (`class_uses_recursive`), and (resources with relation managers) every RelationManager extends `App\Filament\RelationManagers\RelationManager` with `HandlesActionExceptions`. The deep save-failure contract lives in `ProjectResourceTest` ONLY: a real MySQL 1406 through the Livewire create harness (200-char name → 207-char slug over `varchar(191)`) → `assertNotified` with the presented value-too-long title + no persisted row. **Do not "fix" `Project::generateSlug()` truncation without re-pointing that test** — it deliberately rides the real violation to prove the presenter wiring. The service itself has its own master `tests/Feature/Services/ExceptionPresenterTest.php` (all 17 driver codes, reference format, renderable lanes — see `coreTestPattern.md`'s reference list). **Second anchor (2026-10-05):** the `save()`/`create()`-level wrap (validation-time crash, not just the DB-write step) has no FileUpload field on `ProjectResource` to repro against, so its deep contract lives in `GalleryResourceTest::test_create_gallery_shows_friendly_notification_when_upload_never_finished` instead — wipes the Livewire temp disk (`FileUploadConfiguration::disk()`/`directory()`) between `fillForm` and `call('create')` to force the real `UnableToRetrieveMetadata`, asserting the friendly notification and no persisted row.

## Panel plugins — Count Up (registered)

**Count Up** (`xplodman/filament-count-up`) is registered globally on the `admin` panel (`AdminPanelProvider->plugins([CountUpPlugin::make()])`): every `Filament\Widgets\StatsOverviewWidget\Stat::make()` animates automatically — `ModuleAnalyticsWidget`'s all-tabs stats included, zero per-widget edits, ever. Numbers inside plain strings (e.g. `"{$males} ┆ {$females}"`) animate token-by-token with `┆`/`%`/ms left as static text; `Htmlable`/`null` values pass through untouched, and it renders the final number server-side first (no-JS-safe, `prefers-reduced-motion`-aware). Package defaults (1000 ms, `,`/`.` separators) are deliberately kept — don't publish its config unless a real need appears. For tables, numeric count columns use `CountUpColumn` (extends `TextColumn`; keeps sortable/badge/color; coerces null → 0, so never use it on a column whose placeholder must survive a null): all 26 `_count`/`combined_read_count` columns across 15 table presenters are converted and every new count column should start as `CountUpColumn`, not `TextColumn`. Gotcha: batch-inserting the `use Xplodman\CountUp\Tables\Columns\CountUpColumn;` import via Git Bash `sed` silently **strips the backslashes** (`use XplodmanCountUpTablesColumnsCountUpColumn;` — unqualified, "Class …\CountUpColumn not found" only at render time, 70+ ViewExceptions suite-wide). Use the Edit tool or `perl -i -pe` for backslash-carrying insertions.

**Evaluated and rejected:** `giacomomasseron/filament-async-column` was installed, demoed live on DMS `users_count`, judged not useful for this app (every derived value is already a SQL-side aggregate, and AsyncColumn would drop sorting), and **removed**. Don't re-adopt unless a genuinely API-bound, non-sortable column appears.

## `PersianDateFieldService` — `->live()` only on `month`, date assembled at save-time not per-pick (production timeout fix, 2026-09-23)

Every year/month/day select this service built (`app/Services/PersianDateFieldService.php`) had `->live()` unconditionally, so picking a year, month, OR day each triggered a full Livewire round-trip — 3 round-trips to fill one date. On the admin Profile edit form (the heaviest form in the panel — repeaters, attachments), those round-trips stacked and occasionally hit an HTTP timeout in production, with nothing in `laravel.log` because the request was dropped mid-flight (proxy/PHP-FPM killed it before Laravel's own exception handler ran). **Fix: `->live()` now lives only on `monthSelect()`** — the only field whose value another field's options closure actually reads (`daySelect()`'s `dayOptions((int)$get("{$prefix}_month"))`). Year and day picks now cost zero round-trips. The real date is assembled once, at save/validation time, via `dehydrateStateUsing` + `mutateStateForValidationUsing` on the Hidden carrier field (both call the same shared closure, now `PersianDateFieldService::assemble()`, made `public`) — replacing the old `afterStateUpdated`-driven per-pick sync that used to write into the hidden field on every select change.

**This is used by 15+ resources (Event, Gallery, Ths, Reservation ×2, Report ×2, Reminder, Task, Profile ×5) — three of them had a real, independently-confirmed correctness bug hiding behind the old per-pick sync, all fixed:**

1. **`TaskFormPresenter::deadlineDate()`'s `ProjectDeadlineCap` rule stopped validating the picked date.** Filament validates a field BEFORE dehydration runs (`vendor/filament/schemas/src/Concerns/HasState.php::getState()` — `$this->validate()` first, `$this->dehydrateState()` after), so a `carrierRule` on the Hidden field was checking a blank/stale pre-edit date instead of the new year/month/day selection once the per-pick sync was removed — an over-cap deadline could silently save, or a valid one could be wrongly rejected on edit. Fixed by mirroring the same assembly closure into `mutateStateForValidationUsing`, so ANY consumer passing a `carrierRule` gets the correct value at validation time too, not just at dehydration.
2. **`ReservationFormPresenter::isRangeState()` read the assembled bare `{prefix}_date` field reactively** (gating `isFullDay`'s disabled-state AND `isRecurring`/`recurCount`/`recurPattern`'s visible/required-state) — since that bare field is now only ever populated at save time, `isRangeState()` read as permanently empty throughout the whole editing session, breaking all four fields' reactive UI logic (functionally, not just "stale" — it never updated at all pre-save). Fixed by rewriting `isRangeState()` to read `{prefix}_year`/`{prefix}_month`/`{prefix}_day` directly and call `PersianDateFieldService::assemble()` itself, rather than trusting the bare assembled field — this still only refreshes on a `month` pick (the only live-triggering field), same inherent Filament limitation as everywhere else, but is now CORRECT on the round-trips that do happen instead of permanently stale.

3. **`ProfileFormPresenter::skills()`'s `last_used_at` silently stopped saving** — found by an independent Fable-5 regression pass, not the original review, since it's a different call path than the other two: the `skills` Repeater's `saveRelationshipsUsing` reads `$component->getState()` directly (raw Livewire state, the field-level path — `vendor/filament/schemas/src/Components/Concerns/HasState.php` — which never runs `dehydrateStateUsing`, unlike the schema-level Repeater save path other date-bearing repeaters on this form use, e.g. `details()`'s `value_date`, which stays correct). `$item['last_used_at']` was reading the bare hidden field's raw value, which the old per-pick `afterStateUpdated` used to keep in sync via `$set()` — now that assembly only happens at dehydration, that raw key is never written during interaction, so every skill saved with `last_used_at = null` regardless of what was picked. Fixed the same way as Reservation's `isRangeState()`: assemble from `$item['last_used_at_year']`/`_month`/`_day` directly in `saveRelationshipsUsing` instead of trusting the bare item key.

**Rule for any future consumer:** if a `carrierRule`, ANY other field's `visible`/`disabled`/`required` closure elsewhere in the same form, or a `saveRelationshipsUsing`/raw `$component->getState()` read on a Repeater embedding this service, needs this component's assembled date value — during live interaction OR at a save path that bypasses schema-level dehydration — read the underlying `{prefix}_year`/`{prefix}_month`/`{prefix}_day` fields directly via `PersianDateFieldService::assemble()` — never the bare `{prefix}` field, which is dehydration/validation-time-only now. Swept all 15 consumers at fix-time (Reservation, Task) plus an independent Fable-5 pass after (Profile skills); no other consumer has this pattern.

**`dehydrateStateUsing`/`mutateStateForValidationUsing` guard against wiping an untouched existing value:** both now share one `$assembleOrKeep` closure that returns the Hidden field's current `$state` unchanged when year/month/day are ALL blank (rather than assembling `null` from three empty values and overwriting whatever was hydrated) — otherwise editing a record without touching this date field at all would blank it out on save. This also guards carrier-direct writes: without the fallback, ANY writer that sets the bare field directly (Filament's test `fillForm(['deadline_date' => ...])`, or any code path writing the carrier without the selects) got silently clobbered to `null` at BOTH validation and dehydration, disabling `carrierRule` checks. That exact regression was caught by `TaskResourceTest::test_create_task_rejects_deadline_past_project_cap` (fillForm sets the bare `deadline_date` only) — that test family is the standing guard for carrier-direct-write semantics.

**Day-clamp on month change (same fix, same day):** picking day 31 then switching month to a 30-(or 29-)day month used to leave the day selector showing an invalid "31" — `Jalalian::fromFormat` does NOT throw for this (empirically verified: `Jalalian::fromFormat('Y/m/d', '1403/07/31')` silently rolls over to `1403-08-01`, no exception, in both the old per-pick-assemble code and the new save-time-assemble code — a claim that this became a save-time crash was checked and found false), it silently produces the WRONG date one month later than intended. Pre-existing bug, not something today's `->live()` change introduced or worsened — fixed anyway since it's free: `monthSelect()`'s `afterStateUpdated` (already firing on every month pick) now clamps `{prefix}_day` down to `daysInMonth($newMonth)` if it exceeds it.

**Why none of this was caught by the existing test suite (a real gap, not fixed here — flagged for the next test pass):** `TaskResourceTest`'s `ProjectDeadlineCap` tests either set the bare `deadline_date` key directly via `fillForm` (bypassing the year/month/day selects entirely, so the bug path never executes) or omit `project_id` on the year/month/day-based case (so the cap rule short-circuits before it would even notice a wrong date). Reservation's `isRangeState()`-driven reactive UI state (the `isFullDay`/`isRecurring` disable/visible logic) has no test coverage at all. Both are the same root cause: Filament resource tests conventionally use `fillForm([...])` to set the WHOLE form state in one shot, which never exercises the actual multi-step "pick month, THEN pick day" interaction sequence a real admin performs — the exact sequence that both bugs (and the original 3-round-trip performance issue) only manifest through. A future test for either bug needs to `set()` the `_year`/`_month`/`_day` sub-fields individually (not the bare `fillForm(['deadline_date' => ...])` shortcut) to actually exercise the live-interaction path.

## Post-fix sweep — the `->live()`-with-no-consumer bug recurs elsewhere (2026-09-23)

After the `PersianDateFieldService` fix above, a 4-way parallel audit (form round-trips, page lifecycle hooks, table/RelationManager N+1, app-wide DB-hostile patterns) plus a manual review found the same bug class in **6 more places**, all fixed the same way — remove `->live()`, confirmed zero downstream `$get()` consumer in each case before touching:

- `ThsResource\Schemas\TicketFormPresenter::requestArea()` — terminal field of a 3-level cascade (`targetDepartment` → `requestType` → `requestArea`), nothing reads its value.
- `EventResource\Schemas\EventFormPresenter::countdownMood()` and `countdownConfetti()` — both live, nothing reads `mood`/`confetti`; only the sibling `countdownEnabled()` toggle is a real dependency.
- `LinkResource\Schemas\LinkFormPresenter::linkType()` — nothing reads `$get('link')`.
- `DepartmentResource\Schemas\DepartmentFormPresenter::level()` — its own `options()` reads `subordinate_to`, not `level`; nothing reads `level` itself.
- `OnboardingResource\Schemas\OnboardingFormPresenter::guides()`'s `FileUpload::make('url')` — no consumer; Livewire's own upload mechanism doesn't need field-level `->live()`.
- `ReservationResource\Schemas\ReservationFormPresenter::cancelReason()` — its own `visible()` correctly depends on `status`, but nothing depends on `cancel_reason` itself.

**Separately, an unrelated guaranteed-fatal bug was found and fixed in the same sweep:** both `ResourceResource` and `UserResource`'s `ReservationsRelationManager::form()` called three `ReservationFormPresenter` methods that no longer exist — `fullDayDate()`, `startTime()`, `endTime()` — leftover from before the reservation-wide migration to `PersianDateFieldService` (see `reservationPattern.md`'s "Admin form date handling" section). Opening the "create" table action on either RelationManager was a guaranteed PHP fatal error. First remapped to the real field set as a stopgap, then resolved the same day the ERP-native way: **both RMs now declare `protected static ?string $relatedResource = ReservationResource::class;` and their `form()`/`infolist()` overrides are deleted.** Filament's `RelationManager::getDefaultActionUrl()` turns their Edit table action into a plain URL link to the real `EditReservation` page (where `FilamentDateHandler` runs; no CreateAction exists on either RM table), and the ViewAction (no `view` page exists) stays a modal but renders `ReservationResource`'s own form/infolist through vendor delegation (`InteractsWithRelationshipTable::form()`/`infolist()` call `ReservationResource::form()/infolist()` when `$relatedResource` is set) — so no RM-level schema duplication remains to drift again. Both RM tables also carry `->toolbarActions([])` (user decision 2026-09-24): the delegation would otherwise inherit ReservationResource's bulk delete/exporter, which belongs on the main reservations table only — the RM `table()` runs after `$relatedResource::configureTable()`, so the empty-array override wins; the tabs stay plain list/edit tabs. The RMs' redundant `getModelLabel()`/`getPluralModelLabel()` overrides (identical to what delegation supplies) are deleted; each keeps its distinct `getTitle()`. This is the ERP norm for related-record surfaces: a modal must never present fields it cannot persist — the duplicated RM form couldn't hydrate the `{field}_date`/`{field}_time` parts on edit (`EditAction` fills from `$record->attributesToArray()`, and those keys aren't record attributes) and silently dropped them on save (not fillable), so an admin could "edit" dates that never saved while the required hidden carrier blocked other saves. Regression tests: `ResourceResourceTest`/`UserResourceTest` `test_reservations_relation_manager_edit_navigates_to_the_full_reservation_edit_page` asserting the edit action's URL via `assertTableActionHasUrl` — the old `mountTableAction('create')` smoke test was silently vacuous (`mountAction()` swallows a non-resolvable action with a null return, so it passed even when the action never existed and even while the form fataled). **Gotcha for future date-field refactors:** grep for every static-method call site across `Pages/`, `RelationManagers/`, and `Schemas/` in every resource before renaming/removing a `*FormPresenter` method — a `RelationManager` reusing the same presenter is easy to miss since it lives in a different resource's directory tree, and unlike the main resource form, nothing exercises it until an admin actually opens that tab.

**Findings surfaced above — resolved 2026-09-23, one per-issue, all reviewed by an independent Fable-5 pass:**

1. **`ReservationFormPresenter::parentId()`** — was `Reservation::roots()->with(['resource','user'])->get()`, unbounded, re-running on every live field. Fixed with Filament's native async search instead of a flat row cap: `->getSearchResultsUsing()` (matches by id prefix, resource name, or user name — NOT the decorated `resource_dropdown_label` string, which has emoji/Jalali-date noise no SQL `LIKE` could match — `latest('start_time')->limit(50)`) + `->getOptionLabelUsing()` (resolves a single saved id back to its label so an Edit form pre-fills correctly without first typing a search term). Zero eager load, zero cache, admins can still reach any reservation by typing instead of scrolling a capped list.
2. **`HasTicketOptions::getCustomAdminAreaLabelHtml()`** — was `Blade::render()` (a real Blade compile) per option, ~15 times per render. `<x-icon>` in this app resolves to `blade-ui-kit/blade-icons`' generic `Icon` component (`BladeUI\Icons\Components\Icon`, confirmed via vendor source — **not** Filament's own `generate_icon_html()`, a claim that was checked and found wrong before implementing), which itself just calls the global `svg($name, $class, $attributes)` helper. Replaced the whole `Blade::render()` call with a direct `svg($icon, $class)->toHtml()` + plain string concatenation — identical output, zero Blade compiles, `Blade` facade import removed (last use in the file).
3. **`TicketFormPresenter::assignedTo()`** — uncached department-scoped query on a form with 5 live fields. Fixed by adding `User::getCachedDepartmentOptions(string $dept)` mirroring `getCachedAllOptions()`'s existing pattern, keyed `"user_dept_options:{$dept}"` (parameterized per `modelPattern.md` rule 5). **Invalidation completed same day:** the cache's write path lives on `Profile` (`department_id`), which `User`'s own `booted()` gate never sees — `Profile::booted()` now bumps `ModelCacheVersion::bump(User::class)` on `wasChanged('department_id')` (creation included — `getChanges()` contains the attribute on insert) and on `deleting` (a deleted profile removes the user from the dept list), guarded by `UserModelTest::test_moving_a_profile_between_departments_invalidates_cached_department_options`.
4. **`ProjectTablePresenter::progress()`** — was `getStateUsing` calling `ReportingService::summary()` per row (up to 4 queries × visible rows on a cache-cold load). Fixed by adding a third `withCount(['tasks as done_tasks_count' => ...->where('status','done')])` alongside `ProjectResource`'s existing `withCount('tasks')`/`overdue_tasks_count`, then deriving percent inline (`done_tasks_count / tasks_count * 100`, same `round(...,1)` + zero-task guard as the original `summary()` formula) — zero queries per row, whether the column is shown or hidden, and the `ReportingService` import/call is gone from this file entirely (the service's own cached `summary()` method is untouched — still used elsewhere, e.g. `TasksRelationManager`).
5. **`LinkFormPresenter::internalUrl()`** — was `->live()` (per-keystroke round trip); its only consumer, `companyIps()`'s `visible()`, doesn't need pre-blur reactivity. Changed to `->live(onBlur: true)` — one round trip per edit instead of one per few characters typed.
6. **`UserFormPresenter`'s booking-toggle repeater** — no minimal fix exists (a client-side rewrite would need to reimplement Filament's entangled Toggle state from the DOM); left as-is, each toggle still round-trips, which is a genuine dependency (the "all" toggle needs bidirectional sync), not the zero-payoff bug class.
7. **`ProfileFormPresenter`'s `details.key` select** — legitimately `->live()` (correct, not touched), but re-hydrates the panel's heaviest form (5 repeaters) on every pick. Fixed the actual cost instead of the liveness: added `->collapsed()` to the four SIBLING repeaters (`about_me()`, `attachments()`, `favorite_colors()`, `skills()`) — `details()` itself deliberately left uncollapsed (it's the one being edited). A collapsed repeater item skips rendering its child form entirely and renders only its header row, so a `details.key` round trip now re-renders four header rows instead of four full repeater bodies. No change to validation/hydration/save — Filament still computes and hydrates collapsed items' state, it just doesn't render them open.
8. **`SkillTablePresenter::categoryFilter()`** — was an uncached full-table `DISTINCT` pluck on every filter-panel render. Added `Skill::cachedCategoryFilter()` mirroring the file's own existing `cachedActiveCatalog()` pattern (direct `Cache::remember(ModelCacheVersion::key(...))`, not the `HasModelCache` trait, to match this specific file's established style) — `now()->addDay()` TTL, Tier V (auto-invalidates on any `Skill` save/delete).
9. **`Photo::allDepartmentModels()` / `Report::audienceDepartments()`** — both re-computed 3-4× per table row by separate column closures (`color()`, `icon()`, `getStateUsing()`, `tooltip()`). Added `->shouldCache()` to both `Attribute::make(...)` accessors, matching sibling accessors already doing this in the same files — per-instance memoization, safe since nothing mutates `departments`/`all_departments` mid-request in either model's write paths.
10. **`NudgeService::reconcile()` / `EdgeService::reconcile()`** — both had a per-recipient `create()` inside a `foreach` over potentially every active employee (a broadcast trigger like `Post`/`Feed`/`Ad` fires for `User::active()->get()`). Fixed by accumulating genuinely-new rows into an array and writing them with a bulk `insert()` after the loop (chunked in 500s since 2026-10-25, with one shared notification payload per distinct title/body and one bulk delete for rows that stop qualifying — `statePattern.md` "Payload sharing") — mirroring the pattern `BadgeSyncService::syncBatch()` already uses for this exact table (`app/Services/Menu/statePattern.md` documents both). **Non-obvious wiring requirement, easy to miss:** raw `insert()` bypasses Eloquent's `saved` event, which is what normally bumps `DatabaseNotification`'s Tier-V cache backing `UnreadNotifications`'s per-user `unread_menu_groups:{userId}` badge count (`modelPattern.md` rule 6: "bulk/raw writes ⇒ one manual `bump()`") — without an explicit `ModelCacheVersion::bump(DatabaseNotification::class)` after the insert, every recipient's unread badge would sit stale for the full 15-minute TTL after any broadcast nudge. `EdgeService`'s bulk insert needs no such bump — verified no cache anywhere is keyed on `Edge`. Full detail in `statePattern.md`.

## Admin panel loading indicator — do not hand-roll one

The admin panel's global page loader is `resources/views/components/ui/loaders/page-transition.blade.php`, wired into `app/Providers/FilamentServiceProvider.php`'s `PanelsRenderHook::BODY_END` hook — a `.global-app-loader` fixed overlay wrapping `<x-ui.loaders.spin-badge>`. Full rule set (including the one deliberate exception for non-Livewire Alpine/`fetch()`-driven action buttons) lives in `resources/views/components/ui/loaders/loadingPattern.md`. **Grep for `view('components.ui.loaders...` (a PHP-side `view()` call, not a Blade `x-ui.loaders.*` tag) before deleting or renaming any shared loader component** — a PHP-side render-hook consumer like this one won't show up in a Blade-only grep, and missing it caused a full admin-panel outage on 2026-08-24 when `spinner.blade.php` was deleted without checking `FilamentServiceProvider.php` first.

## Admin parity for Task / Project / Ths comes from model hooks, not Filament rules (2026-10-09)

The admin panel inherits the user-panel rulebook through `Task::booted`, `TaskDetail`, `Project::booted` and `Ticket::saving/saved`; never copy those rules into a form or an Action.

1. **Writes:** `TaskResource\Pages\CreateTask` and `ProjectResource\RelationManagers\TasksRelationManager` use `App\Traits\Filament\PreparesAdminTaskCreate` (`prepareTaskCreate` = roster check via `TaskAccessPolicy::assertAssignable`, project labels vocabulary, SLA default deadline, `rank`; `ensureTaskDetail` = detail row + the project's single default department). A done task without a state is still blocked (`doneRequiresState`) and the state of an already-done task is locked.
2. **Fields:** assignee/accountable/collaborator selects are narrowed to the chosen project's `charter()->rosterIds()` (already-selected legacy people stay pinned); labels are validated against the project vocabulary (`TaskFormPresenter::labelsInVocabulary`); `ProjectDeadlineCap` takes the current deadline so an unchanged over-cap deadline stays editable; the task creator is locked on edit; creator/requester/assignee selects list only `visibleOnBoard()` users; the project form has `settings.labels` (TagsInput, normalized), `settings.auto_archive_days` and an owner default of the logged-in admin; extra setting keys share `ProjectForm::extraKeyRules()`.
3. **Locks:** rows with a `ticket_id` hide Edit/Delete and are skipped by the bulk delete (task mirror of a ticket; `Task::restoring` also refuses restoring one outside `Task::syncingFromTicket`); a closed ticket cannot be reopened or reassigned; `Ticket::assignableUsers()` feeds the assignee select (the legacy assignee stays visible); status «open» clears the assignee in the form. `EditTicket::afterSave` and the Tickets relation manager no longer call `AssignTicketAction` — the `Ticket::saved` hook does.
4. **Permissions:** Filament record actions that mutate (task `approve`, workflow force-advance / reassign-step / cancel / apply-template) require the resource's `update` permission (`static::permits('update')` / `ProjectResource::canEdit($record)`); a view-only admin sees none of them. Project owner transfer happens in the form (`owner_id`) and is validated by `Project::saving`; a force-advance/reassign in the project's cycle table (`FilamentWorkflowPresenter`) works even when the owner is gone.
5. **Numbers:** every admin overdue/at-risk figure (ProjectResource count, TaskResource filters and stats, `ModuleAnalyticsWidget`, `OperationalChart`) is `TaskMetrics::overdue/active` — never a hand-written `deadline < now()`; `OperationalChart` also counts only active users.
6. **Ths/Tasksheet:** the user-record «share tasksheet» actions resolve the recipient with `TasksheetShareService::managerFor`.

## Reservation admin fields and Jalali parity (2026-10-19)

- `ReservationPolicyResource` form/infolist gained `last_minute_hours` (1–720, must exceed `window_hours`, empty = off) and `cancel_window_days` (1–365, empty = 30) next to `max_cancel_count` (0 allowed = users cannot cancel). `TypeProvisioner` seeds both (21 rows per type — `ResourceResourceTest` pins the count).
- `UserResource` booking repeater rows are `{key, value, max}`: «همه» (`all`) sets a default cap for every type, a type row overrides it; the `max` input is hidden unless the row is enabled (Get/Set with `'../'`); `User::bookingRows()/bookingMax()` read the raw JSON, `booking()` stays the flat key=>bool accessor used by permission checks.
- Admin create/edit/series reservations flow through the same `ValidationService` pipeline, so they follow the Jalali monthly quota; admin edits skip the cap (`skip_admin`).
- `ProjectFormPresenter` deadline `DatePicker` now follows the same `persian_dates` toggle as `jalaliDateRangeFilter` (`->when($persian, jalali(), native(false))`); the stored value is still a Gregorian `Y-m-d`.
- Wording: use «ماه شمسی» for the quota month and «N روز اخیر» for rolling windows (see `viewPattern.md` §8.36–8.37).

## Correspondence admin (2026-11-09)

Module contract: `app/Livewire/Dashboard/Correspondence/correspondencePattern.md` (§13 is the admin side). Letters are made, edited, signed and sent only in the user panel.

- **`CorrespondenceResource` is read-only** (the AiReportResource shape): `canCreate()` false, pages `index` + `view`, record action = view only (no edit/delete/bulk), query `select(Correspondence::ADMIN_COLUMNS)` + `with('user:id,name')` — never `spec/versions/events/parties/search_text/meta` in the list. The view page reads the full row and renders: header fields, a parties/delivery list (outside people: delivery mode, sent, first opened, errors, derived «ارسال دستی / بدون ایمیل» tag), a plain-sentence timeline (one lang line per event action, generic fallback `admin.events_generic`), version list with the author of each version, and the paper preview (`paper.blade.php` included through `View::make`, screen mode) shown ONLY for `normal` classification. Confidential/secret letters show `admin.masked` instead of the subject, and the timeline masks comment text and reject reasons; numbers, statuses, people and dates stay visible for monitoring. Filters: status, type, direction, template, stale drafts (`created_at` older than `stale_draft_days`, templates excluded), created-at. The secondary columns (direction, classification, urgency, route, sign mode, sender category, sent, approved, awaiting) are toggled-hidden by default. Switch group with the letterhead page via `FilamentResourceSwitch::switchGroup()`; `LetterheadResource::shouldRegisterNavigation()` hides its own nav item when the letters resource is visible.
- **Knowledge admin entry (2026-11-21).** One sidebar item «دانش سازمانی» (Report + Media + KnowledgeProgress, with AiReport as a fourth switch button): `ReportResource::knowledgeEntry()` picks the first reachable resource, `shouldRegisterNavigation()` on the three is `knowledgeEntry() === static::class`, `getNavigationLabel()` is `resources/report/strings.nav_label`; every list page prepends `ReportResource::switchActions(...)` so the admin flips between the tables from the loaded page. Permissions are the existing `AuthorizesByPermission` module keys `report`, `media`, `knowledge_progress`, `ai_report` (the permission matrix lists them automatically; `lang/fa/resources/knowledge_progress/strings.php` exists only so the matrix shows a Persian label — flush `Permission::availableModules()`'s `permission_modules` cache after deploy). The dashboard analytics widget has a permission-gated `media` tab (`widgetsPattern.md`).
- **`LetterheadResource`** has full `ListLetterheads` / `CreateLetterhead` / `EditLetterhead` pages (the form is too large for a modal; slug `correspondence-letterheads`; the list prepends the `switchGroup()` buttons; `FilamentModelRuleNotice` turns a model-hook `ValidationException` from delete into a danger toast, and the base `CreateRecord`/`EditRecord` already do it for saves) with `LetterheadFormPresenter`/`LetterheadTablePresenter`: kind (head | registry — a registry row shows only name/size/lang/numbering), parent (root heads only, same kind), pattern (regex requires `{SEQ}`/`{SEQ:n}`, only known tokens) with a live next-number preview, `config.prefix` (the `{PREFIX}` value, letters/digits/`-_/`, root only), `start_at` with the «ادامه از آخرین» suffix action, borrow header/footer selects (`config.header_from|footer_from`: active head letterheads that themselves borrow nothing; the matching image upload hides while a borrow is chosen), images on the PUBLIC disk (`letterheads/`, ≤`ai.correspondence.upload.image_kb`, ≤`image_max_width` px, `FileNamer::stored('letterhead', …)`), margins (reset to the size's defaults when the size changes), style, fields box, config groups (`dehydrateStateUsing` keeps numbers numeric), sender block, sign layout, page numbers, active toggle. Model hooks enforce every rule again (see `modelPattern.md`), so a crafted payload cannot bypass the form. Delete is blocked while letters (trashed included), children or borrowers exist — deactivate instead; a borrowed letterhead cannot be deactivated or change kind.
- **User form section «مکاتبات: امضا و دسترسی دبیرخانه»** (`UserResource::form`, visible on `edit` only and while `tenantOffName('correspondence')` is false): `UserFormPresenter::signature()` (private `local` disk, `users/signatures/`, image types, size/width caps from `ai.correspondence.upload.*`, `FileNamer::stored('signature', …)`), `signCode()` (password input, min length from config, max 72, hashed in `dehydrateStateUsing`, blank = unchanged, «حذف کد» toggle only when a code exists), `signCodePassword()` (`current_password:web` — the ADMIN's own password, required when a code is set or cleared, never stored) and `registryPermission()` toggle («مسئول ثبت نامه‌های دریافتی» — lets the user register/route incoming letters and run the wet-sign print steps in the user panel). They are virtual fields: `EditUser::mutateFormDataBeforeFill` puts `signature_image`/`registry_permission` into the form from the admin bucket, `mutateFormDataBeforeSave` folds the four virtual fields back into `extra.admin.{signature,sign_code_hash,correspondence_registry}` (the stored value for an unchanged signature, `trustedSignature()` re-validates a new path: under `users/signatures/`, image extension, file exists, not used by another user), and `afterSave` deletes the replaced signature file after commit.
- **`extra` merge.** Those three keys are `User::PROTECTED_ADMIN_KEYS`: the `extra()` KeyValue field hydrates `User::editableExtraOf()` and its `dehydrateStateUsing` re-attaches the stored protected values (and strips any posted attempt to set them), so editing free-form notes can never wipe or leak a signature path, a code hash or the registry flag; the infolist shows `editableExtra()` only. Nobody — admin included — can read a sign code or its hash.
- **Module locks (2026-11-12).** Every resource page base (`ListRecords`/`EditRecord`/`ViewRecord`/`CreateRecord`), `RelationManager` and `ListNotifyLogs` use `GuardsModuleLock`; a new custom page that reads a lockable module's data must use it too. `ManageLocks` (holders only, 404 otherwise) and `UnlockModules` are plain Filament pages with no custom Blade: `ManageLocks` is `content()` + `EmbeddedTable`, `UnlockModules` is a `Section` plus a header action. See `app/Services/Lock/lockPattern.md`.
