<?php

namespace App\Filament\Widgets;

use App\Enums\PresenceStatus;
use App\Enums\ReleaseRequestStatus;
use App\Enums\ReleaseRequestType;
use App\Enums\ReservationStatus;
use App\Enums\SkillRequestStatus;
use App\Enums\UserType;
use App\Filament\Resources\MediaResource;
use App\Livewire\Dashboard\AiReport\Presentation\AiReportPresenter;
use App\Models\Department;
use App\Models\NotifyRule;
use App\Models\User;
use App\Services\ProjectTask\TaskMetrics;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Concerns\InteractsWithSchemas;
use Filament\Schemas\Contracts\HasSchemas;
use Filament\Schemas\Schema;
use Filament\Widgets\StatsOverviewWidget\Stat;
use Filament\Widgets\Widget;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\HtmlString;
use Livewire\Attributes\Computed;

class ModuleAnalyticsWidget extends Widget implements HasSchemas
{
    use InteractsWithSchemas;

    protected static bool $isLazy = true;
    protected static ?int $sort = -1;
    private const TAB_MODULES = ['events' => 'calendar', 'resources' => 'reservation', 'reservation_policies' => 'reservation', 'ai_reports' => 'ai-report', 'media' => 'knowledge:media'];

    public string $activeTab = 'users';
    protected string $view = 'livewire.admin.widgets.filament-analytics';
    protected int|string|array $columnSpan = 'full';

    #[Computed(seconds: 300, cache: true)]
    public function adsData(): array
    {
        $stats = DB::table('ads')->selectRaw("
            COUNT(*) as total,
            COUNT(CASE WHEN active = 1 THEN 1 END) as active,
            COUNT(CASE WHEN gender = 'Male' THEN 1 END) as males,
            COUNT(CASE WHEN gender = 'Female' THEN 1 END) as females,
            COUNT(CASE WHEN gender = 'Any' OR gender IS NULL THEN 1 END) as both_gender
        ")->first();

        return [
            Stat::make('کل آگهی‌ها', $stats->total)
                ->icon('heroicon-o-megaphone')
                ->color('primary'),
            Stat::make('آگهی‌های فعال', $stats->active)
                ->icon('heroicon-o-check')
                ->color('success'),
            Stat::make('آقایان / خانم‌ها', (int) $stats->males . ' ┆ ' . (int) $stats->females)
                ->icon('heroicon-o-user')
                ->color('info'),
            Stat::make('بدون محدودیت جنسیت', $stats->both_gender)
                ->icon('heroicon-o-users')
                ->color('gray'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function aiReportsData(): array
    {
        $today = now()->startOfDay();
        $week = now()->subDays(7);
        $stats = DB::table('ai_reports')->selectRaw("
            COUNT(*) as total,
            COUNT(CASE WHEN status = 'ready' THEN 1 END) as ready,
            COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed,
            COALESCE(SUM(tokens_total), 0) as tokens,
            COUNT(CASE WHEN created_at >= ? THEN 1 END) as today,
            COALESCE(SUM(CASE WHEN created_at >= ? THEN tokens_total END), 0) as tokens_today,
            COALESCE(SUM(CASE WHEN created_at >= ? THEN tokens_total END), 0) as tokens_week
        ", [$today, $today, $week])->first();
        $topFail = DB::table('ai_reports')
            ->where('status', 'failed')
            ->where('created_at', '>=', $week)
            ->whereNotNull('fail_reason')
            ->selectRaw('fail_reason, COUNT(*) as n')
            ->groupBy('fail_reason')
            ->orderByDesc('n')
            ->first();
        $topUser = DB::table('ai_reports')
            ->join('users', 'users.id', '=', 'ai_reports.user_id')
            ->where('users.type', '!=', UserType::Guest->value)
            ->where('ai_reports.created_at', '>=', $week)
            ->selectRaw('users.name, COALESCE(SUM(ai_reports.tokens_total), 0) as tokens')
            ->groupBy('users.id', 'users.name')
            ->orderByDesc('tokens')
            ->first();
        $s = fn (string $key): string => __('resources/ai_report/strings.stats.' . $key);

        return [
            Stat::make(__('resources/ai_report/strings.plural_label'), $stats->total)
                ->description($s('today') . ': ' . $stats->today)
                ->icon('heroicon-o-document-chart-bar')
                ->color('primary'),
            Stat::make(__('resources/ai_report/strings.statuses.ready'), $stats->ready)
                ->icon('heroicon-o-check-circle')
                ->color('success'),
            Stat::make(__('resources/ai_report/strings.statuses.failed'), $stats->failed)
                ->description($topFail ? (new AiReportPresenter)->failReason($topFail->fail_reason) . ' ×' . $topFail->n : null)
                ->icon('heroicon-o-x-circle')
                ->color('danger'),
            Stat::make(__('resources/ai_report/strings.fields.tokens_total'), $stats->tokens)
                ->description($s('today') . ' ' . $stats->tokens_today . ' · ' . $s('week') . ' ' . $stats->tokens_week)
                ->icon('heroicon-o-cpu-chip')
                ->color('info'),
            Stat::make($s('top_user'), $topUser?->name ?? '—')
                ->description($topUser ? $topUser->tokens . ' ' . $s('tokens_week') : null)
                ->icon('heroicon-o-user')
                ->color('warning'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function authoritiesData(): array
    {
        $stats = DB::table('authorities')->selectRaw("
            COUNT(*) as total,
            COUNT(DISTINCT department_id) as depts_with_authorities,
            SUM(CASE WHEN sub_duty = 1 THEN 1 ELSE 0 END) as sub_duties
        ")->first();

        return [
            Stat::make(__('resources/authority/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-shield-check')
                ->color('primary'),
            Stat::make(__('resources/department/strings.plural_label'), $stats->depts_with_authorities)
                ->icon('heroicon-o-building-office')
                ->color('info'),
            Stat::make(__('resources/authority/strings.fields.sub_duty'), $stats->sub_duties)
                ->icon('heroicon-o-queue-list')
                ->color('gray'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function channelsData(): array
    {
        $stats = DB::table('channels')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN type = 'open' THEN 1 ELSE 0 END) as open,
            SUM(CASE WHEN type = 'private' THEN 1 ELSE 0 END) as private
        ")->whereNull('deleted_at')->first();

        $messagesCount = DB::table('channel_messages')->whereNull('deleted_at')->count();

        return [
            Stat::make(__('resources/channel/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-chat-bubble-left-right')
                ->color('primary'),
            Stat::make(__('resources/channel/strings.fields.type'), (int) $stats->open . ' ┆ ' . (int) $stats->private)
                ->icon('heroicon-o-globe-alt')
                ->color('info'),
            Stat::make(__('resources/channel/strings.fields.messages_count'), $messagesCount)
                ->icon('heroicon-o-chat-bubble-left-ellipsis')
                ->color('success'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function contactsData(): array
    {
        $stats = DB::table('messages')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN read_at IS NULL THEN 1 ELSE 0 END) as unread,
            SUM(CASE WHEN reply_to_id IS NOT NULL THEN 1 ELSE 0 END) as replies
        ")->whereNull('deleted_at')->first();


        return [
            Stat::make(__('resources/contact/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-chat-bubble-left-ellipsis')
                ->color('primary'),
            Stat::make(__('resources/contact/strings.fields.unread'), $stats->unread)
                ->icon('heroicon-o-envelope')
                ->color('warning'),
            Stat::make(__('resources/contact/strings.fields.has_reply'), $stats->replies)
                ->icon('heroicon-o-arrow-uturn-left')
                ->color('info'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function credentialsData(): array
    {
        $stats = DB::table('credentials')->selectRaw("
            COUNT(*) as total,
            COUNT(DISTINCT app_name) as apps,
            SUM(CASE WHEN link IS NOT NULL THEN 1 ELSE 0 END) as with_links
        ")->first();

        return [
            Stat::make(__('resources/credential/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-key')
                ->color('primary'),
            Stat::make(__('resources/credential/strings.fields.app_name'), $stats->apps)
                ->icon('heroicon-o-computer-desktop')
                ->color('info'),
            Stat::make(__('resources/credential/strings.filters.has_link'), $stats->with_links)
                ->icon('heroicon-o-link')
                ->color('gray'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function departmentsData(): array
    {
        $ranked = Department::withCount('currentUsers as users_count')
            ->orderByDesc('users_count')->orderBy('code')->get();
        $total = $ranked->count();
        $withUsers = $ranked->where('users_count', '>', 0)->count();
        $mostDense = $ranked->first(fn ($department) => $department->users_count > 0)?->displayLabel() ?? __('resources/dashboard/strings.analytics.departments.unknown');

        return [
            Stat::make(__('resources/dashboard/strings.analytics.departments.total'), $total)
                ->icon('heroicon-o-building-office')
                ->color('primary'),
            Stat::make(__('resources/dashboard/strings.analytics.departments.with_users'), $withUsers)
                ->icon('heroicon-o-user-group')
                ->color('success'),
            Stat::make(
                __('resources/dashboard/strings.analytics.departments.most_dense'),
                new HtmlString("
                            <div class='text-[14px] sm:text-md font-medium tracking-tighter flex items-center gap-1'>
                                 <span>{$mostDense}</span>
                            </div>
                    "))
                ->icon('heroicon-o-chart-bar')
                ->color('warning'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function dmsData(): array
    {
        $stats = DB::table('dms')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN status = 'live' THEN 1 ELSE 0 END) as live,
            SUM(CASE WHEN status = 'under_review' THEN 1 ELSE 0 END) as under_review,
            SUM(combined_read_count) as total_reads
        ")->first();

        return [
            Stat::make(__('resources/dms/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-document-duplicate')
                ->color('primary'),
            Stat::make(__('resources/dms/strings.enums.status.live'), $stats->live)
                ->icon('heroicon-o-check-circle')
                ->color('success'),
            Stat::make(__('resources/dms/strings.enums.status.under_review'), $stats->under_review)
                ->icon('heroicon-o-clock')
                ->color('warning'),
            Stat::make(__('resources/dms/strings.fields.read_count'), $stats->total_reads ?? 0)
                ->icon('heroicon-o-eye')
                ->color('info'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function energyData(): array
    {
        $stats = DB::table('energy_tests')
            ->join('users', 'users.id', '=', 'energy_tests.user_id')
            ->where('users.type', '!=', UserType::Guest->value)
            ->selectRaw("
            COUNT(*) AS total,
            COALESCE(ROUND(AVG(overall_score), 1), 0) AS avg_overall,
            COALESCE(ROUND(AVG(mind_score), 1), 0) AS avg_mind,
            COALESCE(ROUND(AVG(emotion_score), 1), 0) AS avg_emotion,
            COALESCE(ROUND(AVG(physique_score), 1), 0) AS avg_physique,
            COALESCE(ROUND(AVG(soul_score), 1), 0) AS avg_soul,
            SUM(CASE WHEN overall_score >= 12 THEN 1 ELSE 0 END) AS high_risk_count,
            SUM(CASE WHEN completed_at >= ? THEN 1 ELSE 0 END) AS last_month_count
        ", [now()->subDays(30)])
            ->first();

        return [
            Stat::make(__('resources/energy/strings.stats.total'), $stats->total)
                ->icon('heroicon-o-bolt')
                ->color('primary'),

            Stat::make(__('resources/energy/strings.stats.avg_overall'), $stats->avg_overall)
                ->icon('heroicon-o-chart-bar')
                ->color($stats->avg_overall >= 12 ? 'danger' : ($stats->avg_overall > 8 ? 'warning' : 'success')),

            Stat::make(
                __('resources/energy/strings.stats.dimension_averages'),
                new HtmlString("
               <div class='text-[14px] sm:text-md font-medium tracking-tighter flex items-center gap-1'>
                    <span>🏋️ {$stats->avg_physique}</span>
                    <span class='text-gray-300'></span>
                    <span>❤️ {$stats->avg_emotion}</span>
                    <span class='text-gray-300'>|</span>
                    <span>🧠 {$stats->avg_mind}</span>
                    <span class='text-gray-300'>|</span>
                    <span>✨ {$stats->avg_soul}</span>
                </div>
            ")
            )
                ->icon('heroicon-o-squares-2x2')
                ->color('info'),

            Stat::make(__('resources/energy/strings.stats.low_scores'), $stats->high_risk_count)
                ->icon('heroicon-o-exclamation-triangle')
                ->color($stats->high_risk_count > 0 ? 'danger' : 'success')
                ->description(__('resources/energy/strings.stats.above_12')),

            Stat::make(__('resources/energy/strings.stats.last_month'), $stats->last_month_count)
                ->icon('heroicon-o-calendar')
                ->color('gray'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function eventsData(): array
    {
        $stats = DB::table('events')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN date >= CURRENT_DATE THEN 1 ELSE 0 END) as upcoming,
            SUM(CASE WHEN private = 1 THEN 1 ELSE 0 END) as private
        ")->first();

        return [
            Stat::make(__('resources/event/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-calendar-days')
                ->color('primary'),
            Stat::make(__('resources/event/strings.filters.upcoming'), $stats->upcoming)
                ->icon('heroicon-o-clock')
                ->color('success'),
            Stat::make(__('resources/event/strings.fields.private'), $stats->private)
                ->icon('heroicon-o-lock-closed')
                ->color('warning'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function faqsData(): array
    {
        $stats = DB::table('faqs')->selectRaw("
            COUNT(*) as total,
            COUNT(DISTINCT category) as categories,
            COUNT(DISTINCT department_id) as depts
        ")->first();

        return [
            Stat::make(__('resources/faq/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-question-mark-circle')
                ->color('primary'),
            Stat::make(__('resources/faq/strings.fields.category'), $stats->categories)
                ->icon('heroicon-o-tag')
                ->color('info'),
            Stat::make(__('resources/department/strings.plural_label'), $stats->depts)
                ->icon('heroicon-o-building-office')
                ->color('gray'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function feedsData(): array
    {
        $stats = DB::table('feeds')->selectRaw("
            COUNT(*) as total,
            COUNT(DISTINCT category) as categories,
            SUM(CASE WHEN media_paths IS NOT NULL AND JSON_LENGTH(media_paths) > 0 THEN 1 ELSE 0 END) as with_media
        ")->first();

        $reactionsCount = DB::table('reactions')->count();

        return [
            Stat::make(__('resources/feed/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-rss')
                ->color('primary'),
            Stat::make(__('resources/feed/strings.filters.has_media'), $stats->with_media)
                ->icon('heroicon-o-photo')
                ->color('info'),
            Stat::make(__('resources/feed/strings.fields.reactions_count'), $reactionsCount)
                ->icon('heroicon-o-heart')
                ->color('danger'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function galleriesData(): array
    {
        $stats = DB::table('photos')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN department_id IS NULL THEN 1 ELSE 0 END) as public_galleries,
            SUM(JSON_LENGTH(path)) as total_photos
        ")->first();

        return [
            Stat::make(__('resources/gallery/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-photo')
                ->color('primary'),
            Stat::make(__('resources/gallery/strings.fields.public_gallery'), $stats->public_galleries)
                ->icon('heroicon-o-globe-alt')
                ->color('info'),
            Stat::make(__('resources/gallery/strings.fields.count'), $stats->total_photos ?? 0)
                ->icon('heroicon-o-camera')
                ->color('success'),
        ];
    }

    public function getActiveStatsCount(): int
    {
        return match ($this->activeTab) {
            'users' => count($this->usersData),
            'departments' => count($this->departmentsData),
            'ads' => count($this->adsData),
            'ai_reports' => count($this->aiReportsData),
            'reports' => count($this->reportsData),
            'media' => count($this->mediaData),
            'energy' => count($this->energyData),
            'authorities' => count($this->authoritiesData),
            'channels' => count($this->channelsData),
            'contacts' => count($this->contactsData),
            'credentials' => count($this->credentialsData),
            'dms' => count($this->dmsData),
            'events' => count($this->eventsData),
            'faqs' => count($this->faqsData),
            'feeds' => count($this->feedsData),
            'galleries' => count($this->galleriesData),
            'links' => count($this->linksData),
            'notify' => count($this->notifyData),
            'onboardings' => count($this->onboardingsData),
            'permissions' => count($this->permissionsData),
            'posts' => count($this->postsData),
            'profiles' => count($this->profilesData),
            'projects' => count($this->projectsData),
            'reminders' => count($this->remindersData),
            'support' => count($this->releaseRequestsData),
            'reservation_policies' => count($this->reservationPoliciesData),
            'reservations' => count($this->reservationsData),
            'resources' => count($this->resourcesData),
            'skills' => count($this->skillsData),
            'suggestions' => count($this->suggestionsData),
            'tasks' => count($this->tasksData),
            'ths' => count($this->thsData),
            default => 0,
        };
    }

    #[Computed]
    public function getAllTabs(): array
    {
        $tabs = [
            'users' => ['icon' => 'heroicon-o-users', 'label' => __('resources/dashboard/strings.analytics.tabs.users')],
            'profiles' => ['icon' => 'heroicon-o-identification', 'label' => __('resources/profile/strings.navigation.plural')],
            'departments' => ['icon' => 'heroicon-o-building-office', 'label' => __('resources/department/strings.plural_label')],
            'authorities' => ['icon' => 'heroicon-o-shield-check', 'label' => __('resources/authority/strings.plural_label')],
            'credentials' => ['icon' => 'heroicon-o-key', 'label' => __('resources/credential/strings.plural_label')],
            'ads' => ['icon' => 'heroicon-o-megaphone', 'label' => __('resources/ad/strings.plural_label')],
            'ai_reports' => ['icon' => 'heroicon-o-document-chart-bar', 'label' => __('resources/ai_report/strings.plural_label')],
            'posts' => ['icon' => 'heroicon-o-document-text', 'label' => __('resources/post/strings.plural_label')],
            'reports' => ['icon' => 'heroicon-o-document-text', 'label' => __('resources/report/strings.plural_label')],
            'media' => ['icon' => 'heroicon-o-play-circle', 'label' => __('resources/media/strings.plural_label')],
            'events' => ['icon' => 'heroicon-o-calendar-days', 'label' => __('resources/event/strings.plural_label')],
            'suggestions' => ['icon' => 'heroicon-o-light-bulb', 'label' => __('resources/suggestion/strings.plural_label')],
            'tasks' => ['icon' => 'heroicon-o-clipboard-document-list', 'label' => __('resources/task/strings.plural_label')],
            'dms' => ['icon' => 'heroicon-o-document-duplicate', 'label' => __('resources/dms/strings.plural_label')],
            'energy' => ['icon' => 'heroicon-o-bolt', 'label' => __('resources/energy/strings.label')],
            'contacts' => ['icon' => 'heroicon-o-chat-bubble-left-ellipsis', 'label' => __('resources/contact/strings.plural_label')],
            'feeds' => ['icon' => 'heroicon-o-rss', 'label' => __('resources/feed/strings.plural_label')],
            'galleries' => ['icon' => 'heroicon-o-photo', 'label' => __('resources/gallery/strings.plural_label')],
            'links' => ['icon' => 'heroicon-o-link', 'label' => __('resources/link/strings.plural_label')],
            'notify' => ['icon' => 'heroicon-o-envelope', 'label' => __('resources/notify_rule/strings.plural_label')],
            'onboardings' => ['icon' => 'heroicon-o-academic-cap', 'label' => __('resources/onboarding/strings.plural_label')],
            'faqs' => ['icon' => 'heroicon-o-question-mark-circle', 'label' => __('resources/faq/strings.plural_label')],
            'ths' => ['icon' => 'heroicon-o-ticket', 'label' => __('resources/ths/strings.plural_label')],
            'channels' => ['icon' => 'heroicon-o-chat-bubble-left-right', 'label' => __('resources/channel/strings.plural_label')],
            'reservations' => ['icon' => 'heroicon-o-map-pin', 'label' => __('resources/reservation/strings.plural_label')],
            'resources' => ['icon' => 'heroicon-o-archive-box', 'label' => __('resources/resource/strings.plural_label')],
            'reservation_policies' => ['icon' => 'heroicon-o-adjustments-horizontal', 'label' => __('resources/policy/strings.plural_label')],
            'skills' => ['icon' => 'heroicon-o-sparkles', 'label' => __('resources/skill/strings.plural_label')],
            'reminders' => ['icon' => 'heroicon-o-bell-alert', 'label' => __('resources/reminder/strings.plural_label')],
            'support' => ['icon' => 'heroicon-o-lifebuoy', 'label' => __('resources/release_request/strings.plural_label')],
            'permissions' => ['icon' => 'heroicon-o-shield-check', 'label' => __('resources/permission/strings.plural_label')],
            'projects' => ['icon' => 'heroicon-o-rectangle-stack', 'label' => __('resources/project/strings.plural_label')],
        ];

        return array_filter(
            $tabs,
            fn (string $key) => ! tenantOff(self::TAB_MODULES[$key] ?? $key) && ($key !== 'media' || MediaResource::canViewAny()),
            ARRAY_FILTER_USE_KEY
        );
    }

    #[Computed(seconds: 300, cache: true)]
    public function linksData(): array
    {
        $stats = DB::table('links')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN link = 'internal' THEN 1 ELSE 0 END) as internal,
            SUM(CASE WHEN link = 'external' THEN 1 ELSE 0 END) as external,
            SUM(CASE WHEN extra IS NOT NULL AND JSON_LENGTH(extra) > 0 THEN 1 ELSE 0 END) as smart_routing
        ")->first();

        return [
            Stat::make(__('resources/link/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-link')
                ->color('primary'),
            Stat::make(__('resources/link/strings.fields.internal_url'), $stats->internal)
                ->icon('heroicon-o-arrow-down-tray')
                ->color('info'),
            Stat::make(__('resources/link/strings.fields.url'), $stats->external)
                ->icon('heroicon-o-arrow-up-right')
                ->color('warning'),
            Stat::make(__('resources/link/strings.fields.smart_routing'), $stats->smart_routing)
                ->icon('heroicon-o-cpu-chip')
                ->color('success'),
        ];
    }

    public function mount(): void
    {
        $this->activeTab = 'users';
    }

    #[Computed(seconds: 300, cache: true)]
    public function notifyData(): array
    {
        $rules = DB::table('notify_rules')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active,
            SUM(CASE WHEN JSON_CONTAINS(channels, '\"mail\"') THEN 1 ELSE 0 END) as mail,
            SUM(CASE WHEN JSON_CONTAINS(channels, '\"sms\"') THEN 1 ELSE 0 END) as sms
        ")->where('model', '!=', NotifyRule::ONE_OFF)->first();

        $logs = DB::table('notify_logs')->where('created_at', '>=', now()->subDay())->selectRaw("
            SUM(CASE WHEN status = 'sent' THEN count ELSE 0 END) as sent,
            SUM(CASE WHEN status = 'failed' THEN count ELSE 0 END) as failed
        ")->first();

        return [
            Stat::make(__('resources/notify_rule/strings.plural_label'), $rules->total ?? 0)
                ->description(__('resources/dashboard/strings.analytics.notify.active') . ': ' . ($rules->active ?? 0))
                ->icon('heroicon-o-envelope')
                ->color('primary'),
            Stat::make(__('resources/dashboard/strings.analytics.notify.sent'), $logs->sent ?? 0)
                ->icon('heroicon-o-check-circle')
                ->color('success'),
            Stat::make(__('resources/dashboard/strings.analytics.notify.failed'), $logs->failed ?? 0)
                ->icon('heroicon-o-exclamation-triangle')
                ->color(($logs->failed ?? 0) > 0 ? 'danger' : 'gray'),
            Stat::make(__('resources/dashboard/strings.analytics.notify.channels'), __('resources/dashboard/strings.analytics.notify.mail') . ' ' . ($rules->mail ?? 0) . ' · ' . __('resources/dashboard/strings.analytics.notify.sms') . ' ' . ($rules->sms ?? 0))
                ->icon('heroicon-o-paper-airplane')
                ->color('info'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function onboardingsData(): array
    {
        $stats = DB::table('onboardings')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active,
            SUM(CASE WHEN user_id IS NULL THEN 1 ELSE 0 END) as global_audience
        ")->first();

        return [
            Stat::make(__('resources/onboarding/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-academic-cap')
                ->color('primary'),
            Stat::make(__('resources/onboarding/strings.fields.is_active'), $stats->active)
                ->icon('heroicon-o-check-circle')
                ->color('success'),
            Stat::make(__('resources/onboarding/strings.fields.global_audience'), $stats->global_audience)
                ->icon('heroicon-o-globe-alt')
                ->color('info'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function permissionsData(): array
    {
        $stats = DB::table('permissions')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN is_super_admin = 1 THEN 1 ELSE 0 END) as super_admins,
            SUM(CASE WHEN abilities IS NOT NULL AND JSON_LENGTH(abilities) > 0 THEN 1 ELSE 0 END) as with_abilities,
            SUM(CASE WHEN excluded_modules IS NOT NULL AND JSON_LENGTH(excluded_modules) > 0 THEN 1 ELSE 0 END) as with_exclusions
        ")->first();

        return [
            Stat::make(__('resources/permission/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-shield-check')
                ->color('primary'),
            Stat::make(__('resources/permission/strings.fields.is_super_admin'), $stats->super_admins)
                ->icon('heroicon-o-star')
                ->color('warning'),
            Stat::make(__('resources/dashboard/strings.analytics.permissions.with_abilities'), $stats->with_abilities)
                ->icon('heroicon-o-check-badge')
                ->color('success'),
            Stat::make(__('resources/permission/strings.fields.excluded_modules'), $stats->with_exclusions)
                ->icon('heroicon-o-no-symbol')
                ->color('danger'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function postsData(): array
    {
        $stats = DB::table('posts')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN pinned = 1 THEN 1 ELSE 0 END) as pinned,
            SUM(CASE WHEN image IS NOT NULL THEN 1 ELSE 0 END) as with_image
        ")->first();

        return [
            Stat::make(__('resources/post/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-document-text')
                ->color('primary'),
            Stat::make(__('resources/post/strings.fields.pinned'), $stats->pinned)
                ->icon('heroicon-o-paper-clip')
                ->color('warning'),
            Stat::make(__('resources/post/strings.filters.has_image'), $stats->with_image)
                ->icon('heroicon-o-photo')
                ->color('info'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function profilesData(): array
    {
        $stats = DB::table('profiles')
            ->join('users', 'profiles.user_id', '=', 'users.id')
            ->tap(User::currentStaff(...))
            ->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN employment_status = 'working' THEN 1 ELSE 0 END) as active_employees,
            SUM(CASE WHEN gender = 'female' THEN 1 ELSE 0 END) as females,
            SUM(CASE WHEN gender = 'male' THEN 1 ELSE 0 END) as males
        ")->first();

        return [
            Stat::make(__('resources/profile/strings.navigation.plural'), $stats->total)
                ->icon('heroicon-o-identification')
                ->color('primary'),
            Stat::make(__('resources/profile/strings.table.employment_status'), $stats->active_employees)
                ->icon('heroicon-o-check-badge')
                ->color('success'),
            Stat::make(__('resources/ad/strings.gender.any'), (int) $stats->males . ' ┆ ' . (int) $stats->females)
                ->icon('heroicon-o-users')
                ->color('info'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function projectsData(): array
    {
        $stats = DB::table('projects')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN deleted_at IS NULL AND archived_at IS NULL THEN 1 ELSE 0 END) as active,
            SUM(CASE WHEN archived_at IS NOT NULL THEN 1 ELSE 0 END) as archived,
            SUM(CASE WHEN deleted_at IS NOT NULL THEN 1 ELSE 0 END) as deleted
        ")->first();

        return [
            Stat::make(__('resources/project/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-rectangle-stack')
                ->color('primary'),
            Stat::make(__('resources/dashboard/strings.analytics.projects.active'), $stats->active)
                ->icon('heroicon-o-check-circle')
                ->color('success'),
            Stat::make(__('resources/dashboard/strings.analytics.projects.archived'), $stats->archived)
                ->icon('heroicon-o-archive-box')
                ->color('warning'),
            Stat::make(__('resources/dashboard/strings.analytics.projects.deleted'), $stats->deleted)
                ->icon('heroicon-o-trash')
                ->color('danger'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function releaseRequestsData(): array
    {
        $stats = DB::table('release_requests')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open,
            SUM(CASE WHEN status = 'in_review' THEN 1 ELSE 0 END) as in_review,
            SUM(CASE WHEN type = 'bug' THEN 1 ELSE 0 END) as bugs
        ")->first();

        return [
            Stat::make(__('resources/release_request/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-lifebuoy')
                ->color('primary'),
            Stat::make(ReleaseRequestStatus::Open->getLabel(), $stats->open)
                ->icon(ReleaseRequestStatus::Open->getIcon())
                ->color(ReleaseRequestStatus::Open->getColor()),
            Stat::make(ReleaseRequestStatus::InReview->getLabel(), $stats->in_review)
                ->icon(ReleaseRequestStatus::InReview->getIcon())
                ->color(ReleaseRequestStatus::InReview->getColor()),
            Stat::make(ReleaseRequestType::Bug->getLabel(), $stats->bugs)
                ->icon(ReleaseRequestType::Bug->getIcon())
                ->color(ReleaseRequestType::Bug->getColor()),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function remindersData(): array
    {
        $stats = DB::table('reminders')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN completed_at IS NULL THEN 1 ELSE 0 END) as active,
            SUM(CASE WHEN completed_at IS NULL AND due_at < NOW() THEN 1 ELSE 0 END) as overdue,
            SUM(CASE WHEN completed_at IS NOT NULL THEN 1 ELSE 0 END) as completed
        ")->first();

        return [
            Stat::make(__('resources/reminder/strings.plural_label'), $stats->total ?? 0)
                ->icon('heroicon-o-bell-alert')
                ->color('primary'),
            Stat::make(__('resources/dashboard/strings.analytics.reminders.active'), $stats->active ?? 0)
                ->icon('heroicon-o-clock')
                ->color('info'),
            Stat::make(__('resources/dashboard/strings.analytics.reminders.overdue'), $stats->overdue ?? 0)
                ->icon('heroicon-o-exclamation-triangle')
                ->color('danger'),
            Stat::make(__('resources/dashboard/strings.analytics.reminders.completed'), $stats->completed ?? 0)
                ->icon('heroicon-o-check-circle')
                ->color('success'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function reportsData(): array
    {
        $stats = DB::table('reports')
            ->selectRaw('COUNT(*) as total, SUM(CASE WHEN active = 1 THEN 1 ELSE 0 END) as active')
            ->first();

        $mostDense = Department::withCount('reports')->having('reports_count', '>', 0)->orderByDesc('reports_count')->first()?->displayLabel() ?? __('resources/dashboard/strings.analytics.departments.unknown');

        return [
            Stat::make(__('resources/dashboard/strings.analytics.reports.top_department'), $mostDense)
                ->icon('heroicon-o-chart-bar')
                ->extraAttributes(['class' => '!text-xs'])
                ->color('warning'),
            Stat::make(__('resources/dashboard/strings.analytics.reports.total'), $stats->total)
                ->icon('heroicon-o-document-text')
                ->color('primary'),
            Stat::make(__('resources/dashboard/strings.analytics.reports.active'), $stats->active)
                ->icon('heroicon-o-document-check')
                ->color('success'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function mediaData(): array
    {
        $library = DB::table('media')->selectRaw("
            COUNT(CASE WHEN parent_id IS NULL THEN 1 END) as items,
            COUNT(CASE WHEN parent_id IS NULL AND active = 1 THEN 1 END) as active,
            COUNT(CASE WHEN parent_id IS NULL AND kind = 'series' THEN 1 END) as series,
            COUNT(CASE WHEN parent_id IS NULL AND kind = 'video' THEN 1 END) as videos,
            COUNT(CASE WHEN parent_id IS NULL AND kind = 'audio' THEN 1 END) as audios,
            COUNT(CASE WHEN parent_id IS NOT NULL THEN 1 END) as episodes
        ")->first();

        $learning = DB::table('knowledge_progress')->selectRaw('
            COUNT(DISTINCT user_id) as learners,
            COUNT(DISTINCT CASE WHEN last_seen_at >= ? THEN user_id END) as weekly,
            COUNT(CASE WHEN completed_at IS NOT NULL THEN 1 END) as completed,
            COALESCE(SUM(position), 0) as seconds
        ', [now()->subDays(7)])->first();

        $top = DB::table('knowledge_progress')
            ->join('media', 'media.id', '=', 'knowledge_progress.media_id')
            ->groupBy('media.id', 'media.title')
            ->orderByRaw('COUNT(DISTINCT knowledge_progress.user_id) DESC')
            ->selectRaw('media.title, COUNT(DISTINCT knowledge_progress.user_id) as learners')
            ->first();

        $s = fn (string $key): string => __('resources/dashboard/strings.analytics.media.' . $key);

        return [
            Stat::make(__('resources/media/strings.plural_label'), $library->items)
                ->description($s('active') . ': ' . (int) $library->active)
                ->icon('heroicon-o-play-circle')
                ->color('primary'),
            Stat::make($s('kinds'), (int) $library->series . ' ┆ ' . (int) $library->videos . ' ┆ ' . (int) $library->audios)
                ->description($s('episodes') . ': ' . (int) $library->episodes)
                ->icon('heroicon-o-rectangle-stack')
                ->color('info'),
            Stat::make($s('learners'), $learning->learners)
                ->description($s('weekly') . ': ' . (int) $learning->weekly)
                ->icon('heroicon-o-users')
                ->color('success'),
            Stat::make($s('completed'), $learning->completed)
                ->description($s('hours') . ': ' . round($learning->seconds / 3600, 1))
                ->icon('heroicon-o-check-badge')
                ->color('success'),
            Stat::make($s('top'), $top?->title ?? '—')
                ->description($top ? $s('learners') . ': ' . (int) $top->learners : null)
                ->extraAttributes(['class' => '!text-xs'])
                ->icon('heroicon-o-trophy')
                ->color('warning'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function reservationPoliciesData(): array
    {
        $stats = DB::table('reservation_policies')->selectRaw("
            COUNT(*) as total,
            COUNT(DISTINCT resource_type) as resource_types,
            COUNT(DISTINCT `key`) as distinct_keys
        ")->first();

        return [
            Stat::make(__('resources/policy/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-adjustments-horizontal')
                ->color('primary'),
            Stat::make(__('resources/dashboard/strings.analytics.policies.resource_types'), $stats->resource_types)
                ->icon('heroicon-o-archive-box')
                ->color('info'),
            Stat::make(__('resources/dashboard/strings.analytics.policies.distinct_keys'), $stats->distinct_keys)
                ->icon('heroicon-o-key')
                ->color('success'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function reservationsData(): array
    {
        $stats = DB::table('reservations')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
            SUM(CASE WHEN status IN ('cancelled_user', 'cancelled_admin') THEN 1 ELSE 0 END) as cancelled,
            SUM(CASE WHEN status = 'active' AND start_time <= NOW() AND end_time >= NOW() THEN 1 ELSE 0 END) as ongoing
        ")->first();

        return [
            Stat::make(__('resources/reservation/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-map-pin')
                ->color('primary'),
            Stat::make(ReservationStatus::Active->getLabel(), $stats->active)
                ->icon(ReservationStatus::Active->getIcon())
                ->color(ReservationStatus::Active->getColor()),
            Stat::make(__('resources/dashboard/strings.analytics.reservations.ongoing'), $stats->ongoing)
                ->icon('heroicon-o-clock')
                ->color('info'),
            Stat::make(__('resources/dashboard/strings.analytics.reservations.cancelled'), $stats->cancelled)
                ->icon('heroicon-o-x-circle')
                ->color('danger'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function resourcesData(): array
    {
        $stats = DB::table('resources')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
            COUNT(DISTINCT type) as distinct_types
        ")->first();

        return [
            Stat::make(__('resources/resource/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-archive-box')
                ->color('primary'),
            Stat::make(__('resources/dashboard/strings.analytics.resources.active'), $stats->active)
                ->icon('heroicon-o-check-circle')
                ->color('success'),
            Stat::make(__('resources/dashboard/strings.analytics.resources.distinct_types'), $stats->distinct_types)
                ->icon('heroicon-o-squares-2x2')
                ->color('info'),
        ];
    }

    public function setTab(string $tab): void
    {
        if (array_key_exists($tab, $this->getAllTabs())) {
            $this->activeTab = $tab;
        }
    }

    #[Computed(seconds: 300, cache: true)]
    public function skillsData(): array
    {
        $skills = DB::table('skills')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active,
            SUM(CASE WHEN is_active = 0 AND is_ghost = 0 THEN 1 ELSE 0 END) as draft,
            SUM(CASE WHEN is_ghost = 1 THEN 1 ELSE 0 END) as ghost
        ")->first();

        $requests = DB::table('skill_user')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
        ")->first();

        return [
            Stat::make(__('resources/skill/strings.plural_label'), $skills->total)
                ->icon('heroicon-o-sparkles')
                ->color('primary'),
            Stat::make(__('resources/skill/strings.filters.active'), $skills->active)
                ->icon('heroicon-o-check-circle')
                ->color('success'),
            Stat::make(__('resources/skill/strings.filters.inactive'), $skills->draft)
                ->icon('heroicon-o-document')
                ->color('gray'),
            Stat::make(__('resources/skill/strings.widget.title'), $skills->ghost)
                ->icon('heroicon-o-magnifying-glass')
                ->color('warning'),
            Stat::make(SkillRequestStatus::Pending->label(), $requests->pending)
                ->icon('heroicon-o-clock')
                ->color('warning'),
            Stat::make(SkillRequestStatus::Approved->label(), $requests->approved)
                ->icon('heroicon-o-check-badge')
                ->color('info'),
            Stat::make(SkillRequestStatus::Rejected->label(), $requests->rejected)
                ->icon('heroicon-o-x-circle')
                ->color('danger'),
        ];
    }

    public function statsSchema(Schema $schema): Schema
    {
        $stats = ! array_key_exists($this->activeTab, $this->getAllTabs()) ? [] : match ($this->activeTab) {
            'users' => $this->usersData,
            'departments' => $this->departmentsData,
            'ads' => $this->adsData,
            'ai_reports' => $this->aiReportsData,
            'reports' => $this->reportsData,
            'media' => $this->mediaData,
            'energy' => $this->energyData,
            'authorities' => $this->authoritiesData,
            'channels' => $this->channelsData,
            'contacts' => $this->contactsData,
            'credentials' => $this->credentialsData,
            'dms' => $this->dmsData,
            'events' => $this->eventsData,
            'faqs' => $this->faqsData,
            'feeds' => $this->feedsData,
            'galleries' => $this->galleriesData,
            'links' => $this->linksData,
            'notify' => $this->notifyData,
            'onboardings' => $this->onboardingsData,
            'permissions' => $this->permissionsData,
            'posts' => $this->postsData,
            'profiles' => $this->profilesData,
            'projects' => $this->projectsData,
            'reminders' => $this->remindersData,
            'support' => $this->releaseRequestsData,
            'reservation_policies' => $this->reservationPoliciesData,
            'reservations' => $this->reservationsData,
            'resources' => $this->resourcesData,
            'skills' => $this->skillsData,
            'suggestions' => $this->suggestionsData,
            'tasks' => $this->tasksData,
            'ths' => $this->thsData,
            default => [],
        };

        return $schema->components([
            Grid::make()
                ->schema(array_map(fn (Stat $stat) => $stat->getValue() === null ? $stat->value(0) : $stat, $stats))
                ->columns([
                    'default' => 1,
                    'sm' => 2,
                    'md' => 3,
                    'lg' => 4,
                    '2xl' => 5,
                ]),
        ]);
    }

    #[Computed(seconds: 300, cache: true)]
    public function suggestionsData(): array
    {
        $stats = DB::table('suggestions')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN stage IN ('pending', 'team_remarks', 'dept_remarks', 'awaiting_decision', 'under_review') THEN 1 ELSE 0 END) as in_process,
            SUM(CASE WHEN stage = 'awaiting_decision' THEN 1 ELSE 0 END) as awaiting_decision,
            SUM(CASE WHEN stage = 'accepted' THEN 1 ELSE 0 END) as accepted,
            SUM(CASE WHEN stage = 'rejected' THEN 1 ELSE 0 END) as rejected,
            SUM(CASE WHEN self_fill = 1 THEN 1 ELSE 0 END) as self_filled,
            SUM(CASE WHEN attachment IS NOT NULL THEN 1 ELSE 0 END) as with_attachment
        ")->first();

        $referralCount = DB::table('reviews')
            ->where('department_id', 'MA')
            ->whereNotNull('referral')
            ->count();

        return [
            Stat::make(__('resources/suggestion/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-light-bulb')
                ->color('primary'),
            Stat::make(__('resources/suggestion/strings.tabs.awaiting_decision'), $stats->awaiting_decision)
                ->icon('heroicon-o-scale')
                ->color('warning'),
            Stat::make(__('resources/suggestion/strings.tabs.accepted'), $stats->accepted)
                ->icon('heroicon-o-check-circle')
                ->color('success'),
            Stat::make(__('resources/suggestion/strings.tabs.rejected'), $stats->rejected)
                ->icon('heroicon-o-x-circle')
                ->color('danger'),
            Stat::make(__('resources/suggestion/strings.filters.has_referral'), $referralCount)
                ->icon('heroicon-o-arrow-uturn-right')
                ->color('info'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function tasksData(): array
    {
        $stats = DB::table('tasks')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN status = 'todo' THEN 1 ELSE 0 END) as todo,
            SUM(CASE WHEN status = 'in-progress' THEN 1 ELSE 0 END) as in_progress
        ")->whereNull('deleted_at')->first();
        $stats->overdue = TaskMetrics::overdue(DB::table('tasks'))->count();

        return [
            Stat::make(__('resources/task/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-clipboard-document-list')
                ->color('primary'),
            Stat::make(__('resources/task/strings.tabs.in_progress'), $stats->in_progress)
                ->icon('heroicon-o-arrow-path')
                ->color('info'),
            Stat::make(__('resources/task/strings.tabs.todo'), $stats->todo)
                ->icon('heroicon-o-clock')
                ->color('gray'),
            Stat::make(__('resources/task/strings.tabs.overdue'), $stats->overdue)
                ->icon('heroicon-o-exclamation-triangle')
                ->color('danger'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function thsData(): array
    {
        $stats = DB::table('tickets')->selectRaw("
            COUNT(*) as total,
            SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open_tickets,
            SUM(CASE WHEN status = 'in-progress' THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN assigned_to IS NULL THEN 1 ELSE 0 END) as unassigned
        ")->first();

        return [
            Stat::make(__('resources/ths/strings.plural_label'), $stats->total)
                ->icon('heroicon-o-ticket')
                ->color('primary'),
            Stat::make(__('resources/ths/strings.tabs.open'), $stats->open_tickets)
                ->icon('heroicon-o-envelope-open')
                ->color('danger'),
            Stat::make(__('resources/ths/strings.tabs.in_progress'), $stats->in_progress)
                ->icon('heroicon-o-arrow-path')
                ->color('info'),
            Stat::make(__('resources/ths/strings.tabs.unassigned'), $stats->unassigned)
                ->icon('heroicon-o-user-minus')
                ->color('warning'),
        ];
    }

    #[Computed(seconds: 300, cache: true)]
    public function usersData(): array
    {
        $since = User::onlineSince();
        $unreachable = PresenceStatus::unreachableValues();
        $marks = implode(',', array_fill(0, count($unreachable), '?'));

        $stats = DB::table('users')
            ->where('type', '!=', UserType::Guest->value)
            ->selectRaw("
            COUNT(*) as total,
            COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
            COUNT(CASE WHEN role IN ('admin', 'developer') THEN 1 END) as admins,
            COUNT(CASE WHEN last_seen >= ? THEN 1 END) as online,
            COUNT(CASE WHEN last_seen >= ? AND presence NOT IN ({$marks}) THEN 1 END) as available
        ", [$since, $since, ...$unreachable])->first();

        return [
            Stat::make(__('resources/dashboard/strings.analytics.users.total'), $stats->total)
                ->icon('heroicon-o-users')
                ->color('primary'),
            Stat::make(__('resources/dashboard/strings.analytics.users.active'), $stats->active)
                ->icon('heroicon-o-check-circle')
                ->color('success'),
            Stat::make(__('resources/dashboard/strings.analytics.users.admins'), $stats->admins)
                ->icon('heroicon-o-shield-check')
                ->color('danger'),
            Stat::make(__('resources/dashboard/strings.analytics.users.online'), $stats->online)
                ->icon('heroicon-o-signal')
                ->color('info'),
            Stat::make(__('resources/dashboard/strings.analytics.users.available'), $stats->available)
                ->icon('heroicon-o-user-circle')
                ->color('success'),
        ];
    }
}
