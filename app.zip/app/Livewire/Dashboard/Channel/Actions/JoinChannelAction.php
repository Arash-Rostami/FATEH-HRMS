<?php

namespace App\Livewire\Dashboard\Channel\Actions;

use App\Enums\ChannelType;
use App\Models\Channel;
use App\Models\ChannelMessage;
use Illuminate\Support\Facades\DB;

class JoinChannelAction
{
    public function execute(int $channelId, int $userId): bool
    {
        if (!auth()->user()?->isActive()) {
            return false;
        }

        return DB::transaction(function () use ($channelId, $userId): bool {
            $channel = Channel::withoutTrashed()->lockForUpdate()->find($channelId);

            if (!$channel || $channel->type !== ChannelType::Open) {
                return false;
            }

            $channel->memberUsers()->newPivotStatement()->insertOrIgnore([
                'channel_id'           => $channelId,
                'user_id'              => $userId,
                'joined_at'            => now(),
                'entered_at'           => now(),
                'last_read_message_id' => ChannelMessage::lastIdForChannel($channelId),
                'created_at'           => now(),
                'updated_at'           => now(),
            ]);

            return true;
        });
    }
}